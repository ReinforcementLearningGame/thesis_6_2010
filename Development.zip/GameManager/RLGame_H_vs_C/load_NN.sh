#!/bin/sh

cp -v ../whVWeights .
cp -v ../whWWeights .
cp -v ../blVWeights .
cp -v ../blWWeights .
