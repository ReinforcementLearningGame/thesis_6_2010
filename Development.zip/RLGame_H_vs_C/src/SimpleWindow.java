/***************
  Created by:  Eirini Ntoutsi
  Operation: Creates a single child window
*******/
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.awt.geom.*;
import java.io.*;
import javax.swing.border.*;

public class SimpleWindow extends JComponent
{
    static JFrame frame;
    private static String title;
    private static String textToShow;
    private static ImageIcon middle;
    private static Dimension minSize;
    public SimpleWindow(String s1,String s2,Dimension size)
    {
        super();
        title=s1;
        textToShow=s2;
        minSize=size;
        setSize(minSize);
    }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
    public void setString(String str)
    {
        textToShow=str;
    }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
    public Dimension getPreferredSize()
    {
        Container parent=getParent();
        return (parent!=null) ? parent.getSize():minSize;
    }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
    public Dimension getMinimumSize()
    {
        return minSize;
    }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
    public void refreshWindow()
    {
        this.repaint();
        if (frame!=null)
            frame.repaint();
    }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
    public static void showSimpleWindow()
    {
        frame = new JFrame();
       JPanel mainPanel=new JPanel();
       JPanel upPanel=new JPanel();
       JPanel toolbarPanel=new JPanel();
       JScrollPane scrollPanel;
       JTextArea textArea;
       JButton closeButton;
       Dimension buttonSize=new Dimension(30,30);
       Dimension scrollPanelDim = new Dimension(200,250);
       Dimension toolbarPanelDim = new Dimension(100,50);

       frame.setBackground(Color.orange);
       frame.setTitle(title);

       mainPanel.setBackground(Color.red);
       mainPanel.setLayout(new BorderLayout());
       upPanel.setBackground(Color.green);
       upPanel.setLayout(new BorderLayout());

       textArea = new JTextArea(textToShow,15,25);
       textArea.setFont(new Font("Comic Sans MS", Font.ROMAN_BASELINE,11));
       textArea.setLineWrap(true);
       textArea.setWrapStyleWord(true);
       textArea.setBackground(Color.orange);

       scrollPanel = new JScrollPane(textArea);
       scrollPanel.setBackground(Color.blue);
       scrollPanel.setSize(scrollPanelDim);
       scrollPanel.setPreferredSize(scrollPanelDim);
       scrollPanel.setMinimumSize(scrollPanelDim);

       toolbarPanel.setBackground(Color.orange);
       toolbarPanel.setSize(toolbarPanelDim);
       toolbarPanel.setMinimumSize(toolbarPanelDim);
       toolbarPanel.setMaximumSize(toolbarPanelDim);
       toolbarPanel.setPreferredSize(toolbarPanelDim);
       //buttons
       //To closeButton kai o listener tou
       closeButton=new JButton(new ImageIcon("images/close.gif"));
       closeButton.setToolTipText("Close");
       closeButton.setSize(buttonSize);
       closeButton.setMinimumSize(buttonSize);
       closeButton.setMaximumSize(buttonSize);
       closeButton.setPreferredSize(buttonSize);

       class closeButtonActionListener implements ActionListener
       {
            public void actionPerformed(ActionEvent evt)
            {
                 frame.dispose();
             }
       }
       closeButtonActionListener myCloseAL=new closeButtonActionListener();
       closeButton.addActionListener(myCloseAL);
       //end of buttons

       toolbarPanel.setLayout(new BoxLayout(toolbarPanel,BoxLayout.X_AXIS));
       toolbarPanel.setBorder(new BevelBorder(BevelBorder.RAISED,Color.gray,Color.gray));
       toolbarPanel.add(BorderLayout.EAST,closeButton);

       upPanel.add(BorderLayout.CENTER,scrollPanel);
       upPanel.add(BorderLayout.NORTH,toolbarPanel);
       mainPanel.add(BorderLayout.CENTER,upPanel);

       //add mainPanel to the frame
       frame.getContentPane().setLayout(new BorderLayout());
       frame.getContentPane().add(BorderLayout.CENTER,mainPanel);
       frame.setSize(minSize);
       frame.setVisible(true);
       frame.setResizable(true);
       frame.addWindowListener(new WindowAdapter()
       {
            public void windowClosing(WindowEvent e)
            {
                frame.dispose();
            }
       });
    }
  //send of class
}