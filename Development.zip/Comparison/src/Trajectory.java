


import java.util.ArrayList;
import java.util.Stack;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class Trajectory extends ArrayList
{

    public Trajectory() 
    {
        super();
    }
    public static Trajectory trajectoryListRedistribution(Trajectory trajectories)
    {
        int k = trajectories.size();
        Stack redistributor = new Stack();
        for(int i=0; i<k; i++)
            redistributor.push(trajectories.get(i));
        trajectories.clear();
        for(int j=0; j<k; j++)
            trajectories.add(redistributor.pop());
        redistributor.clear();
        return trajectories;
    }
}
