
import java.awt.Color;
import javax.swing.*;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
    public class MoveStatus extends JPanel{
        private JLabel JLabel0 = new JLabel(" It is the ");
        private JLabel movementNumLabel = new JLabel("#");
        private JLabel JLabel1 = new JLabel(" move for ");
        private JLabel playerLabel = new JLabel("A");
        private JLabel JLabel2 = new JLabel(" player: He moves from square (");
        private JLabel prevXLabel = new JLabel("#");
        private JLabel JLabel3 = new JLabel(",");
        private JLabel prevYLabel = new JLabel("#");
        private JLabel JLabel4 = new JLabel(") to square (");
        private JLabel nextXLabel = new JLabel("#");
        private JLabel JLabel5 = new JLabel(",");
        private JLabel nextYLabel = new JLabel("#");
        private JLabel JLabel6 = new JLabel(").");
        public static JFrame frame;

        public MoveStatus()
        {
            setBackground(new java.awt.Color(255, 255, 225));
            setLayout(new BoxLayout(this, BoxLayout.LINE_AXIS));
            JLabel0.setFont(new java.awt.Font("SansSerif", 0, 12));
            movementNumLabel.setFont(new java.awt.Font("SansSerif", 1, 16));
            JLabel1.setFont(new java.awt.Font("SansSerif", 0, 12));
            playerLabel.setFont(new java.awt.Font("SansSerif", 1, 14));
            JLabel2.setFont(new java.awt.Font("SansSerif", 0, 12));
            prevXLabel.setFont(new java.awt.Font("SansSerif", 1, 16));
            JLabel3.setFont(new java.awt.Font("SansSerif", 0, 16));
            prevYLabel.setFont(new java.awt.Font("SansSerif", 1, 16));
            JLabel4.setFont(new java.awt.Font("SansSerif", 0, 12));
            nextXLabel.setFont(new java.awt.Font("SansSerif", 1, 16));
            JLabel5.setFont(new java.awt.Font("SansSerif", 0, 16));
            nextYLabel.setFont(new java.awt.Font("SansSerif", 1, 16));
            JLabel6.setFont(new java.awt.Font("SansSerif", 0, 12));
            add(JLabel0);
            add(movementNumLabel);
            add(JLabel1);
            add(playerLabel);
            add(JLabel2);
            add(prevXLabel);
            add(JLabel3);
            add(prevYLabel);
            add(JLabel4);
            add(nextXLabel);
            add(JLabel5);
            add(nextYLabel);
            add(JLabel6);
        }

        public void setMovementNumLabel(int moveNum)
        {
            movementNumLabel.setText(String.valueOf(moveNum));
        }

        public void setPlayerLabel(String player,Color color)
        {
            playerLabel.setText(player);
            playerLabel.setForeground(color);
        }

        public void setPrevXLabel(int prevX)
        {
            prevXLabel.setText(String.valueOf(prevX));
        }

        public void setPrevYLabel(int prevY)
        {
            prevYLabel.setText(String.valueOf(prevY));
        }

        public void setNextXLabel(int nextX)
        {
            nextXLabel.setText(String.valueOf(nextX));
        }

        public void setNextYLabel(int nextY)
        {
            nextYLabel.setText(String.valueOf(nextY));
        }

        public JFrame getMoveStatusFrame()
        {
            return frame;
        }

        public void createAndShowMoveStatus(int dimboard)
        {
        frame = new JFrame("MOVE STATUS");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.add(this);
        frame.pack();
        frame.setSize(new java.awt.Dimension(470,80));
        frame.setResizable(false);
        frame.setVisible(true);
        if(dimboard*40+60>400)
            frame.setLocation(dimboard*40+80, 590);
        else
            frame.setLocation(420, 590);
        ImageIcon winIcon = new ImageIcon(getClass().getResource("images/move_status.png"));
        frame.setIconImage(winIcon.getImage());
        }

    }