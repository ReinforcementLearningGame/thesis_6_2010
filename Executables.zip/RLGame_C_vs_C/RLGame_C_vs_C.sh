#!/bin/sh

java -jar RLGame_C_vs_C.jar

