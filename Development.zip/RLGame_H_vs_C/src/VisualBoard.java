/***************
  Created by: Eirini Ntoutsi
  Operation:
*******/
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.awt.geom.*;
import javax.swing.*;
import java.awt.image.*;
import javax.swing.border.*;

//class VisualBoard (VB gia eykolia)
public class VisualBoard extends JComponent implements Common
{
   Vector visualPawns; //gia na ksero pia pionia na emfanizo/diagrafo
   int width=400;
   int height=400;
   static public String inputFromTextField; //human input string
   private Dimension minVBSize=new Dimension(width,height);
   private int previousX,previousY;
   public Point selectedSquare;

   //constructor
   public VisualBoard()
   {
      super();
      //kathorismos tou size tou visual board component
      previousX=-1;
      previousY=-1;
      selectedSquare=new Point(-1,-1);
      setSize(minVBSize);
      setMaximumSize(minVBSize);
      setMinimumSize(minVBSize);
      setPreferredSize(minVBSize);
      visualPawns=new Vector();
      addMouseListener(new MouseAdapter()
              {
                public void mouseClicked(MouseEvent e)
                {
                    int fromX=e.getX();
                    int fromY=e.getY();
                    int xCoord =(int)java.lang.Math.floor(fromX/(width/DIMBOARD));
                    int yCoord =DIMBOARD-1-(int)java.lang.Math.floor(fromY/(height/DIMBOARD));
                   // System.out.println("xCoord "+xCoord+" yCoord "+yCoord);
                    if((previousX!=-1)&&(previousY!=-1))
                    {
                        if((previousX+previousY<=2)&&((previousX==1)||(previousY==1)))
                        {
                           previousX=0;
                           previousY=0;
                        }

                        if((xCoord+yCoord>=12)&&((xCoord>5)&&(yCoord>5)))
                        {
                            if((previousX==7)&&(previousY==5))
                            {
                                xCoord=7;
                                yCoord=6;
                            }

                            if(((previousX==6)&&(previousY==5))||((previousX==5)&&(previousY==6)))
                            {
                                xCoord=6;
                                yCoord=6;
                            }

                            if((previousX==5)&&(previousY==7))
                            {
                                xCoord=6;
                                yCoord=7;
                            }
                        }
                        inputFromTextField=previousX+""+previousY+""+xCoord+""+yCoord;
                        xCoord=-1;
                        yCoord=-1;
                        selectedSquare.setLocation(xCoord,yCoord);
                    }
                    else
                    {
                         selectedSquare.setLocation(xCoord,yCoord);
//---------------> nikolinos tropopoiisi <---------------
//                         repaint();
//---------------> nikolinos tropopoiisi end <-----------
                    }
                    previousX=xCoord;
                    previousY=yCoord;
//---------------> nikolinos tropopoiisi <---------------
                    repaint();
//---------------> nikolinos tropopoiisi end <-----------
                }
              }
      );
   }

   //klasi Visual Pawn
   public class VisualPawn
   {
      private int cordX;
      private int cordY;
      private int color;

      VisualPawn(int cordX,int cordY, int color)
      {
         this.cordX=cordX;
         this.cordY=cordY;
         this.color=color;
      }
      public int getXCord()
      {
         return cordX;
      }

      public int getYCord()
      {
         return cordY;
      }

      public int getColor()
      {
         return color;
      }
   }

   //metakinise to visual pawn apo ti thesi (removeX,removeY) sti thesi (addX,addY)
   public void moveVisualPawn(int removeX,int removeY,int color,int addX,int addY)
   {
      for(int i=0;i<visualPawns.size();i++)
      {
          VisualPawn tmpPawn=(VisualPawn)visualPawns.get(i);
          if((tmpPawn.getXCord()==removeX)&&(tmpPawn.getYCord()==removeY))
          {
             visualPawns.remove(tmpPawn);
             break;
          }
      }
      VisualPawn toDisplayPawn=new VisualPawn(addX,addY,color);
      visualPawns.addElement(toDisplayPawn);
      repaint();
   }

   //gia ti diagrafi tou visual pawn (removeX,removeY)
   public void deleteVisualPawn(int removeX,int removeY)
   {
      for(int i=0;i<visualPawns.size();i++)
      {
          VisualPawn tmpPawn=(VisualPawn)visualPawns.get(i);
          if((tmpPawn.getXCord()==removeX)&&(tmpPawn.getYCord()==removeY))
          {
              visualPawns.remove(tmpPawn);
              break;
          }
      }
      repaint();
   }
   //kanei reset sta visual pawns
   public void clearVisualBoardPawns()
   {
       visualPawns.clear();
       repaint();
   }

   //gia to paint tou component
   public void paintComponent (Graphics g)
   {
      Graphics2D g2D = null;
      if (g instanceof Graphics2D)
        g2D = (Graphics2D) g;
      else
        return;

      int width = getSize().width;
      int height = getSize().height;
      float slope_x = (width-1)/DIMBOARD;
      float slope_y = (height-1)/DIMBOARD;

      //paralliles kai kathetes grammes gia tin emfanisi tou board
      g2D.setColor(Color.pink);
      for (int i=0;i<DIMBOARD;i++)
      {
        g2D.drawLine(0,(int)(slope_y*i),(int)slope_x*DIMBOARD,(int)slope_y*i);
        g2D.drawLine((int)(slope_x*i),0,(int)slope_x*i,(int)slope_y*DIMBOARD);
      }
      g2D.drawLine(0,(int)(slope_y*DIMBOARD),(int)slope_x*DIMBOARD,(int)slope_y*DIMBOARD);
      g2D.drawLine((int)(slope_x*DIMBOARD)+1,0,(int)slope_x*DIMBOARD+1,(int)slope_y*DIMBOARD);

      //xromatise tis baseis
      g2D.setColor(Color.magenta);
  //********************************************************
            //g2D.fill3DRect((int)( (DIMBOARD-DIMBASE)*slope_x),0,(int)((DIMBOARD)*slope_x),(int)slope_x*DIMBASE,false);
            //Modified by Dockos to
      g2D.fill3DRect((int)((DIMBOARD-DIMBASE)*slope_x)+2,2,(int)(DIMBASE*slope_x)-3,(int)(slope_y*DIMBASE)-3,true);
  //********************************************************
      g2D.setColor(Color.yellow);
  //********************************************************
            //g2D.fill3DRect(0,(int)( (DIMBOARD-DIMBASE)*slope_y),(int)(DIMBASE*slope_x),(int)(DIMBOARD*slope_y),false);
            //Modified by Dockos to
      g2D.fill3DRect(2,(int)((DIMBOARD-DIMBASE)*slope_y)+2,(int)(DIMBASE*slope_x)-3,(int)(DIMBASE*slope_y)-3,true);
  //********************************************************

      //arithmise ta tetragwna
      g2D.setColor(Color.blue);
      for ( int j = 0; j <DIMBOARD; j++ )
      {
         int axeX = (int)((float)j*slope_x);
         int axeY = (int) ((float)j*slope_y);
         g2D.drawString(""+(DIMBOARD-j),0,axeY);
         g2D.drawString(""+(j),axeX,height-10);
      }
      if((selectedSquare.getX()!=-1)&&(selectedSquare.getY()!=-1))
      {
         g2D.setColor(Color.red);
         g2D.draw3DRect((int)(selectedSquare.getX()*slope_x),(int)((DIMBOARD-1-selectedSquare.getY())*slope_y),(int)(slope_x),(int)(slope_y),true);
      }
      //emfanise ta pionia
      for (int k=0;k<visualPawns.size();k++)
      {
         VisualPawn displayP=(VisualPawn)visualPawns.get(k);
         int x=displayP.getXCord();
         int y=displayP.getYCord();
         int myColor=displayP.getColor();
         if(myColor==1)
         {
            g2D.setColor(Color.yellow);
            g2D.fillOval((int)(x*slope_x)+4,(int)((DIMBOARD-1-y)*slope_y)+4,40,40);
         }
         else
         {
            g2D.setColor(Color.magenta);
            g2D.fillOval((int)(x*slope_x)+4,(int)((DIMBOARD-1-y)*slope_y)+4,40,40);
         }
      }
   }
//this is the end
}
