/***************
  Created by:  Eirini Ntoutsi
  Operation: Implements the graph of the game
*******/
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.awt.geom.*;
import java.io.*;

public class PlotXY extends JComponent implements Common
{
  private Vector bestValue; //oi kaliteres pou tou proteinei
  private Vector movesValue;  //oi dikes tou kiniseis
  private Vector worstValue; //oi xeiroteres pou tou proteinei
  final static BasicStroke wideStroke=new BasicStroke(4.0f);
  final static BasicStroke normalStroke=new BasicStroke(2.0f);
  int upperLevel=20;
  private int max=100000;
  private Dimension minSize=new Dimension(550,550);
  public PlotXY(Vector v1,Vector v2,Vector v3)
  {
    super();
    bestValue=v1;
    movesValue=v2;
    worstValue=v3;
    setSize(new Dimension(550,550));
    System.out.println(bestValue.size()+":");
    System.out.println(movesValue.size()+":");
    System.out.println(worstValue.size()+":\n");
  }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
  public Dimension getPreferredSize()
  {
    Container parent=getParent();
    return (parent!=null) ? parent.getSize():minSize;
  }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
  public Dimension getMinimumSize()
  {
    return minSize;
  }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
  public void plot()
  {
    repaint();
  }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
  public double findMax(int k)
  {
    double maxValue=((Double)bestValue.get(0)).doubleValue();
    for (int i=0;i<bestValue.size()-k;i++)
    {
      if (((Double)bestValue.get(i)).doubleValue()<1)
      {
        if(((Double)bestValue.get(i)).doubleValue()>maxValue)
          maxValue=((Double)bestValue.get(i)).doubleValue();
      }
    }
    return maxValue;
  }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
  public double findMin()
  {
    double minValue=((Double)worstValue.get(0)).doubleValue();
    for (int i=0;i<worstValue.size();i++)
    {
      if(((Double)worstValue.get(i)).doubleValue()<minValue)
        minValue=((Double)worstValue.get(i)).doubleValue();
    }
    return minValue;
  }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
 public void paintComponent (Graphics g)
 {
   Graphics2D g2D=null;
   if (g instanceof Graphics2D)
   {
     g2D=(Graphics2D) g;
   }
   else
     return;

   double maxValue=findMax(0);
   double minValue=findMin();
   double delta = maxValue - minValue;
   System.out.println("MAX= "+maxValue+"\t MIN= "+minValue+"MAX-MIN= "+delta);

   int width=getSize().width;
   int height=getSize().height;
   System.out.println("width= "+height+"\t height= "+height);

   int itemsSize=movesValue.size();
   //gia tous aksones
   g2D.setColor(Color.black);
   g2D.setStroke(wideStroke);
   g2D.draw(new Line2D.Double(0,height, 0,0));
   g2D.draw(new Line2D.Double(0, 0, 0,height));

   //find the factor
   double tmp=minValue;
   int factor=10;
   while(tmp<1)
   {
     tmp=minValue*factor;
     factor*=10 ;
   }
   factor/=10;
   float slope_x=width/itemsSize;
   float slope_y=(float)(height/(maxValue));
   System.out.println("factor= "+factor+" heigth="+height);
   System.out.println("items= "+itemsSize+"\tslope_x= "+slope_x+"\tslope_y= "+slope_y);

  //gia tin klimaka ston x kai ston y
   g2D.setColor(Color.blue);
   for ( int j = 0; j <itemsSize; j++ )
   {
      int axeX = (int)((float)j*slope_x);
      int axeY = (int) ((float)j*slope_y);
      g2D.drawString("|"+(j),axeX,height-10);
   }
//ektipose tis min max times
   int tmp1 = (int)(minValue*slope_y);
   double toPrint=tmp1/(factor*slope_y);
   g2D.drawString("-"+(toPrint),0,height-tmp1+upperLevel);
   double maxValue2=findMax(1);
   int tmp2 = (int)(maxValue2*slope_y);
   toPrint=tmp2/(factor*slope_y);
   g2D.drawString("-"+(toPrint),0,height-tmp2+upperLevel);
//1 grafiki
   g2D.setStroke(normalStroke);
   g2D.setColor(Color.red);
   for( int i = 0; i < itemsSize-1; i++ )
   {
//      System.out.println("bestValue.get(i) :"+bestValue.get(i));
      int x = (int) ((float)i*slope_x);
      int y = (int) ((((Double)bestValue.get(i)).doubleValue()*3));
      int xNext = (int)((float)(i+1)*slope_x);
      int yNext = (int) ((((Double)bestValue.get(i+1)).doubleValue()*3));
//      System.out.println("y="+y+" yNext="+yNext);
      g2D.drawLine(x,height-y-upperLevel,xNext,height-yNext-upperLevel);
//      System.out.println("Line=: "+x+"_"+(height-y)+"\t "+xNext+"_"+(height-yNext));
   }

   g2D.setColor(Color.green);
   for( int i = 0; i < itemsSize-1; i++ )
   {
      //System.out.println("movesValue.get(i) :"+movesValue.get(i));
      int x = (int) ((float)i*slope_x);
      int y = (int) ((((Double)movesValue.get(i)).doubleValue()*3));
      int xNext = (int)((float)(i+1)*slope_x);
      int yNext = (int) ((((Double)movesValue.get(i+1)).doubleValue()*3));
      //System.out.println("y="+y+" yNext="+yNext+upperLevel);
      g2D.drawLine(x,height-y-upperLevel,xNext,height-yNext-upperLevel);
      //System.out.println("Line=: "+x+"_"+(height-y+upperLevel)+"\t "+xNext+"_"+(height-yNext+upperLevel));
    }

   g2D.setColor(Color.blue);
   for( int i = 0; i < itemsSize-1; i++ )
   {
      //System.out.println("bestValue.get(i) :"+worstValue.get(i));
      int x = (int) ((float)i*slope_x);
      int y = (int) ((((Double)worstValue.get(i)).doubleValue()*3));
      int xNext = (int)((float)(i+1)*slope_x);
      int yNext = (int) ((((Double)worstValue.get(i+1)).doubleValue()*3));
      //System.out.println("y="+y+" yNext="+yNext);
      g2D.drawLine(x,height-y-upperLevel,xNext,height-yNext-upperLevel);
      //System.out.println("Line=: "+x+"_"+(height-y)+"\t "+xNext+"_"+(height-yNext));
    }
  
  }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
  public void showPlotXY()
  {
//   System.out.println("mesa sti showPlotXY\n");
    final JFrame frame = new JFrame();
    JPanel myJPanel=new JPanel();
    JPanel upPanel=new JPanel();
    Dimension dim=new Dimension(550,550);
    frame.setBackground(Color.orange);
    frame.setTitle("Graph of the game");
    myJPanel.setBackground(Color.orange);
    frame.setContentPane(myJPanel);
    frame.getContentPane().add(this);
    frame.setSize(dim);
    frame.setVisible(true);
    frame.setResizable(true);
    repaint();
    frame.addWindowListener(new WindowAdapter()
    {
      public void windowClosing(WindowEvent e)
        {frame.dispose();}});
    }
}
//this is the end