import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.BorderFactory;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class CmpType1WBS extends ComparisonType
{
    private BoardPixel[][] mainBoardPixelMap;
    private BoardPixel[][] prospectiveSimilarBoardPixelMap;
    private double winnerBoardDeviation;
    private double winnerPixelDeviation[][];
    private WBS1_Settings settingsWindow;
    private double movementVariationPercentage;
    private boolean blackWinner;
    private boolean whiteWinner;

    public CmpType1WBS() {
        //super(mainGame);
        settingsWindow = new WBS1_Settings(ComparisonFrame.comparisonFrame,true);
        blackWinner=false;
        whiteWinner=false;
    }
    @Override
    public WBS1_Settings getSettingsWindow() {
        return settingsWindow;
    }


    private void makePixelMap(Game game, BoardPixel[][] BoardPixelMap){
        int i,j;
        PawnTrajectory pTrajectory;
        PawnTrajectory.StepRecord pawnPosition;
        game.getPawnDeletionPositionList().clear();
        game.makeDelitionList();
        System.out.print("\n***"+game.getPawnDeletionPositionList().size()+"***\n");
        if(whiteWinner){
            for(i=0;i<game.getWhiteTrajectories().size();i++){
                pTrajectory = (PawnTrajectory)(game.getWhiteTrajectories().get(i));
                //System.out.print("\n***"+pTrajectory.size()+"***\n");
                for(j=0;j<pTrajectory.size();j++){
                    pawnPosition = (PawnTrajectory.StepRecord)pTrajectory.get(j);
                    //System.out.print("\n***"+pawnPosition.getPosX()+","+pawnPosition.getPosY()+","+pawnPosition.getStepTime()+"***\n");
                    BoardPixelMap[pawnPosition.getPosX()][pawnPosition.getPosY()].addWhitePass(i, pawnPosition.getStepTime());
                    if(j==pTrajectory.size()-1)
                        if(pTrajectory.getEndState()==-1){
                            System.out.print("\n**************deletioN*************");
                            int delTime=game.isDeletedPawn(1, pawnPosition.getPosX(), pawnPosition.getPosY(), pawnPosition.getStepTime());
                            /*if(delTime<0)*/ System.out.print("\n**************"+delTime+"*************\n");
                            BoardPixelMap[pawnPosition.getPosX()][pawnPosition.getPosY()].addWhiteDeletion(i, delTime);
                        }
                }
            }
        }
        if(blackWinner){
            System.out.print("\n***"+game.getPawnDeletionPositionList().size()+"***\n");
            for(i=0;i<game.getBlackTrajectories().size();i++){
                pTrajectory = (PawnTrajectory)(game.getBlackTrajectories().get(i));
                for(j=0;j<pTrajectory.size();j++){
                    pawnPosition = (PawnTrajectory.StepRecord)pTrajectory.get(j);
                    BoardPixelMap[pawnPosition.getPosX()][pawnPosition.getPosY()].addBlackPass(i, pawnPosition.getStepTime());
                    if(j==pTrajectory.size()-1)
                        if(pTrajectory.getEndState()==-1){
                            System.out.print("\n**************deletioN*************");
                            int delTime=game.isDeletedPawn(0, pawnPosition.getPosX(), pawnPosition.getPosY(), pawnPosition.getStepTime());
                            /*if(delTime<0)*/ System.out.print("\n**************"+delTime+"*************\n");
                            BoardPixelMap[pawnPosition.getPosX()][pawnPosition.getPosY()].addBlackDeletion(i, delTime);
                        }
                }
            }
        }
    }

    public double estimateBlackPixelDeviation(int coordX, int coordY){
        double deviation;
        BoardPixel mainPixel = mainBoardPixelMap[coordX][coordY];
        BoardPixel prospectiveSimilarPixel = prospectiveSimilarBoardPixelMap[coordX][coordY];
        if(mainPixel.getbPass()==null && prospectiveSimilarPixel.getbPass()==null)
            deviation=0;
        else if(mainPixel.getbPass()==null)
            deviation=prospectiveSimilarPixel.getbPass().length;
        else if(prospectiveSimilarPixel.getbPass()==null)
            deviation=mainPixel.getbPass().length;
        else
            deviation = ((double)Math.abs(mainPixel.getbPass().length-prospectiveSimilarPixel.getbPass().length))/(double)mainPixel.getbPass().length;
        winnerPixelDeviation[coordX][coordY]=deviation;
        return Math.abs(deviation);
    }

    public double estimateWhitePixelDeviation(int coordX, int coordY){
        double deviation;
        BoardPixel mainPixel = mainBoardPixelMap[coordX][coordY];
        BoardPixel prospectiveSimilarPixel = prospectiveSimilarBoardPixelMap[coordX][coordY];
        if(mainPixel.getwPass()==null && prospectiveSimilarPixel.getwPass()==null)
            deviation=0;
        else if(mainPixel.getwPass()==null)
            deviation=prospectiveSimilarPixel.getwPass().length;
        else if(prospectiveSimilarPixel.getwPass()==null)
            deviation=mainPixel.getwPass().length;
        else
            deviation = ((double)Math.abs(mainPixel.getwPass().length-prospectiveSimilarPixel.getwPass().length))/(double)mainPixel.getwPass().length;
        winnerPixelDeviation[coordX][coordY]=deviation;
        return Math.abs(deviation);
    }

    public void estimateWinnerBoardDeviation(){
        if(blackWinner){
            for(int i=0;i<mainBoardPixelMap.length;i++)
                for(int j=0;j<mainBoardPixelMap.length;j++)
                    winnerBoardDeviation+=estimateBlackPixelDeviation(i, j);
        }
        if(whiteWinner){
            for(int i=0;i<mainBoardPixelMap.length;i++)
                for(int j=0;j<mainBoardPixelMap.length;j++)
                    winnerBoardDeviation+=estimateWhitePixelDeviation(i, j);
        }
    }

   @Override
    public void estimateComparisonMeasure(){
        double winnerMeasure;
        double totalWinnerBoardDeviation=winnerBoardDeviation;
        winnerBoardDeviation=winnerBoardDeviation/Math.pow(mainBoardPixelMap.length,2);
        if(whiteWinner) System.out.print("\nTHE BOARD SNAPSHOT DEVIATION  PERCENTAGE FOR THE PLAYER OF THE WHITE BASE IS: "+winnerBoardDeviation);
        if(blackWinner) System.out.print("\nTHE BOARD SNAPSHOT DEVIATION  PERCENTAGE FOR THE PLAYER OF THE RED BASE IS: "+winnerBoardDeviation);
        if(winnerBoardDeviation>settingsWindow.winnerBoardDeviationMaxPercentage){
            super.setCmpMeasure1(0);
            super.setCmpMeasure2(0);
            System.out.print("\n");
            return;
        }
        winnerMeasure=1-winnerBoardDeviation/settingsWindow.winnerBoardDeviationMaxPercentage;
        if(winnerBoardDeviation>settingsWindow.winnerBoardDeviationMaxPercentage)
            winnerMeasure=0;
        if(winnerMeasure==1){
            super.setCmpMeasure1(1);
            super.setCmpMeasure2(1);
            System.out.print("\n");
        }
        else{
            super.setCmpMeasure1(winnerMeasure*(1-Math.pow(movementVariationPercentage/settingsWindow.movementVariationPercentageLimit, 2)));
            super.setCmpMeasure2((1-Math.exp(-mainBoardPixelMap.length*mainBoardPixelMap.length/totalWinnerBoardDeviation))*winnerMeasure*(1-Math.pow(movementVariationPercentage/settingsWindow.movementVariationPercentageLimit, 2)));
        }
        System.out.print("\nTHE SIMILARITY MEASURE 1 IS: "+super.getCmpMeasure1());
        System.out.print("\nTHE SIMILARITY MEASURE 2 IS: "+super.getCmpMeasure2()+"\n");

    }

    @Override
    public SingleResultInfo collectAndStoreInfo(){
    SingleResultInfo resultInfo = new SingleResultInfo(super.getProspectiveSimilarGame().getGameFile(),this.winnerBoardDeviation,super.getCmpMeasure1(),super.getCmpMeasure2(),super.getProspectiveSimilarGame().getFileSrvs().getWinnerMovements(),this.movementVariationPercentage);
    return resultInfo;
    }

    @Override
    public String printResult(){
        String result="";
        result += "\n\t\t\tFOUND "+this.getResult().size()+" SIMILAR GAMES\n";
        result += "\n\tFile Name\t\tWinner Deviation\tMovements\tMovement Variation\tSimilarity Measure 1\tSimilarity Measure 2\n";
        ComparisonType.SingleResultInfo rslt;
        for(int i=0; i<this.getResult().size(); i++){
            rslt = (ComparisonType.SingleResultInfo)this.getResult().get(i);
            result += String.format("%s\t       %.3f\t       %d\t         %.3f\t         %.5f\t         %.5f\n", rslt.getSimilarFile().getName(),rslt.getWhiteBoardDeviation(),rslt.getMoveTime(),rslt.getMovementVariationPercentage(),rslt.getSimilarityMeasure1(),rslt.getSimilarityMeasure2());
        }
        return result;
    }

    @Override
    public boolean prepareSingleComparison(Game mainGame){
        int whiteUsedPawnsDiff = Math.abs(super.getProspectiveSimilarGame().getWhiteTrajectories().size()-mainGame.getWhiteTrajectories().size());
        int blackUsedPawnsDiff = Math.abs(super.getProspectiveSimilarGame().getBlackTrajectories().size()-mainGame.getBlackTrajectories().size());
        if(settingsWindow.usedPawnsCheck.isSelected() && (whiteUsedPawnsDiff>mainGame.getFileSrvs().getFNaneAnalyzer().getGameNumpawns()/4 && blackUsedPawnsDiff>mainGame.getFileSrvs().getFNaneAnalyzer().getGameNumpawns()/4))
            return false;
        if(settingsWindow.winnerCheck.isSelected() && super.getProspectiveSimilarGame().isBlackWinner()!=mainGame.isBlackWinner())
            return false;
        int movementVariation=super.getProspectiveSimilarGame().getFileSrvs().getMovementList().size()-mainGame.getFileSrvs().getMovementList().size();
        movementVariationPercentage=Math.abs((double)movementVariation)/(double)mainGame.getFileSrvs().getMovementList().size();
        System.out.print("\nTHE MOVEMENT VARIATION PERCENTAGE IS: "+movementVariationPercentage);
        if(super.getProspectiveSimilarGame().getFileSrvs().getMovementList().size()>(1+settingsWindow.movementVariationPercentageLimit)*mainGame.getFileSrvs().getMovementList().size() || super.getProspectiveSimilarGame().getFileSrvs().getMovementList().size()<(1-settingsWindow.movementVariationPercentageLimit)*mainGame.getFileSrvs().getMovementList().size()){
            System.out.print("\n");
            return false;
        }
        int dimBoard=mainGame.getFileSrvs().getFNaneAnalyzer().getGameDimboard();
        if(mainBoardPixelMap==null||super.isNewGameSelection()){
            if(mainGame.isBlackWinner()){
                blackWinner=true;
                whiteWinner=false;
            }
            else{
                blackWinner=false;
                whiteWinner=true;
            }
            mainBoardPixelMap = new BoardPixel[dimBoard][dimBoard];
            for(int i=0;i<dimBoard;i++)
                for(int j=0;j<dimBoard;j++){
                    //System.out.print("\n***"+i+","+j+"***\n");
                    mainBoardPixelMap[i][j] = new BoardPixel(i,j);
                }
            makePixelMap(mainGame, mainBoardPixelMap);
            super.setNewGameSelection(false);
        }
        prospectiveSimilarBoardPixelMap = new BoardPixel[dimBoard][dimBoard];
        for(int i=0;i<dimBoard;i++)
            for(int j=0;j<dimBoard;j++){
                //System.out.print("\n***"+i+","+j+"***\n");
                prospectiveSimilarBoardPixelMap[i][j] = new BoardPixel(i,j);
            }
        makePixelMap(super.getProspectiveSimilarGame(), prospectiveSimilarBoardPixelMap);
        winnerPixelDeviation=new double[dimBoard][dimBoard];
        winnerBoardDeviation=0;
        estimateWinnerBoardDeviation();
        return true;
    }

    public class WBS1_Settings extends JDialog {

        public WBS1_Settings(Frame parent, boolean modal) {
            super(parent, modal);
            initComponents();
            movementVariationPercentageTextField.setText(String.valueOf(movementVariationPercentageLimit));
            winnerBoardDeviationPercentageTextField.setText(String.valueOf(winnerBoardDeviationMaxPercentage));
        }

        private void controlJTextFieldAndItsDoubleValue(JTextField textField, double fieldValue, double defaultValue, double minValue, double maxvalue, String messageTitle, String paramName){
            try
            {
                if(textField.getText().isEmpty())
                {
                    fieldValue=defaultValue;
                    textField.setText(Double.toString(fieldValue));
                }
                else
                {
                    double a =Double.valueOf(textField.getText());
                    if(a<=minValue || a>maxvalue)
                    {
                        JOptionPane.showMessageDialog(this, "Invalid number of "+paramName+". The system will set it to default.", messageTitle, JOptionPane.WARNING_MESSAGE, new ImageIcon(getClass().getResource("images/setinterface.png")));
                        fieldValue=defaultValue;
                        textField.setText(String.valueOf(fieldValue));
                    }
                    else fieldValue=a;
                }
                System.out.print(fieldValue);

            }
            catch(java.util.InputMismatchException IME)
            {
            JOptionPane.showMessageDialog(this, "InputMismatchException. The system will set "+paramName+" number to default.", messageTitle, JOptionPane.WARNING_MESSAGE, new ImageIcon(getClass().getResource("images/setinterface.png")));
            fieldValue=defaultValue;
            textField.setText(String.valueOf(defaultValue));
            System.out.print(fieldValue);
            }
            catch(java.util.NoSuchElementException NSE)
            {
            JOptionPane.showMessageDialog(this, "NoSuchElementException. The system will set "+paramName+" number to default.", messageTitle, JOptionPane.WARNING_MESSAGE, new ImageIcon(getClass().getResource("images/setinterface.png")));
            fieldValue=defaultValue;
            textField.setText(String.valueOf(defaultValue));
            System.out.print(fieldValue);
            }
            catch(IllegalStateException ISE)
            {
            JOptionPane.showMessageDialog(this, "IllegalStateException. The system will set "+paramName+" number to default.", messageTitle, JOptionPane.WARNING_MESSAGE, new ImageIcon(getClass().getResource("images/setinterface.png")));
            fieldValue=defaultValue;
            textField.setText(String.valueOf(defaultValue));
            System.out.print(fieldValue);
            }
        }

        private void initComponents() {
            basePanel = new JPanel();
            settingsPanel = new JPanel();
            jLabel1 = new JLabel();
            jLabel2 = new JLabel();
            movementVariationPercentageTextField = new JTextField();
            winnerBoardDeviationPercentageTextField = new JTextField();
            OKButton = new JButton();
            winnerCheck = new JCheckBox();
            usedPawnsCheck = new JCheckBox();

            setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
            setTitle("\"Single Game Board Snapshot\" comparison settings");
            setIconImage(new ImageIcon(getClass().getResource("/images/options_small.png")).getImage());
            setResizable(false);
            /*addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
            noTypeSelectionMessage(evt);
            }
            });*/

            basePanel.setBackground(new Color(231, 241, 241));
            basePanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
            basePanel.setPreferredSize(new Dimension(410, 390));
            basePanel.setRequestFocusEnabled(false);
            basePanel.setLayout(new BorderLayout());

            settingsPanel.setBackground(new Color(182, 208, 208));
            settingsPanel.setBorder(BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(231, 241, 241), new java.awt.Color(0, 102, 102), new java.awt.Color(0, 102, 102), new java.awt.Color(231, 241, 241)), "StWT COMPARISON SETTINGS", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 14), new java.awt.Color(0, 102, 102))); // NOI18N
            settingsPanel.setPreferredSize(new Dimension(350, 350));

            jLabel1.setFont(jLabel1.getFont().deriveFont(jLabel1.getFont().getSize()+1f));
            jLabel1.setForeground(new Color(0, 51, 51));
            jLabel1.setText("Movement Variation Percentage Limit:");

            jLabel2.setFont(jLabel2.getFont().deriveFont(jLabel2.getFont().getSize()+1f));
            jLabel2.setForeground(new Color(0, 51, 51));
            jLabel2.setText("Winner Board Deviation Max Percentage:");

            winnerCheck.setFont(winnerCheck.getFont().deriveFont(winnerCheck.getFont().getSize()+1f));
            winnerCheck.setForeground(new Color(0, 51, 51));
            winnerCheck.setBackground(new Color(182, 208, 208));
            winnerCheck.setText("Check for winner");

            usedPawnsCheck.setFont(usedPawnsCheck.getFont().deriveFont(usedPawnsCheck.getFont().getSize()+1f));
            usedPawnsCheck.setForeground(new Color(0, 51, 51));
            usedPawnsCheck.setBackground(new Color(182, 208, 208));
            usedPawnsCheck.setText("Check for used pawns");

            movementVariationPercentageTextField.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                    movementVariationPercentageTextFieldActionPerformed(evt);
                }
            });
            movementVariationPercentageTextField.addFocusListener(new FocusAdapter() {
                @Override
                public void focusLost(FocusEvent evt) {
                    movementVariationPercentageTextFieldFocusLost(evt);
                }
            });

            winnerBoardDeviationPercentageTextField.addActionListener((ActionListener) new ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                    winnerBoardDeviationPercentageTextFieldActionPerformed(evt);
                }
            });
            winnerBoardDeviationPercentageTextField.addFocusListener(new FocusAdapter() {
                @Override
                public void focusLost(FocusEvent evt) {
                    winnerBoardDeviationPercentageTextFieldFocusLost(evt);
                }
            });

            OKButton.setFont(OKButton.getFont().deriveFont(OKButton.getFont().getSize()+2f));
            OKButton.setForeground(new Color(0, 51, 51));
            OKButton.setIcon(new ImageIcon(getClass().getResource("/images/dialog-ok.png")));
            OKButton.setText(" O K");
            OKButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                    OKButtonActionPerformed(evt);
                }
            });

            GroupLayout settingsPanelLayout = new GroupLayout(settingsPanel);
            settingsPanel.setLayout(settingsPanelLayout);
            settingsPanelLayout.setHorizontalGroup(
                settingsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(settingsPanelLayout.createSequentialGroup()
                    .addGap(32, 32, 32)
                    .addGroup(settingsPanelLayout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                        .addComponent(OKButton)
                        .addGroup(settingsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addComponent(winnerCheck)
                            .addComponent(usedPawnsCheck)
                            .addGroup(settingsPanelLayout.createSequentialGroup()
                                .addGroup(settingsPanelLayout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel1))
                                .addGap(18, 18, 18)
                                .addGroup(settingsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                    .addComponent(winnerBoardDeviationPercentageTextField, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                    .addComponent(movementVariationPercentageTextField, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)))))
                    .addContainerGap(30, Short.MAX_VALUE))
            );
            settingsPanelLayout.setVerticalGroup(
                settingsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(settingsPanelLayout.createSequentialGroup()
                    .addGap(32, 32, 32)
                    .addGroup(settingsPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1)
                        .addComponent(movementVariationPercentageTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(settingsPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2)
                        .addComponent(winnerBoardDeviationPercentageTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                    .addGap(30, 30, 30)
                    .addComponent(winnerCheck)
                    .addGap(18, 18, 18)
                    .addComponent(usedPawnsCheck)
                    .addGap(30, 30, 30)
                    .addComponent(OKButton)
                    .addContainerGap(30, Short.MAX_VALUE))
            );

            basePanel.add(settingsPanel, BorderLayout.CENTER);

            getContentPane().add(basePanel, BorderLayout.CENTER);

            pack();
        }

        /*private void noTypeSelectionMessage(java.awt.event.WindowEvent evt) {
        if(areaComparisonPercentageLimit==0)
        JOptionPane.showMessageDialog(this, "<html><font color=\"#006666\">There is no directory selected. Prompt again to select one.</font>", "Options Window", JOptionPane.WARNING_MESSAGE);
        }*/

        private void movementVariationPercentageTextFieldActionPerformed(ActionEvent evt) {
            controlJTextFieldAndItsDoubleValue(movementVariationPercentageTextField, movementVariationPercentageLimit, 0.3, 0.0, 1.0, "Area Percentage Limit", "Area percentage limit");
        }

        private void winnerBoardDeviationPercentageTextFieldActionPerformed(ActionEvent evt) {
            controlJTextFieldAndItsDoubleValue(winnerBoardDeviationPercentageTextField, winnerBoardDeviationMaxPercentage, 0.2, 0.0, 1.0, "Time Variation Max Percentage", "Time variation max percentage");
        }

        private void movementVariationPercentageTextFieldFocusLost(FocusEvent evt) {
            controlJTextFieldAndItsDoubleValue(movementVariationPercentageTextField, movementVariationPercentageLimit, 0.3, 0.0, 1.0, "Area Percentage Limit", "Area percentage limit");
        }

        private void winnerBoardDeviationPercentageTextFieldFocusLost(FocusEvent evt) {
            controlJTextFieldAndItsDoubleValue(winnerBoardDeviationPercentageTextField, winnerBoardDeviationMaxPercentage, 0.2, 0.0, 1.0, "Time Variation Max Percentage", "Time variation max percentage");
        }

        private void OKButtonActionPerformed(ActionEvent evt) {
            movementVariationPercentageTextFieldActionPerformed(evt);
            winnerBoardDeviationPercentageTextFieldActionPerformed(evt);
            movementVariationPercentageLimit = Double.valueOf(movementVariationPercentageTextField.getText());
            winnerBoardDeviationMaxPercentage = Double.valueOf(winnerBoardDeviationPercentageTextField.getText());
            ComparisonFrame.comparisonFrame.recompareConf();
            setVisible(false);
        }

        private double movementVariationPercentageLimit=0.3;
        private double winnerBoardDeviationMaxPercentage=0.2;
        private JButton OKButton;
        private JTextField movementVariationPercentageTextField;
        private JTextField winnerBoardDeviationPercentageTextField;
        private JPanel basePanel;
        private JLabel jLabel1;
        private JLabel jLabel2;
        private JPanel settingsPanel;
        private JCheckBox winnerCheck;
        private JCheckBox usedPawnsCheck;
    }

}
