


import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class Game {
    private JFileChooser fileSelection;
    private SimilarGamesListWindow similarFileSelection;
    private FileServices fileSrvs;
    private File gameFile;
    private Trajectory blackTrajectories;
    private Trajectory whiteTrajectories;
    private GameInfoWindow gameInfoWindow;
    private ArrayList pawnDeletionPositionList;
    private PawnTrajectory winningTrajectory;
    private boolean whiteWinner;
    private boolean blackWinner;
    private FileNameExtensionFilter fileType;

    //private int dimboard;
    //private int dimbase;
    
    public  Game()
    {
        blackTrajectories = new Trajectory();
        whiteTrajectories = new Trajectory();
        blackTrajectories.clear();
        whiteTrajectories.clear();
        whiteWinner=false;
        blackWinner=false;
        winningTrajectory=null;
        similarFileSelection=null;
    }

    /*  public int getDimbase() {
        return dimbase;
    }

    public int getDimboard() {
        return dimboard;
    }  */

    public void setSimilarFileSelection(SimilarGamesListWindow similarFileSelection) {
        this.similarFileSelection = similarFileSelection;
    }

    public SimilarGamesListWindow getSimilarFileSelection() {
        return similarFileSelection;
    }

    public File getGameFile() {
        return gameFile;
    }

    public GameInfoWindow getGameInfoWindow() {
        return gameInfoWindow;
    }

    public FileServices getFileSrvs() {
        return fileSrvs;
    }
    
    public Trajectory getBlackTrajectories() {
        return blackTrajectories;
    }

    public JFileChooser getFileSelection() {
        return fileSelection;
    }

    public FileNameExtensionFilter getFileType() {
        return fileType;
    }

    public ArrayList getPawnDeletionPositionList() {
        return pawnDeletionPositionList;
    }

    public void setPawnDeletionPositionList(ArrayList pawnDeletionPositionList) {
        this.pawnDeletionPositionList = pawnDeletionPositionList;
    }

    public void setFileType(FileNameExtensionFilter fileType) {
        this.fileType = fileType;
    }


    public void setFileSrvs(FileServices fileSrvs) {
        this.fileSrvs = fileSrvs;
    }

    public void setGameFile(File gameFile) {
        this.gameFile = gameFile;
    }

    public void setBlackTrajectories(Trajectory blackTrajectories) {
        this.blackTrajectories = blackTrajectories;
    }

    public void setWhiteTrajectories(Trajectory whiteTrajectories) {
        this.whiteTrajectories = whiteTrajectories;
    }

    public void setPawnDeletionPossitionList(ArrayList pawnDeletionPossitionList) {
        this.pawnDeletionPositionList = pawnDeletionPossitionList;
    }

    public Trajectory getWhiteTrajectories() {
        return whiteTrajectories;
    }

    public boolean isWhiteWinner() {
        return whiteWinner;
    }

    public void setWhiteWinner(boolean whiteWinner) {
        this.whiteWinner = whiteWinner;
    }

    public boolean isBlackWinner() {
        return blackWinner;
    }

    public void setBlackWinner(boolean blackWinner) {
        this.blackWinner = blackWinner;
    }

    public PawnTrajectory getWinningTrajectory() {
        return winningTrajectory;
    }

    public void setWinningTrajectory(PawnTrajectory winningTrajectory) {
        this.winningTrajectory = winningTrajectory;
    }

    public void createGameInfoWindow(String title,String innerTitle)
    {
        if(!fileSrvs.getFNaneAnalyzer().equals(null))
        {
            gameInfoWindow = new GameInfoWindow();
            gameInfoWindow.updateGameInfoWindow(this);
            gameInfoWindow.setTitleLabelText(innerTitle);
            gameInfoWindow.setTitle(title);
            gameInfoWindow.setVisible(true);
            gameInfoWindow.setLocation((int) (Toolkit.getDefaultToolkit().getScreenSize().getWidth()/2 - gameInfoWindow.getWidth()/2),(int) (Toolkit.getDefaultToolkit().getScreenSize().getHeight()/2 - gameInfoWindow.getHeight()/2));
        }

    }
    
    public void selectMainGame()
    {
        //JFileChooser fileSelection;
        FileNameExtensionFilter filter1 = new FileNameExtensionFilter("MinMaxGame Playback File Type", "mmg");
        FileNameExtensionFilter filter = new FileNameExtensionFilter("RLGame Playback File", "rlg");
        fileSelection= new JFileChooser();
        fileSelection.setDialogTitle("Open Game File");
        fileSelection.setFileFilter(filter1);
        fileSelection.setFileFilter(filter);
        if(gameFile==null)
            fileSelection.setCurrentDirectory(new File(System.getProperty("user.dir")));
        else
            fileSelection.setCurrentDirectory(gameFile);
        fileSelection.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
        fileSelection.setApproveButtonText("Select");
        fileSelection.setApproveButtonToolTipText("Select an RLGame saved file");
        fileSelection.showOpenDialog(ComparisonFrame.comparisonFrame);
        if(fileSelection.getSelectedFile()==null || fileSelection.getSelectedFile().equals(gameFile) || fileSelection.getSelectedFile().isDirectory() )
        {
           JOptionPane.showMessageDialog(ComparisonFrame.comparisonFrame, "<html><font color=\"#006666\">There is not a new main game file selected.<br/>Promt again if you want to select one.</font>", "Main game selection", JOptionPane.WARNING_MESSAGE);
           if(gameFile==null)
               JOptionPane.showMessageDialog(ComparisonFrame.comparisonFrame, "<html><font color=\"#006666\">There is no main game file selected.</font>", "Main game error", JOptionPane.ERROR_MESSAGE);
           return;
        }
        gameFile = fileSelection.getSelectedFile();
        try {
            fileSrvs = new FileServices(gameFile);
        } catch (IOException ex) {
            Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
        }
        fileType=(FileNameExtensionFilter)fileSelection.getFileFilter();

        if(fileSelection.getFileFilter() == filter)
            fileSrvs.setFileType('a');
        if(fileSelection.getFileFilter() == filter1)
            fileSrvs.setFileType('b');

        //dimboard = fileSrvs.getFNaneAnalyzer().getGameDimboard();
        //dimbase = fileSrvs.getFNaneAnalyzer().getGameDimbase();

        fileSrvs.getMovementList().clear();
        try
        {
            fileSrvs.readRecordsToMakeList();
        }
        catch (NullPointerException NPE)
        {
            return;
        }

        blackTrajectories.clear();
        whiteTrajectories.clear();

        fileSrvs.estimateLostPawns();
        fileSrvs.getWinnerMovements();

        System.out.print("\nThe movement list's size is: ");
        System.out.print(this.fileSrvs.getMovementList().size());
    }

    public void selectASimilarGame()
    {
        if(similarFileSelection==null)
            similarFileSelection = new SimilarGamesListWindow(ComparisonFrame.comparisonFrame,true);
        similarFileSelection.getFileList().setEnabled(true);
        similarFileSelection.setLocation(ComparisonFrame.comparisonFrame.getWidth()-similarFileSelection.getWidth(), ComparisonFrame.comparisonFrame.getHeight()-similarFileSelection.getHeight());
        similarFileSelection.setVisible(true);
        if(similarFileSelection.getSelectedFile()==null)
        {
           return;
        }
        gameFile = similarFileSelection.getSelectedFile();
        try {
            fileSrvs = new FileServices(gameFile);
        } catch (IOException ex) {
            Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
        }
        //fileType=(FileNameExtensionFilter)similarFileSelection.getFileFilter();

        //dimboard = fileSrvs.getFNaneAnalyzer().getGameDimboard();
        //dimbase = fileSrvs.getFNaneAnalyzer().getGameDimbase();

        fileSrvs.getMovementList().clear();
        try
        {
            fileSrvs.readRecordsToMakeList();
        }
        catch (NullPointerException NPE)
        {
            return;
        }

        blackTrajectories.clear();
        whiteTrajectories.clear();

        fileSrvs.estimateLostPawns();
        fileSrvs.getWinnerMovements();

        System.out.print("\nThe movement list's size is: ");
        System.out.print(this.fileSrvs.getMovementList().size());
    }
    
    public void splitPawnTrajectories(int firstPosition)
    {
        int x1,y1,x2 = 0,y2 = 0;
        boolean firstUse=true;
        boolean waitNextPawnStart=true;
        boolean deletedEnd = false;
        int j=0;
        PawnTrajectory singleTrajectory = new PawnTrajectory();
        singleTrajectory.clear();

       if(pawnDeletionPositionList==null)
       {
           makeDelitionList();
           System.out.print("\n----- Deletions: "+pawnDeletionPositionList.size()+" -----");
       }

        for(int i=firstPosition; i<fileSrvs.getMovementList().size(); i=i+2)
        {
            if(firstUse)
            {
                firstUse=false;
                x1=fileSrvs.getMovementList().getMovement(i).getPosPrevX();
                y1=fileSrvs.getMovementList().getMovement(i).getPosPrevY();
                x2=fileSrvs.getMovementList().getMovement(i).getPosNextX();
                y2=fileSrvs.getMovementList().getMovement(i).getPosNextY();
                singleTrajectory.addPosition(j, x1, y1, i);
                j++;
                if(isDeletedPawn((firstPosition+1)%2, x2, y2,i)!=-1)
                {
                    singleTrajectory.setEndState(-1);
                    deletedEnd=true;
                }
            }
            else{
                x1=fileSrvs.getMovementList().getMovement(i).getPosPrevX();
                y1=fileSrvs.getMovementList().getMovement(i).getPosPrevY();
                if(x1==x2 && y1==y2 && deletedEnd==false)
                {
                    singleTrajectory.addPosition(j, x1, y1, i);
                    j++;
                    x2=fileSrvs.getMovementList().getMovement(i).getPosNextX();
                    y2=fileSrvs.getMovementList().getMovement(i).getPosNextY();
        
                    if(isDeletedPawn((firstPosition+1)%2, x2, y2,i)!=-1)
                    {
                        singleTrajectory.setEndState(-1);
                        deletedEnd=true;
                    }
        
                    if(firstPosition%2==0
                            && x2>=fileSrvs.getFNaneAnalyzer().getGameDimboard()-fileSrvs.getFNaneAnalyzer().getGameDimbase()
                            && y2>=fileSrvs.getFNaneAnalyzer().getGameDimboard()-fileSrvs.getFNaneAnalyzer().getGameDimbase())
                        singleTrajectory.setEndState(1);
                    if(firstPosition%2==1
                            && x2<=fileSrvs.getFNaneAnalyzer().getGameDimbase()-1
                            && y2<=fileSrvs.getFNaneAnalyzer().getGameDimbase()-1)
                        singleTrajectory.setEndState(1);
                }
                else if(firstPosition%2==0 && waitNextPawnStart && x1==0 && y1==0)
                    {
                        splitPawnTrajectories(i);
                        waitNextPawnStart=false;
                    }
                else if(firstPosition%2==1 && waitNextPawnStart && x1==fileSrvs.getFNaneAnalyzer().getGameDimboard()-1 && y1==fileSrvs.getFNaneAnalyzer().getGameDimboard()-1)
                    {
                        splitPawnTrajectories(i);
                        waitNextPawnStart=false;
                    }
            }
        }
        singleTrajectory.addPosition(j, x2, y2, singleTrajectory.getPosition(j-1).getStepTime());
        
        int lastPosition = singleTrajectory.getPosition(j).getStepTime();
        singleTrajectory.setStartTime(firstPosition);
        singleTrajectory.setEndTime(lastPosition);

        System.out.print("\n\nThe point sequence for "+(firstPosition)+"th pawn's trajectory is:\n");
        for(int m=0; m<singleTrajectory.size(); m++)
        {
            System.out.print(singleTrajectory.getPosition(m).getPosX()+"*"+singleTrajectory.getPosition(m).getPosY()+" --> ");
        }
        System.out.print("\nTime: **"+singleTrajectory.getStartTime()+"*"+singleTrajectory.getEndTime()+"**");
        if(singleTrajectory.getEndState()==1)
            System.out.print("\nThis pawn is the WINNER");
        if(singleTrajectory.getEndState()==-1)
            System.out.print("\nThis pawn is DELETED");

        if(firstPosition%2==0)
        {
            if(singleTrajectory.getEndState()==1)
            {
                winningTrajectory=singleTrajectory;
                whiteWinner=true;
                blackWinner=false;
            }
            whiteTrajectories.add(singleTrajectory);
        }
        else if(firstPosition%2==1)
        {
            if(singleTrajectory.getEndState()==1)
            {
                winningTrajectory=singleTrajectory;
                blackWinner=true;
                whiteWinner=false;
            }
            blackTrajectories.add(singleTrajectory);
        }
        //if(pawnDeletionPositionList.isEmpty())
            //pawnDeletionPositionList=null;
    }

    public int isDeletedPawn(int colorNum, int coordX, int coordY, int positionTime)
    {
        if(!(pawnDeletionPositionList==null))
        {
            for(int i=0; i<pawnDeletionPositionList.size(); i++)
            {
                PawnDeletionPossition dPawn=(PawnDeletionPossition) pawnDeletionPositionList.get(i);
                if(dPawn.pawnColorNumber==colorNum)
                {
                    if(dPawn.xPosCoord==coordX && dPawn.yPosCoord==coordY)
                    {
                        if(positionTime<=dPawn.getDeletionTime())
                        {
                            int deletionExistenceTime=positionTime;
                            for(int pos=positionTime; pos<dPawn.getDeletionTime(); pos++)
                            {
                                if(fileSrvs.getMovementList().getMovement(pos).getPosPrevX()==coordX && fileSrvs.getMovementList().getMovement(pos).getPosPrevY()==coordY)
                                    deletionExistenceTime=pos;
                            }
                            if(deletionExistenceTime==positionTime)
                            {
                                pawnDeletionPositionList.remove(i);
                                pawnDeletionPositionList.trimToSize();
                                return dPawn.getDeletionTime();
                            }
                        }
                    }
                }
            }
        }
        return -1;
    }
    
    public void makeDelitionList()
    {
        if(gameFile!=null)
        {
            pawnDeletionPositionList = new ArrayList();
            pawnDeletionPositionList.clear();
            for(int serialNum=0; serialNum<fileSrvs.getMovementList().size(); serialNum++)
            {
                if(!fileSrvs.getMovementList().getMovement(serialNum).getPawnsToDelete().isEmpty())
                {
                    for(int i=0; i<fileSrvs.getMovementList().getMovement(serialNum).getPawnsToDelete().size(); i++)
                    {
                        String dPawn= (String)fileSrvs.getMovementList().getMovement(serialNum).getPawnsToDelete().get(i);
                        Scanner pawnToDelete= new Scanner(dPawn.replace("*", " "));
                        int colorNum = pawnToDelete.nextInt();
                        int coordX = pawnToDelete.nextInt();
                        int coordY = pawnToDelete.nextInt();
                        pawnDeletionPositionList.add(new PawnDeletionPossition(colorNum,coordX,coordY,serialNum));
                    }
                }
            }
            pawnDeletionPositionList.trimToSize();
        }
    }
    
    public class PawnDeletionPossition  
    {

        private int pawnColorNumber;
        private int xPosCoord;
        private int yPosCoord;
        private int deletionTime;

        public int getDeletionTime() {
            return deletionTime;
        }

        public PawnDeletionPossition(int pawnColorNumber, int xPosCoord, int yPosCoord, int deletionTime) {
            this.pawnColorNumber = pawnColorNumber;
            this.xPosCoord = xPosCoord;
            this.yPosCoord = yPosCoord;
            this.deletionTime = deletionTime;
        }

        
        public int getYPosCoord() {
            return yPosCoord;
        }

        public int getXPosCord() {
            return xPosCoord;
        }

        public int getPawnColorNumber() {
            return pawnColorNumber;
        }

    }
    
}
