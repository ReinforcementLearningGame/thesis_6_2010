/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class BoardPixel {
    private int posX;
    private int posY;
    private int bDel[][];
    private int wDel[][];
    private int bPass[][];
    private int wPass[][];

    public BoardPixel(int posX, int posY) {
        this.posX = posX;
        this.posY = posY;
    }

    public int[][] getbPass() {
        return bPass;
    }

    public int getPosX() {
        return posX;
    }

    public int getPosY() {
        return posY;
    }

    public int[][] getwPass() {
        return wPass;
    }

    public void addBlackDeletion(int trajectoryIndex, int deletionTime){
        if(bDel!=null){
            int[][] bDellTemp = bDel;
            bDel=new int[bDellTemp.length+1][2];
            for(int i=0;i<bDellTemp.length;i++){
                bDel[i][0]=bDellTemp[i][0];
                bDel[i][1]=bDellTemp[i][1];
            }
        }
        else{
            bDel=new int[1][2];
        }
        bDel[bDel.length-1][0]=trajectoryIndex;
        bDel[bDel.length-1][1]=deletionTime;
    }

    public void addWhiteDeletion(int trajectoryIndex, int deletionTime){
        if(wDel!=null){
            int[][] wDellTemp = wDel;
            wDel=new int[wDellTemp.length+1][2];
            for(int i=0;i<wDellTemp.length;i++){
                wDel[i][0]=wDellTemp[i][0];
                wDel[i][1]=wDellTemp[i][1];
            }
        }
        else{
            wDel=new int[1][2];
        }
        wDel[wDel.length-1][0]=trajectoryIndex;
        wDel[wDel.length-1][1]=deletionTime;
    }

    public void addBlackPass(int trajectoryIndex, int passTime){
        if(bPass!=null){
            int[][] bPassTemp = bPass;
            bPass=new int[bPassTemp.length+1][2];
            for(int i=0;i<bPassTemp.length;i++){
                bPass[i][0]=bPassTemp[i][0];
                bPass[i][1]=bPassTemp[i][1];
            }
        }
        else{
            bPass=new int[1][2];
        }
        bPass[bPass.length-1][0]=trajectoryIndex;
        bPass[bPass.length-1][1]=passTime;
    }

    public void addWhitePass(int trajectoryIndex, int passTime){
        if(wPass!=null){
            int[][] wPassTemp = wPass;
            wPass=new int[wPassTemp.length+1][2];
            for(int i=0;i<wPassTemp.length;i++){
                wPass[i][0]=wPassTemp[i][0];
                wPass[i][1]=wPassTemp[i][1];
            }
        }
        else{
            wPass=new int[1][2];
        }
        wPass[wPass.length-1][0]=trajectoryIndex;
        wPass[wPass.length-1][1]=passTime;
    }

}
