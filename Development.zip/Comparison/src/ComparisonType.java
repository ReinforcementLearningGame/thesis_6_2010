
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class ComparisonType
{
    private boolean newGameSelection;
    private Game prospectiveSimilarGame;
    private double cmpMeasure1;
    private double cmpMeasure2;
    private ArrayList result;

    public ComparisonType() {
        prospectiveSimilarGame = new Game();
        result = new ArrayList(0);
        newGameSelection=true;
    }

    public boolean isNewGameSelection() {
        return newGameSelection;
    }

    public void setNewGameSelection(boolean newGameSelection) {
        this.newGameSelection = newGameSelection;
    }

    public ArrayList getResult() {
        return result;
    }

    public void setResult(ArrayList result) {
        this.result = result;
    }

    public double getCmpMeasure1() {
        return cmpMeasure1;
    }

    public void setCmpMeasure1(double cmpMeasure) {
        this.cmpMeasure1 = cmpMeasure;
    }

    public double getCmpMeasure2() {
        return cmpMeasure2;
    }

    public void setCmpMeasure2(double cmpMeasure) {
        this.cmpMeasure2 = cmpMeasure;
    }

    public Game getProspectiveSimilarGame() {
        return prospectiveSimilarGame;
    }

    public void setProspectiveSimilarGame(Game prospectiveSimilarGame) {
        this.prospectiveSimilarGame = prospectiveSimilarGame;
    }

    public boolean selectProspectiveSimilarGameFile(File similarGameFile){
        prospectiveSimilarGame.setGameFile(similarGameFile);
        try {
            prospectiveSimilarGame.setFileSrvs(new FileServices(prospectiveSimilarGame.getGameFile()));
        } catch (IOException ex) {
            Logger.getLogger(ComparisonType.class.getName()).log(Level.SEVERE, null, ex);
        }
        if((prospectiveSimilarGame.getFileSrvs().getFNaneAnalyzer().getGameDimboard() != ComparisonFrame.comparisonFrame.getMainGame().getFileSrvs().getFNaneAnalyzer().getGameDimboard()) || (prospectiveSimilarGame.getFileSrvs().getFNaneAnalyzer().getGameDimbase() != ComparisonFrame.comparisonFrame.getMainGame().getFileSrvs().getFNaneAnalyzer().getGameDimbase()))
            return false;
        prospectiveSimilarGame.getFileSrvs().getMovementList().clear();
        prospectiveSimilarGame.getFileSrvs().readRecordsToMakeList();
        prospectiveSimilarGame.getWhiteTrajectories().clear();
        prospectiveSimilarGame.getBlackTrajectories().clear();
        prospectiveSimilarGame.getFileSrvs().estimateLostPawns();

        prospectiveSimilarGame.setPawnDeletionPossitionList(null);
        prospectiveSimilarGame.splitPawnTrajectories(0);
        prospectiveSimilarGame.splitPawnTrajectories(1);
        Trajectory wTrajectory = Trajectory.trajectoryListRedistribution(prospectiveSimilarGame.getWhiteTrajectories());
        Trajectory bTrajectory = Trajectory.trajectoryListRedistribution(prospectiveSimilarGame.getBlackTrajectories());
        prospectiveSimilarGame.setWhiteTrajectories(wTrajectory);
        prospectiveSimilarGame.setBlackTrajectories(bTrajectory);
        return true;
    }
    public File[] selectComparisonFiles(String comparisonDirectoryName){
        File comparisonDirectory = new File(comparisonDirectoryName);
        ArrayList cmpFls= new ArrayList(0);
        int j = 0;
        File[] possibleComparisonFiles = comparisonDirectory.listFiles();
        if(possibleComparisonFiles.length==0)
        {
            JOptionPane.showMessageDialog(ComparisonFrame.comparisonFrame, "<html><font color=\"#006666\">The comparison direcrory is empty. Click<br/> on Tools --> Options to select another.</font>", "Comparison directory error", JOptionPane.WARNING_MESSAGE);
            return possibleComparisonFiles;
        }
        for(int i=0;i<possibleComparisonFiles.length;i++)
        {
            if(possibleComparisonFiles[i].isFile())
            {
                if(possibleComparisonFiles[i].getName().matches("([a-zA-Z]{3}\\s){2}(\\d{2}\\s){3}\\d{2}_\\S+_(\\d{1,2}_){3}game_\\d{1,10}\\."+ComparisonFrame.comparisonFrame.getMainGame().getFileType().getExtensions()[0].toString()))
                {
                    cmpFls.add(j, possibleComparisonFiles[i]);
                    j++;
                }
            }
        }
        //System.out.print("\n"+cmpFls.size()+"\n");
        File[] comparisonFiles = new File[cmpFls.size()];
        for(int k=0; k<cmpFls.size(); k++)
            comparisonFiles[k]=(File)cmpFls.get(k);
        if(comparisonFiles.length==0)
        {
            JOptionPane.showMessageDialog(ComparisonFrame.comparisonFrame, "<html><font color=\"#006666\">The comparison direcrory has no game files.<br/>Click on Tools --> Options to select another.</font>", "Comparison directory error", JOptionPane.WARNING_MESSAGE);
            return comparisonFiles;
        }
        return comparisonFiles;
    }

    public class SingleResultInfo
    {

        private File similarFile;
        private int commonPointsNum;
        private double includedVolume;
        private double whiteBoardDeviation;
        private double blackBoardDeviation;
        private double similarityMeasure1;
        private double similarityMeasure2;
        private int moveTime;
        private double movementVariationPercentage;

        public SingleResultInfo(File similarFile, int commonPointsNum, double includedVolume, double similarityMeasure1, double similarityMeasure2, int moveTime) {
            this.similarFile = similarFile;
            this.commonPointsNum = commonPointsNum;
            this.includedVolume = includedVolume;
            this.similarityMeasure1 = similarityMeasure1;
            this.similarityMeasure2 = similarityMeasure2;
            this.moveTime = moveTime;
        }

        public SingleResultInfo(File similarFile, double whiteBoardDeviation, double blackBoardDeviation, double similarityMeasure1, double similarityMeasure2, int moveTime, double movementVariationPercentage) {
            this.similarFile = similarFile;
            this.whiteBoardDeviation = whiteBoardDeviation;
            this.blackBoardDeviation = blackBoardDeviation;
            this.similarityMeasure1 = similarityMeasure1;
            this.similarityMeasure2 = similarityMeasure2;
            this.moveTime = moveTime;
            this.movementVariationPercentage = movementVariationPercentage;
        }

        public SingleResultInfo(File similarFile, double winnerBoardDeviation, double similarityMeasure1, double similarityMeasure2, int moveTime, double movementVariationPercentage) {
            this.similarFile = similarFile;
            this.whiteBoardDeviation = winnerBoardDeviation;
            this.similarityMeasure1 = similarityMeasure1;
            this.similarityMeasure2 = similarityMeasure2;
            this.moveTime = moveTime;
            this.movementVariationPercentage = movementVariationPercentage;
        }

        public double getBlackBoardDeviation() {
            return blackBoardDeviation;
        }

        public void setBlackBoardDeviation(double blackBoardDeviation) {
            this.blackBoardDeviation = blackBoardDeviation;
        }

        public double getMovementVariationPercentage() {
            return movementVariationPercentage;
        }

        public void setMovementVariationPercentage(double movementVariationPercentage) {
            this.movementVariationPercentage = movementVariationPercentage;
        }

        public double getWhiteBoardDeviation() {
            return whiteBoardDeviation;
        }

        public void setWhiteBoardDeviation(double whiteBoardDeviation) {
            this.whiteBoardDeviation = whiteBoardDeviation;
        }

         public int getMoveTime() {
            return moveTime;
        }

        public void setMoveTime(int moveTime) {
            this.moveTime = moveTime;
        }

       public double getSimilarityMeasure2() {
            return similarityMeasure2;
        }

        public void setSimilarityMeasure2(int similarityMeasure2) {
            this.similarityMeasure2 = similarityMeasure2;
        }

        public double getSimilarityMeasure1() {
            return similarityMeasure1;
        }

        public void setSimilarityMeasure1(int similarityMeasure1) {
            this.similarityMeasure1 = similarityMeasure1;
        }

        public double getIncludedVolume() {
            return includedVolume;
        }

        public void setIncludedVolume(int includedVolume) {
            this.includedVolume = includedVolume;
        }

        public int getCommonPointsNum() {
            return commonPointsNum;
        }

        public void setCommonPointsNum(int commonPointsNum) {
            this.commonPointsNum = commonPointsNum;
        }

        public File getSimilarFile() {
            return similarFile;
        }

        public void setSimilarFile(File similarFile) {
            this.similarFile = similarFile;
        }

    }

    public SingleResultInfo collectAndStoreInfo(){
        return null;
    }

    public boolean prepareSingleComparison(Game mainGame){
        return false;
    }

    public void estimateComparisonMeasure(){

    }

    public JDialog getSettingsWindow(){
        return null;
    }

    public String printResult(){
        return "NO RESULTS";
    }

}
