/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class CmpType2GBS extends ComparisonType
{

    public CmpType2GBS() {
        //super(mainGame);
    }

}
