
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.*;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class TrajectoryViewer extends JComponent
{
    private int DIMBOARD;
    private int DIMBASE;
    private Dimension minTVSize;
    private int mode=0;
    private MovementList movements;
    
    public TrajectoryViewer(int trajectoryMode, int dimboard, int dimbase, MovementList movementList)
    {
        super();
        DIMBOARD=dimboard;
        DIMBASE=dimbase;
        movements=movementList;
        minTVSize=new Dimension(DIMBOARD*50,DIMBOARD*50);
        mode=trajectoryMode;
        setBackground(new Color(250, 250, 210));
        setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
        setSize(minTVSize);
        setMaximumSize(minTVSize);
        setMinimumSize(minTVSize);
        setPreferredSize(minTVSize);
    }
    
    @Override
    public void paintComponent (Graphics g)
    {
        super.paintComponent(g);
        Graphics2D g2D = null;
        if (g instanceof Graphics2D)
            g2D = (Graphics2D) g;
        else
        return;

        float slope_x = (getSize().width-1)/DIMBOARD;
        float slope_y = (getSize().height-1)/DIMBOARD;

        //paralliles kai kathetes grammes gia tin emfanisi tou board
        g2D.setColor(Color.magenta);
        for (int i=0;i<DIMBOARD+1;i++)
        {
            g2D.drawLine(0,(int)(slope_y*i),(int)slope_x*DIMBOARD,(int)slope_y*i);
            g2D.drawLine((int)(slope_x*i),0,(int)slope_x*i,(int)slope_y*DIMBOARD);
        }

        //xromatise tis baseis
        g2D.setColor(new Color(250, 170, 170));
        g2D.fill3DRect((int)((DIMBOARD-DIMBASE)*slope_x)+2,2,(int)(DIMBASE*slope_x)-3,(int)(slope_y*DIMBASE)-3,true);
        g2D.setColor(new Color(170, 170, 250));
        g2D.fill3DRect(2,(int)((DIMBOARD-DIMBASE)*slope_y)+2,(int)(DIMBASE*slope_x)-3,(int)(DIMBASE*slope_y)-3,true);

        //arithmise ta tetragwna
        g2D.setColor(Color.black);
        for ( int j = 0; j <DIMBOARD; j++ )
        {
            int axeX = (int)((float)j*slope_x);
            int axeY = (int) ((float)j*slope_y);
            g2D.drawString(""+(DIMBOARD-j-1),3,axeY+(slope_y/2));
            g2D.drawString(""+(j),axeX+(slope_x/2),DIMBOARD*50-4-DIMBOARD);
        }
        
        if(movements!=null)
        {
            for(int serialNum=0; serialNum<movements.size(); serialNum++)
            {
                int xCoord = movements.getMovement(serialNum).getPosNextX();
                int yCoord = movements.getMovement(serialNum).getPosNextY();
                int previousX = movements.getMovement(serialNum).getPosPrevX();
                int previousY = movements.getMovement(serialNum).getPosPrevY();
                if(mode==1)
                {
                    if(serialNum%2==0)
                    {
                        g2D.setColor(Color.green);
                        g2D.setStroke(new BasicStroke(3.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                        g2D.drawLine(previousX*50+22, (DIMBOARD-previousY)*50-32, xCoord*50+22, (DIMBOARD-yCoord)*50-32);
                        g2D.fill3DRect(xCoord*50+17, (DIMBOARD-yCoord)*50-37, 10, 10,true);
                    }
                }
                else if(mode==2)
                {
                    if(serialNum%2!=0)
                    {
                        g2D.setColor(Color.orange);
                        g2D.setStroke(new BasicStroke(3.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                        g2D.drawLine(previousX*50+17, (DIMBOARD-previousY)*50-27, xCoord*50+17, (DIMBOARD-yCoord)*50-27);
                        g2D.fill3DRect(xCoord*50+12, (DIMBOARD-yCoord)*50-32, 10, 10,true);
                    }
                }
                else if(mode==3)
                {
                    if(serialNum%2==0)
                    {
                        g2D.setColor(Color.green);
                        g2D.setStroke(new BasicStroke(3.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                        g2D.drawLine(previousX*50+22, (DIMBOARD-previousY)*50-32, xCoord*50+22, (DIMBOARD-yCoord)*50-32);
                        g2D.fill3DRect(xCoord*50+17, (DIMBOARD-yCoord)*50-37, 10, 10,true);
                    }
                    else
                    {
                        g2D.setColor(Color.orange);
                        g2D.setStroke(new BasicStroke(3.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                        g2D.drawLine(previousX*50+17, (DIMBOARD-previousY)*50-27, xCoord*50+17, (DIMBOARD-yCoord)*50-27);
                        g2D.fill3DRect(xCoord*50+12, (DIMBOARD-yCoord)*50-32, 10, 10,true);
                    }
                }
            }
        }
    }
    
}
