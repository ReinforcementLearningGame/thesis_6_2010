// initiates the board, creates squares
public class GameBoard {
  static Square[][] mySquare;
  public GameBoard(int dimBoard,int dimBase){
    mySquare=new Square[dimBoard][dimBoard];
    for (int i=0;i<dimBoard;i++){
      for (int j=0;j<dimBoard;j++){
        mySquare[i][j]=new Square(i,j,dimBoard,dimBase);
      }
    }  
  }
}
