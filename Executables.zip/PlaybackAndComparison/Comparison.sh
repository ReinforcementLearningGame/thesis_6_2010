#!/bin/sh

java -jar Comparison.jar

