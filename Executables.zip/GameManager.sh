#!/bin/sh

java -jar GameManager.jar

