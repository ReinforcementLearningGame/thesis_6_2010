


import java.util.ArrayList;



/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class PawnTrajectory extends ArrayList
{
    
    private int endState=0;
    private int startTime;
    private int endTime;
    
    public void addPosition(int index,int PosX, int PosY, int Time  )
    {
       StepRecord position=new StepRecord( PosX, PosY, Time );
       this.add(index, position);
    }

    public StepRecord getPosition(int index)
    {
        StepRecord position;
        position=(StepRecord)this.get(index);
        return position;
    }

    public class StepRecord
    {
        private int posX;
        private int posY;
        private int stepTime;

        public StepRecord()
        {
            this( -1, -1, -1);
        }

        // initialize a StepRecord
        public StepRecord( int X, int Y, int time)
        {
            setPosX( X );
            setPosY( Y );
            setStepTime(time);
        }


        // set posX x cordinator
        public void setPosX( int X )
        {
            posX = X;
        }

        // get posX x cordinator
        public int getPosX()
        {
            return posX;
        }

        // set posY y cordinator
        public void setPosY( int Y )
        {
            posY = Y;
        }

        // get posY y cordinator
        public int getPosY()
        {
            return posY;
        }

        // set posY y cordinator
        public void setStepTime( int sTime )
        {
            stepTime = sTime;
        }

        // get posY y cordinator
        public int getStepTime()
        {
            return stepTime;
        }
    }

    // set end state
    public void setEndState( int end )
    {
        endState = end;
    }

    // get end state
    public int getEndState()
    {
        return endState;
    }

    // set the serial number of movements that trajectory starts
    public void setStartTime( int start )
    {
        startTime = start;
    }

    // get the serial number of movements that trajectory starts
    public int getStartTime()
    {
        return startTime;
    }

    // set the serial number of movements that trajectory starts
    public void setEndTime( int end )
    {
        endTime = end;
    }

    // get the serial number of movements that trajectory starts
    public int getEndTime()
    {
        return endTime;
    }

    public int getLifeTime()
    {
        return endTime-startTime;
    }

    public int getOwnStartTime()
    {
        if(startTime%2==0)
            return startTime/2;
        else
            return startTime/2+1;
    }

    public int getOwnEndTime()
    {
        if(endTime%2==0)
            return endTime/2;
        else
            return endTime/2+1;
    }

    public int getOwnLifeTime()
    {
        return getOwnEndTime()-getOwnStartTime();
    }
}
