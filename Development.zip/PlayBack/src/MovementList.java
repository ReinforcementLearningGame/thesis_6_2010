
import java.util.ArrayList;


public class MovementList extends ArrayList
{
    public void addMovement(int index,int PrevX, int PrevY, int NextX, int NextY, ArrayList pawnsForDeletion )
    {
       MoveRecord movement=new MoveRecord( PrevX, PrevY, NextX, NextY, pawnsForDeletion );
       this.add(index, movement);
    }
    
    public MoveRecord getMovement(int index)
    {
        MoveRecord movement;
        movement=(MoveRecord)this.get(index);
        return movement;
    }
    
    public class MoveRecord
    {
        private int posPrevX;
        private int posPrevY;
        private int posNextX;
        private int posNextY;
        private ArrayList pawnsToDelete;
        // no-argument constructor calls other constructor with default values
        public MoveRecord()
        {
            this( -1, -1, -1, -1, null);
        } 

        // initialize a MoveRecord
        public MoveRecord( int PrevX, int PrevY, int NextX, int NextY, ArrayList pawnsToDel )
        {
            setPosPrevX( PrevX );
            setPosPrevY( PrevY );
            setPosNextX( NextX );
            setPosNextY( NextY );
            setPawnsToDelete(pawnsToDel);
        }


        // set posX x cordinator   
        public void setPosPrevX( int PrevX )
        {
            posPrevX = PrevX;
        } 

        // get posPrevX x cordinator 
        public int getPosPrevX() 
        { 
            return posPrevX; 
        }

        // set posPrevY y cordinator   
        public void setPosPrevY( int PrevY )
        {
            posPrevY = PrevY;
        }

        // get posPrevY y cordinator 
        public int getPosPrevY() 
        { 
            return posPrevY; 
        } 

         // set posNextX x cordinator   
        public void setPosNextX( int NextX )
        {
            posNextX = NextX;
        } 

        // get posNextX x cordinator 
        public int getPosNextX() 
        { 
            return posNextX; 
        } 

        // set posNextY y cordinator   
        public void setPosNextY( int NextY )
        {
            posNextY = NextY;
        } 

        // get posNextY y cordinator 
        public int getPosNextY() 
        { 
            return posNextY; 
        }
        
        
        public void setPawnsToDelete( ArrayList deletedPawns )
        {
            pawnsToDelete = deletedPawns;
        } 

        
        public ArrayList getPawnsToDelete() 
        { 
            return pawnsToDelete; 
        } 
        

    }
}
    