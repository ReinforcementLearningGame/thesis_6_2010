/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class CmpTypeSWMT extends ComparisonType
{

    public CmpTypeSWMT() {
        //super(mainGame);
    }

}
