#!/bin/sh

java -jar RLGame_H_vs_C.jar

