
import java.util.Random;

//import java.awt.*;


//Spiel is ''game'' in german
public class Spiel implements Common{
    static NeuralNet whiteNeural; //neural net used for the 1st player
    static NeuralNet blackNeural; //neural net used for the 2nd player
    static Pawn[] whitePawn;
    static Pawn[] blackPawn;
    static Position myPosition;
    static StringBuffer myStats=new StringBuffer(); //used for the statistics
    static int inputSize=DIMBOARD*DIMBOARD-2*DIMBASE*DIMBASE+5; //abbreviation
    static history moveLog;


    //**************Added by Dockos************
    static double whiteGamma=0.95;
    static double blackGamma=0.95;
    static double whiteLamda=0.5;
    static double blackLamda=0.5;
   //******************************************


    public Spiel(int gid, int dimBoard,int dimBase,int numOfPawns, String Path) {

      /********************************************/
      /* moveLog = new history(""+gid+".txt");
      Modified by Dockos to */
      moveLog = new history("_cVSc_"+dimBoard+"_"+dimBase+"_"+numOfPawns+"_game_"+Math.abs(new Random().nextInt()),0, Path);
      /*********************************************/

      GameBoard myBoard=new GameBoard(dimBoard,dimBase);
      whitePawn=new Pawn[numOfPawns];
      blackPawn=new Pawn[numOfPawns];
        /*whiteNeural=new NeuralNet(1,2*inputSize,inputSize,1,0.95,0.5);
        blackNeural=new NeuralNet(2,2*inputSize,inputSize,1,0.95,0.5);
        replaced by Dockos to*/
      whiteNeural=new NeuralNet(1,2*inputSize,inputSize,1,whiteGamma,whiteLamda);
      blackNeural=new NeuralNet(2,2*inputSize,inputSize,1,blackGamma,blackLamda);

      Player whitePlayer=new Player(1);
      Player blackPlayer=new Player(2);
      for (int i=0;i<numOfPawns;i++){
        whitePawn[i]=new Pawn(i,true);
        blackPawn[i]=new Pawn(i,false);
      }
      myPosition=new Position(whitePawn,blackPawn);
      int counter=1; //so as not to let a game last forever, the maximum number of moves is 10000

      /*************************************************************************
      int[] whiteDesc=new int[2]; //not used, description of the move made
      int[] blackDesc=new int[2]; //not used, description of the move made
      Modified by Dockos to */
      String[] whiteDesc=new String[4]; //not used, description of the move made
      String[] blackDesc=new String[4]; //not used, description of the move made
      //************************************************************************
int i=0;
      boolean written=false;
      while ((myPosition.isFinal(whitePawn,blackPawn)==false)&&(counter<10000)){
        i++;
          whiteDesc=whitePlayer.pickWhiteMove(PLIES,whitePawn, blackPawn, GameBoard.mySquare);
        appendLog(whiteDesc);
        if (myPosition.isFinal(whitePawn,blackPawn)==false){
         blackDesc=blackPlayer.pickBlackMove(blackPawn,GameBoard.mySquare);
	 appendLog(blackDesc);
        } else {
                  written=true;
                  createStats(""+counter);
                  if (myPosition.getWhiteRemaining(whitePawn) > 0) {
				createStats(" aspros");
			} else createStats(" mavros");
        }
        counter++;
      }
      if ((counter<10000)&&(written==false)){
        createStats(""+ (--counter));
        if (myPosition.getBlackRemaining(blackPawn) > 0) {
		createStats(" mavros");
        } else createStats(" aspros");
      }
      whiteNeural.storeWeights();
      blackNeural.storeWeights();
    }
   
    /***************************************************
    public void appendLog(int[] desc)
    Modified by Dockos to  */
    public void appendLog(String[] desc)
    //**************************************************
    {
	moveLog.writeToFile(""+(Integer.valueOf(desc[0])-1)%DIMBOARD+","+(Integer.valueOf(desc[0])-1)/DIMBOARD+"->"+(Integer.valueOf(desc[1])-1)%DIMBOARD+","+(Integer.valueOf(desc[1])-1)/DIMBOARD+"->"+desc[2]+desc[3]);
    }

    public void createStats(String s)
    {
        myStats.append(s);
        myStats.append("\n");

    }

}
