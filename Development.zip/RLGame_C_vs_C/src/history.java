//records the result and the number of moves

import java.io.*;
import java.util.*;

public class history {
  File file;
  static String Path;
  FileWriter out;
  public history() {
  }
  
  //creates the file, using the time the game started to name it
   /* final void writeToFile(String s,String name){
   Replaced by Dockos to */
   final void writeToFile(String s,String name,int historyType){
    Date myDate=new Date();
    String fileName=name;
    String helpName=myDate.toString();

    /* helpName=helpName.substring(11,19);
    Replaced by Dockos to */
    helpName=helpName.substring(0,19);

    helpName=helpName.replace(':',' ');
    fileName=helpName+fileName;

    //********************************************************
    //fileName=fileName.concat(".txt");
    //file=new File(fileName);
    //Replaced by Dockos to
    if(historyType==0)
    {
        fileName=fileName.concat(".rlg");
        file=new File(Path+File.separatorChar+fileName);
    }
    if(historyType==1)
    {
        fileName=fileName.concat(".txt");
        file=new File(fileName);
    }
    //********************************************************

    try
    {
      out=new FileWriter(file);
      out.write(s);
      out.close();
    }
    catch (IOException e1)
    {
      System.out.println("tin katsame");
    }
  }
}
