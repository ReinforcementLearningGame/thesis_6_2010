/***************
  Created by:  Panagiotis Kanellopoulos
  Modified by: Eirini Ntoutsi
  Operation: Records the result and the number of moves
*******/
import java.io.*;
import java.util.*;
import java.io.FileWriter;
import java.lang.Object.*;

public class history
{
   File file;
   FileWriter out;
   public history(){}

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   //Ftiakse to arxeio kai onomase to me tin ora dimioyrgias tou

   /***********************************************************
   final void writeToFile(String s,String name)
   Replaced by Dockos to */
   final void writeToFile(String s,String name,int historyType)
   //**********************************************************

   {
      Date myDate=new Date();
      String fileName=name;
      String helpName=myDate.toString();

      //********************************************************
      //helpName=helpName.substring(11,19);
      //Replaced by Dockos to
      helpName=helpName.substring(0,19);
      //********************************************************

      helpName=helpName.replace(':',' ');
      fileName=helpName+fileName;
      
      //********************************************************
      //fileName=fileName.concat(".txt");
      //Replaced by Dockos to
      if(historyType==0)
          fileName=fileName.concat(".rlg");
      if(historyType==1)
          fileName=fileName.concat(".txt");
      //********************************************************

      file=new File(fileName);
      try
      {
        out=new FileWriter(file);
        out.write(s);
        out.close();
      }
      catch (IOException e1){System.out.println("error in file "+fileName+".txt");}
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   //kane append se ena idi yparxon arxeio
   final void appendFile(String s,String name)
   {
      String fileName=name;
      try
      {
          out=new FileWriter(name+".txt",true);
          out.write(s);
          out.close();
      }
      catch (IOException e1){System.out.println("error in file "+name+".txt");}
   }
}
//this is the end