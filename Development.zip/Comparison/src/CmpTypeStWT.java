
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;



/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class CmpTypeStWT extends ComparisonType
{
    private int Height;
    private int partialVolume;
    private double Volume=0;
    private PawnTrajectory mainTrajectory;
    private PawnTrajectory prospectiveSimilarTrajectory;
    private ArrayList commonPasses;
    private StWT_Settings settingsWindow;

    public CmpTypeStWT() {
        //super();
        prospectiveSimilarTrajectory = new PawnTrajectory();
        mainTrajectory = new PawnTrajectory();
        settingsWindow = new StWT_Settings(ComparisonFrame.comparisonFrame,true);
    }

    @Override
    public StWT_Settings getSettingsWindow() {
        return settingsWindow;
    }

    public double getVolume() {
        return Volume;
    }

    public void setVolume(int Volume) {
        this.Volume = Volume;
    }

    private void estimateElementalVolume(int prevX, int prevY, int curX, int curY, int curT, boolean mainSection)
    {
        int volume=0;
        if(curY-prevY==0)
        {
            if(mainSection)
                volume = (curX-prevX)*Height*curT;
            else
                volume = (curX-prevX)*Height*curT;
        }
        else
        {
            Height += curY-prevY;
        }
        partialVolume += volume;
    }

    private void commonStartPointCorrection(PawnTrajectory mainTrajectory,PawnTrajectory trajectoryToCompare)
    {
        int Xm = mainTrajectory.getPosition(1).getPosX();
        int Ym = mainTrajectory.getPosition(1).getPosY();
        int Xc = trajectoryToCompare.getPosition(1).getPosX();
        int Yc = trajectoryToCompare.getPosition(1).getPosY();
        mainTrajectory.getPosition(0).setPosX(Math.min(Xm, Xc));
        mainTrajectory.getPosition(0).setPosY(Math.min(Ym, Yc));
        trajectoryToCompare.getPosition(0).setPosX(Math.min(Xm, Xc));
        trajectoryToCompare.getPosition(0).setPosY(Math.min(Ym, Yc));
    }

    private void commonEndPointCorrection(PawnTrajectory mainTrajectory,PawnTrajectory trajectoryToCompare)
    {
        int Xm = mainTrajectory.getPosition(mainTrajectory.size()-2).getPosX();
        int Ym = mainTrajectory.getPosition(mainTrajectory.size()-2).getPosY();
        int Xc = trajectoryToCompare.getPosition(trajectoryToCompare.size()-2).getPosX();
        int Yc = trajectoryToCompare.getPosition(trajectoryToCompare.size()-2).getPosY();
        mainTrajectory.getPosition(mainTrajectory.size()-1).setPosX(Math.max(Xm, Xc));
        mainTrajectory.getPosition(mainTrajectory.size()-1).setPosY(Math.max(Ym, Yc));
        trajectoryToCompare.getPosition(trajectoryToCompare.size()-1).setPosX(Math.max(Xm, Xc));
        trajectoryToCompare.getPosition(trajectoryToCompare.size()-1).setPosY(Math.max(Ym, Yc));
    }

    private void estimateVolume(PawnTrajectory mainTrajectory, PawnTrajectory trajectoryToCompare )
    {
        commonStartPointCorrection(mainTrajectory, trajectoryToCompare);
        commonEndPointCorrection(mainTrajectory, trajectoryToCompare);
        if(settingsWindow.simpleSearchSelection.isSelected())
            commonPasses=searchCommonTrajectoryPasses(mainTrajectory, trajectoryToCompare);
        if(settingsWindow.strictSearchSelection.isSelected())
            commonPasses=searchStrictCommonTrajectoryPasses(mainTrajectory, trajectoryToCompare);
        System.out.print("\n\nTHE NUMBER OF COMMON POINTS IS: "+commonPasses.size()+"\n");
        for(int m=0; m<commonPasses.size()-1; m++)
        {
            commonTrajectoryPass Pos1=(commonTrajectoryPass)commonPasses.get(m);
            commonTrajectoryPass Pos2=(commonTrajectoryPass)commonPasses.get(m+1);
            
            int mainStartTime = mainTrajectory.getPosition(Pos1.getIndexOfTrajectoryA()).getStepTime();
            int toCompareStartTime = trajectoryToCompare.getPosition(Pos1.getIndexOfTrajectoryB()).getStepTime();
            
            partialVolume=0;
            Height=0;
            for(int i=Pos1.getIndexOfTrajectoryA()+1; i<=Pos2.getIndexOfTrajectoryA(); i++)
            {
                int trajectoryATime = mainTrajectory.getPosition(i).getStepTime() - mainStartTime;
                estimateElementalVolume(mainTrajectory.getPosition(i-1).getPosX(), mainTrajectory.getPosition(i-1).getPosY(), mainTrajectory.getPosition(i).getPosX(), mainTrajectory.getPosition(i).getPosY(), trajectoryATime, true);
                System.out.print("\nRefresh Volume = "+partialVolume);
            }
            Height=0;
            for(int j=Pos1.getIndexOfTrajectoryB()+1; j<=Pos2.getIndexOfTrajectoryB(); j++)
            {
                int trajectoryBTime = trajectoryToCompare.getPosition(j).getStepTime() - toCompareStartTime;
                estimateElementalVolume(trajectoryToCompare.getPosition(j-1).getPosX(), trajectoryToCompare.getPosition(j-1).getPosY(), trajectoryToCompare.getPosition(j).getPosX(), trajectoryToCompare.getPosition(j).getPosY(), trajectoryBTime, false);
                System.out.print("\nRefresh Volume = "+partialVolume);
            }
            Volume+=(double)Math.abs(partialVolume);
            System.out.print("\nTHE PARTIAL VOLUME IS: "+partialVolume+"\n");
        }
        System.out.print("\nTHE VOLUME IS: "+Volume);
    }

    public ArrayList searchCommonTrajectoryPasses(PawnTrajectory trajectoryA,PawnTrajectory trajectoryB){
        ArrayList passes=new ArrayList(0);
        passes.clear();
        commonTrajectoryPass pass;
        int l=0;
        int k=0;
        for(int i=0; i<trajectoryA.size(); i++)
        {
            for(int j=l; j<trajectoryB.size(); j++)
            {
                if(trajectoryA.getPosition(i).getPosX()==trajectoryB.getPosition(j).getPosX()&&trajectoryA.getPosition(i).getPosY()==trajectoryB.getPosition(j).getPosY())
                {
                    pass=new commonTrajectoryPass(i,j);
                    passes.add(k, pass);
                    k++;
                    l=j+1;
                    break;
                }
            }
        }
        return passes;
    }

    public ArrayList searchStrictCommonTrajectoryPasses(PawnTrajectory trajectoryA,PawnTrajectory trajectoryB){
        ArrayList passes=new ArrayList(0);
        passes.clear();
        commonTrajectoryPass pass;
        int l=0;
        int k=0;
        int j=0;
        boolean endPoint=false;
        for(int i=0; i<trajectoryA.size(); i++)
        {
            for(j=l; j<trajectoryB.size(); j++)
            {
                if(trajectoryA.getPosition(i).getPosX()==trajectoryB.getPosition(j).getPosX() && trajectoryA.getPosition(i).getPosY()==trajectoryB.getPosition(j).getPosY() &&  trajectoryA.getPosition(i).getStepTime()- trajectoryA.getPosition(0).getStepTime()==trajectoryB.getPosition(j).getStepTime()- trajectoryB.getPosition(0).getStepTime())
                {
                    pass=new commonTrajectoryPass(i,j);
                    passes.add(k, pass);
                    if(i+1==trajectoryA.size() && j+1==trajectoryB.size())
                        endPoint=true;
                    k++;
                    l=j+1;
                    break;
                }
            }
        }
        if(!endPoint)
            passes.add(k, new commonTrajectoryPass(trajectoryA.size()-1,trajectoryB.size()-1));
        return passes;
    }
    
    @Override
    public boolean prepareSingleComparison(Game mainGame){
        if((mainGame.isWhiteWinner() ^ super.getProspectiveSimilarGame().isWhiteWinner()))
            return false;
        if(!mainTrajectory.isEmpty()||super.isNewGameSelection()){
            mainTrajectory.clear();
            //System.out.print("\n"+mainGame.getWinningTrajectory().size()+"\n");
            for(int i=0; i<mainGame.getWinningTrajectory().size(); i++)
                mainTrajectory.addPosition(i, mainGame.getWinningTrajectory().getPosition(i).getPosX(), mainGame.getWinningTrajectory().getPosition(i).getPosY(), mainGame.getWinningTrajectory().getPosition(i).getStepTime());
            mainTrajectory.setEndState(mainGame.getWinningTrajectory().getEndState());
            mainTrajectory.setEndTime(mainGame.getWinningTrajectory().getEndTime());
            mainTrajectory.setStartTime(mainGame.getWinningTrajectory().getStartTime());
            super.setNewGameSelection(false);
        }
        prospectiveSimilarTrajectory.clear();
        prospectiveSimilarTrajectory=super.getProspectiveSimilarGame().getWinningTrajectory();
        if(prospectiveSimilarTrajectory.isEmpty())
        {
            JOptionPane.showMessageDialog(ComparisonFrame.comparisonFrame, "<html><font color=\"#006666\">The selected file for searching similarities has an error.</font>", "File error", JOptionPane.ERROR);
            return false;
        }
        Volume=0;
        estimateVolume(mainTrajectory, prospectiveSimilarTrajectory);
        return true;
    }

    @Override
    public void estimateComparisonMeasure(){
        int dimbase = ComparisonFrame.comparisonFrame.getMainGame().getFileSrvs().getFNaneAnalyzer().getGameDimbase();
        int dimboard = ComparisonFrame.comparisonFrame.getMainGame().getFileSrvs().getFNaneAnalyzer().getGameDimboard();
        /*int dimtime = ComparisonFrame.comparisonFrame.getMainGame().getWinningTrajectory().getOwnLifeTime();*/
        int dimtime =2*(dimboard-dimbase);
        double volumeComparisonPercentage=Math.abs(Volume/(3*dimboard*dimboard*(dimtime)/4-dimboard*dimbase*(dimtime)));
        System.out.print("\nTHE INCLUDED VOLUME PERCENTAGE IS: "+volumeComparisonPercentage);
        if(volumeComparisonPercentage>settingsWindow.volumeComparisonPercentageLimit){
            super.setCmpMeasure1(0);
            super.setCmpMeasure2(0);
            System.out.print("\n");
            return;
        }
        int timeVariation=Math.abs(prospectiveSimilarTrajectory.getOwnLifeTime()-mainTrajectory.getOwnLifeTime());
        int moveVariation=Math.abs(prospectiveSimilarTrajectory.size()-mainTrajectory.size());
        System.out.print("\nTHE TIME VARIATION PERCENTAGE IS: "+((double)timeVariation/(double)mainTrajectory.getOwnLifeTime())+"\n");
        if(((double)timeVariation/(double)mainTrajectory.getOwnLifeTime())>settingsWindow.timeVariationMaxPercentage || ((double)moveVariation/(double)mainTrajectory.size())>settingsWindow.moveVariationMaxPercentage){
            super.setCmpMeasure1(0);
            super.setCmpMeasure2(0);
            return;
        }
        double timeAverange=Math.abs(((double)prospectiveSimilarTrajectory.getOwnLifeTime()+(double)mainTrajectory.getOwnLifeTime())/2);
        if(Volume==0)
        {
            super.setCmpMeasure1(1);
            super.setCmpMeasure2(1);
        }
        else
        {
            super.setCmpMeasure1((1-Math.pow(((double)timeVariation/(settingsWindow.timeVariationMaxPercentage*(double)mainTrajectory.getOwnLifeTime())),2))*(1-Math.pow(((double)moveVariation/(settingsWindow.moveVariationMaxPercentage*(double)mainTrajectory.size())),2))*(1-Math.pow((volumeComparisonPercentage/settingsWindow.volumeComparisonPercentageLimit),2))*(1-Math.exp(-timeAverange/(volumeComparisonPercentage))));
            super.setCmpMeasure2((1-Math.pow(((double)timeVariation/(settingsWindow.timeVariationMaxPercentage*(double)mainTrajectory.getOwnLifeTime())),2))*(1-Math.pow(((double)moveVariation/(settingsWindow.moveVariationMaxPercentage*(double)mainTrajectory.size())),2))*(1-Math.pow((volumeComparisonPercentage/settingsWindow.volumeComparisonPercentageLimit),2))*(1-Math.exp(-timeAverange/(Math.abs(Volume)))));
        }
        System.out.print("\nTHE SIMILARITY MEASURE 1 IS: "+super.getCmpMeasure1());
        System.out.print("\nTHE SIMILARITY MEASURE 2 IS: "+super.getCmpMeasure2()+"\n");
    }

    @Override
    public SingleResultInfo collectAndStoreInfo(){
        SingleResultInfo resultInfo = new SingleResultInfo(super.getProspectiveSimilarGame().getGameFile(),this.commonPasses.size()-2,this.Volume,super.getCmpMeasure1(),super.getCmpMeasure2(),super.getProspectiveSimilarGame().getWinningTrajectory().getOwnLifeTime());
        return resultInfo;
    }

    @Override
    public String printResult(){
        String result="";
        result += "\n\t\t\tFOUND "+this.getResult().size()+" SIMILAR GAMES\n";
        result += "\n\tFile Name\t\tCommon Points\tIncluded Volume\tTime\tSimilarity Measure 1\tSimilarity Measure 2\n";
        ComparisonType.SingleResultInfo rslt;
        for(int i=0; i<this.getResult().size(); i++){
            rslt = (ComparisonType.SingleResultInfo)this.getResult().get(i);
            result += String.format("%s\t        %d\t     %4.1f\t  %d\t         %.5f\t         %.5f\n", rslt.getSimilarFile().getName(),rslt.getCommonPointsNum(),rslt.getIncludedVolume(),rslt.getMoveTime(),rslt.getSimilarityMeasure1(),rslt.getSimilarityMeasure2());
        }
        return result;
    }

    public class commonTrajectoryPass
    {
        private int indexOfTrajectoryA;
        private int indexOfTrajectoryB;

        public commonTrajectoryPass(int indexOfTrajectoryA, int indexOfTrajectoryB) {
            setIndexOfTrajectoryA(indexOfTrajectoryA);
            setIndexOfTrajectoryB(indexOfTrajectoryB);
        }

        public int getIndexOfTrajectoryA() {
            return indexOfTrajectoryA;
        }

        public void setIndexOfTrajectoryA(int indexOfTrajectoryA) {
            this.indexOfTrajectoryA = indexOfTrajectoryA;
        }

        public int getIndexOfTrajectoryB() {
            return indexOfTrajectoryB;
        }

        public void setIndexOfTrajectoryB(int indexOfTrajectoryB) {
            this.indexOfTrajectoryB = indexOfTrajectoryB;
        }

    }

    public class StWT_Settings extends JDialog {

        public StWT_Settings(Frame parent, boolean modal) {
            super(parent, modal);
            initComponents();
            volumePercentageTextField.setText(String.valueOf(volumeComparisonPercentageLimit));
            timeVariationPercentageTextField.setText(String.valueOf(timeVariationMaxPercentage));
            moveVariationPercentageTextField.setText(String.valueOf(moveVariationMaxPercentage));
        }

        private void controlJTextFieldAndItsDoubleValue(JTextField textField, double fieldValue, double defaultValue, double minValue, double maxvalue, String messageTitle, String paramName){
            try
            {
                if(textField.getText().isEmpty())
                {
                    fieldValue=defaultValue;
                    textField.setText(Double.toString(fieldValue));
                }
                else
                {
                    double a =Double.valueOf(textField.getText());
                    if(a<=minValue || a>maxvalue)
                    {
                        JOptionPane.showMessageDialog(this, "Invalid number of "+paramName+". The system will set it to default.", messageTitle, JOptionPane.WARNING_MESSAGE, new ImageIcon(getClass().getResource("images/setinterface.png")));
                        fieldValue=defaultValue;
                        textField.setText(String.valueOf(fieldValue));
                    }
                    else fieldValue=a;
                }
                System.out.print(fieldValue);

            }
            catch(java.util.InputMismatchException IME)
            {
            JOptionPane.showMessageDialog(this, "InputMismatchException. The system will set "+paramName+" number to default.", messageTitle, JOptionPane.WARNING_MESSAGE, new ImageIcon(getClass().getResource("images/setinterface.png")));
            fieldValue=defaultValue;
            textField.setText(String.valueOf(defaultValue));
            System.out.print(fieldValue);
            }
            catch(java.util.NoSuchElementException NSE)
            {
            JOptionPane.showMessageDialog(this, "NoSuchElementException. The system will set "+paramName+" number to default.", messageTitle, JOptionPane.WARNING_MESSAGE, new ImageIcon(getClass().getResource("images/setinterface.png")));
            fieldValue=defaultValue;
            textField.setText(String.valueOf(defaultValue));
            System.out.print(fieldValue);
            }
            catch(IllegalStateException ISE)
            {
            JOptionPane.showMessageDialog(this, "IllegalStateException. The system will set "+paramName+" number to default.", messageTitle, JOptionPane.WARNING_MESSAGE, new ImageIcon(getClass().getResource("images/setinterface.png")));
            fieldValue=defaultValue;
            textField.setText(String.valueOf(defaultValue));
            System.out.print(fieldValue);
            }
        }

        private void initComponents() {
            buttonGroup1 = new ButtonGroup();
            basePanel = new JPanel();
            settingsPanel = new JPanel();
            jLabel1 = new JLabel();
            jLabel2 = new JLabel();
            jLabel3 = new JLabel();
            volumePercentageTextField = new JTextField();
            timeVariationPercentageTextField = new JTextField();
            moveVariationPercentageTextField = new JTextField();
            OKButton = new JButton();
            simpleSearchSelection = new JCheckBox();
            strictSearchSelection = new JCheckBox();

            setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
            setTitle("\"Spatiotemporal Winning Trajectory\" comparison settings");
            setIconImage(new ImageIcon(getClass().getResource("/images/options_small.png")).getImage());
            setResizable(false);
            /*addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
            noTypeSelectionMessage(evt);
            }
            });*/

            basePanel.setBackground(new java.awt.Color(231, 241, 241));
            basePanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
            basePanel.setPreferredSize(new Dimension(410, 372));
            basePanel.setRequestFocusEnabled(false);
            basePanel.setLayout(new BorderLayout());

            settingsPanel.setBackground(new java.awt.Color(182, 208, 208));
            settingsPanel.setBorder(BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(231, 241, 241), new java.awt.Color(0, 102, 102), new java.awt.Color(0, 102, 102), new java.awt.Color(231, 241, 241)), "StWT COMPARISON SETTINGS", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 14), new java.awt.Color(0, 102, 102))); // NOI18N
            settingsPanel.setPreferredSize(new Dimension(350, 332));

            jLabel1.setFont(jLabel1.getFont().deriveFont(jLabel1.getFont().getSize()+1f));
            jLabel1.setForeground(new Color(0, 51, 51));
            jLabel1.setText("Spatiotemporal Volume Percentage Limit:");

            jLabel2.setFont(jLabel2.getFont().deriveFont(jLabel2.getFont().getSize()+1f));
            jLabel2.setForeground(new java.awt.Color(0, 51, 51));
            jLabel2.setText("Time Variation Max Percentage:");

            jLabel3.setFont(jLabel3.getFont().deriveFont(jLabel3.getFont().getSize()+1f));
            jLabel3.setForeground(new java.awt.Color(0, 51, 51));
            jLabel3.setText("Move Variation Max Percentage:");

            buttonGroup1.add(simpleSearchSelection);
            simpleSearchSelection.setFont(simpleSearchSelection.getFont().deriveFont(simpleSearchSelection.getFont().getSize()+1f));
            simpleSearchSelection.setForeground(new Color(0, 51, 51));
            simpleSearchSelection.setBackground(new java.awt.Color(182, 208, 208));
            simpleSearchSelection.setSelected(true);
            simpleSearchSelection.setText("Search for spatial common points");

            buttonGroup1.add(strictSearchSelection);
            strictSearchSelection.setFont(strictSearchSelection.getFont().deriveFont(strictSearchSelection.getFont().getSize()+1f));
            strictSearchSelection.setForeground(new Color(0, 51, 51));
            strictSearchSelection.setBackground(new java.awt.Color(182, 208, 208));
            strictSearchSelection.setText("Search for spatiotemporal common points");

            volumePercentageTextField.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                    volumePercentageTextFieldActionPerformed(evt);
                }
            });
            volumePercentageTextField.addFocusListener(new FocusAdapter() {
                @Override
                public void focusLost(FocusEvent evt) {
                    areaPercentageTextFieldFocusLost(evt);
                }
            });

            timeVariationPercentageTextField.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                    timeVariationPercentageTextFieldActionPerformed(evt);
                }
            });
            timeVariationPercentageTextField.addFocusListener(new FocusAdapter() {
                @Override
                public void focusLost(FocusEvent evt) {
                    timeVariationPercentageTextFieldFocusLost(evt);
                }
            });

            moveVariationPercentageTextField.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                    moveVariationPercentageTextFieldActionPerformed(evt);
                }
            });
            moveVariationPercentageTextField.addFocusListener(new FocusAdapter() {
                @Override
                public void focusLost(FocusEvent evt) {
                    moveVariationPercentageTextFieldFocusLost(evt);
                }
            });

            OKButton.setFont(OKButton.getFont().deriveFont(OKButton.getFont().getSize()+2f));
            OKButton.setForeground(new java.awt.Color(0, 51, 51));
            OKButton.setIcon(new ImageIcon(getClass().getResource("/images/dialog-ok.png")));
            OKButton.setText(" O K");
            OKButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                    OKButtonActionPerformed(evt);
                }
            });

            GroupLayout settingsPanelLayout = new GroupLayout(settingsPanel);
            settingsPanel.setLayout(settingsPanelLayout);
            settingsPanelLayout.setHorizontalGroup(
                settingsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(settingsPanelLayout.createSequentialGroup()
                    .addGap(32, 32, 32)
                    .addGroup(settingsPanelLayout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                        .addComponent(OKButton)
                        .addGroup(settingsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addComponent(simpleSearchSelection)
                            .addComponent(strictSearchSelection)
                            .addGroup(settingsPanelLayout.createSequentialGroup()
                                .addGroup(settingsPanelLayout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel1))
                                .addGap(18, 18, 18)
                                .addGroup(settingsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                    .addComponent(moveVariationPercentageTextField, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                    .addComponent(timeVariationPercentageTextField, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                    .addComponent(volumePercentageTextField, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)))))
                    .addContainerGap(30, Short.MAX_VALUE))
            );
            settingsPanelLayout.setVerticalGroup(
                settingsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(settingsPanelLayout.createSequentialGroup()
                    .addGap(32, 32, 32)
                    .addGroup(settingsPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1)
                        .addComponent(volumePercentageTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(settingsPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2)
                        .addComponent(timeVariationPercentageTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(settingsPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3)
                        .addComponent(moveVariationPercentageTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                    .addGap(30, 30, 30)
                    .addComponent(simpleSearchSelection)
                    .addComponent(strictSearchSelection)
                    .addGap(30, 30, 30)
                    .addComponent(OKButton)
                    .addContainerGap(30, Short.MAX_VALUE))
            );

            basePanel.add(settingsPanel, BorderLayout.CENTER);

            getContentPane().add(basePanel, BorderLayout.CENTER);

            pack();
        }

        /*private void noTypeSelectionMessage(java.awt.event.WindowEvent evt) {
        if(areaComparisonPercentageLimit==0)
        JOptionPane.showMessageDialog(this, "<html><font color=\"#006666\">There is no directory selected. Prompt again to select one.</font>", "Options Window", JOptionPane.WARNING_MESSAGE);
        }*/

        private void volumePercentageTextFieldActionPerformed(ActionEvent evt) {
            controlJTextFieldAndItsDoubleValue(volumePercentageTextField, volumeComparisonPercentageLimit, 0.3, 0.0, 1.0, "Area Percentage Limit", "Area percentage limit");
        }

        private void timeVariationPercentageTextFieldActionPerformed(ActionEvent evt) {
            controlJTextFieldAndItsDoubleValue(timeVariationPercentageTextField, timeVariationMaxPercentage, 0.2, 0.0, 1.0, "Time Variation Max Percentage", "Time variation max percentage");
        }

        private void moveVariationPercentageTextFieldActionPerformed(ActionEvent evt) {
            controlJTextFieldAndItsDoubleValue(moveVariationPercentageTextField, moveVariationMaxPercentage, 0.2, 0.0, 1.0, "Move Variation Max Percentage", "Move variation max percentage");
        }

        private void areaPercentageTextFieldFocusLost(FocusEvent evt) {
            controlJTextFieldAndItsDoubleValue(volumePercentageTextField, volumeComparisonPercentageLimit, 0.3, 0.0, 1.0, "Area Percentage Limit", "Area percentage limit");
        }

        private void timeVariationPercentageTextFieldFocusLost(FocusEvent evt) {
            controlJTextFieldAndItsDoubleValue(timeVariationPercentageTextField, timeVariationMaxPercentage, 0.2, 0.0, 1.0, "Time Variation Max Percentage", "Time variation max percentage");
        }

        private void moveVariationPercentageTextFieldFocusLost(FocusEvent evt) {
            controlJTextFieldAndItsDoubleValue(moveVariationPercentageTextField, moveVariationMaxPercentage, 0.2, 0.0, 1.0, "Move Variation Max Percentage", "Move variation max percentage");
        }

        private void OKButtonActionPerformed(ActionEvent evt) {
            volumePercentageTextFieldActionPerformed(evt);
            timeVariationPercentageTextFieldActionPerformed(evt);
            moveVariationPercentageTextFieldActionPerformed(evt);
            volumeComparisonPercentageLimit = Double.valueOf(volumePercentageTextField.getText());
            timeVariationMaxPercentage = Double.valueOf(timeVariationPercentageTextField.getText());
            moveVariationMaxPercentage = Double.valueOf(moveVariationPercentageTextField.getText());
            ComparisonFrame.comparisonFrame.recompareConf();
            setVisible(false);
        }

        private double volumeComparisonPercentageLimit=0.3;
        private double timeVariationMaxPercentage=0.2;
        private double moveVariationMaxPercentage=0.2;
        private JButton OKButton;
        private JTextField volumePercentageTextField;
        private JTextField timeVariationPercentageTextField;
        private JTextField moveVariationPercentageTextField;
        private JPanel basePanel;
        private JLabel jLabel1;
        private JLabel jLabel2;
        private JLabel jLabel3;
        private JPanel settingsPanel;
        private JCheckBox simpleSearchSelection;
        private JCheckBox strictSearchSelection;
        private ButtonGroup buttonGroup1;

    }

}
