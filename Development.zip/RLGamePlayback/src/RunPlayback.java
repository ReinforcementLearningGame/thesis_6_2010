
import javax.swing.ToolTipManager;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class RunPlayback {

    public static void main(String args[]) {
        ToolTipManager.sharedInstance().setDismissDelay(20000);
        final PlaybackFrame playbackFrame = new PlaybackFrame();
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                playbackFrame.setVisible(true);
            }
        });
    }
}
