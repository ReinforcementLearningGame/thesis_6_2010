
public class Position implements Cloneable,Common{
  //******Added by Dockos************
  static double whiteReward=100;
  static double blackReward=100;
  //*********************************
  private double currentWValue;
  private double currentBValue;
  private double currentWWInd;
  private double currentWBInd;
  private double currentBWInd;
  private double currentBBInd;
  private double[] whiteIndex;
  private double[] blackIndex;
  private int whiteRemaining;
  private int aux=0;
  private int blackRemaining;
  private double whitePawnId;
  private double blackPawnId;
  Pawn[] whitePawns;
  Pawn[] blackPawns;
  private Pawn[] cloneWhite=new Pawn[NUMOFPAWNS];
  private Pawn[] cloneBlack=new Pawn[NUMOFPAWNS];
  private Pawn[] sortWhite=new Pawn[NUMOFPAWNS];
  private Pawn[] sortBlack=new Pawn[NUMOFPAWNS];
  private Square[][] cloneSquare;
  private int xxx;private int yyy;

  //Added by Dockos for saving the coordinates of deleted pawns
  private String positionOfDeletedPawns="";

  public Position (Pawn[] wh_Pawns,Pawn[] bl_Pawns) {
    whitePawns=wh_Pawns;
    blackPawns=bl_Pawns;
    currentWValue=0;
    currentBValue=0;
    currentWWInd=0;
    currentWBInd=0;
    currentBWInd=0;
    currentBBInd=0;
  }
   
//check how many white pawns are still alive
   public final int getWhiteRemaining(Pawn[] helpPawns){
    whiteRemaining=0;
    for (int i=0;i<NUMOFPAWNS;i++){
       if (helpPawns[i].isAlive()) whiteRemaining++;
    }
    return whiteRemaining;
  }

//check how many black pawns are still alive
  public final int getBlackRemaining(Pawn[] helpPawns){
    blackRemaining=0;
    for (int i=0;i<NUMOFPAWNS;i++){
      if (helpPawns[i].isAlive()) blackRemaining++;
    }
    return blackRemaining;
  }

//get all legal moves for white player
  public final Square[][] getAllMovesForWhitePlayer(Square[][] outSquare){
    Square[][] helpSquare=new Square[NUMOFPAWNS][1];
    for (int i=0;i<NUMOFPAWNS;i++){
      helpSquare[i]=whitePawns[i].getLegitMovesForWhitePawn(outSquare);
    }
    return helpSquare;
  }

//get all legal moves for black player
  public final Square[][] getAllMovesForBlackPlayer(Square[][] outSquare){
    Square[][] helpSquare=new Square[NUMOFPAWNS][1];
    for (int i=0;i<NUMOFPAWNS;i++){
      helpSquare[i]=blackPawns[i].getLegitMovesForBlackPawn(outSquare);
    }
    return helpSquare;
  }

//check for winner
  public final boolean isFinal(Pawn[] wPawns,Pawn[] bPawns){
    boolean  answer=false;
    int whiteLeft=getWhiteRemaining(wPawns);
    int blackLeft=getBlackRemaining(bPawns);
    if ((whiteLeft==0)||(blackLeft==0))
      answer=true;
    else{
      for (int i=0;i<NUMOFPAWNS;i++){
        if (wPawns[i].isPawnInEnemyBase()){
          answer=true;
        }
        if (bPawns[i].isPawnInEnemyBase()) {
          answer=true;
        }
      }
    }
    return answer;
  }

//get the value occuring after playing the proposed move in a cloned board
  public final double[] getWValue(int pioni,Square tetr)
  {
    int[] deadWhite;
    int[] deadBlack;
    deadWhite=new int[NUMOFPAWNS];
    deadBlack=new int[NUMOFPAWNS];
    Square dest=(Square)tetr.clone();
    for (int i=0;i<NUMOFPAWNS;i++)
    {
      deadWhite[i]=0;
      deadBlack[i]=0;
    }
    //clone the board
    cloneSquare=new Square[DIMBOARD][DIMBOARD];
    //clone the pawns
    for(int i=0;i<NUMOFPAWNS;i++)
    {
       cloneWhite[i]=(Pawn)whitePawns[i].clone();
       cloneWhite[i].position=(Square)whitePawns[i].position.clone();
       cloneBlack[i]=(Pawn)blackPawns[i].clone();
       cloneBlack[i].position=(Square)blackPawns[i].position.clone();
    }
    for(int i=0;i<DIMBOARD;i++)
    {
       for(int j=0;j<DIMBOARD;j++)
       {
         cloneSquare[i][j]=(Square)GameBoard.mySquare[i][j].clone();
       }
    }
    //move the cloned pawn
    int kk=pioni;
    cloneWhite[kk].movePawn(cloneWhite[kk].position,cloneSquare[dest.xCoord][dest.yCoord]);
    //check for dead
    for(int i=0;i<NUMOFPAWNS;i++)
    {
       if((cloneBlack[i].isAlive())&&(cloneBlack[i].isBlackPawnMovable(cloneSquare)==false))
       {
         deadBlack[i]=1;
       }
      if ((cloneWhite[i].isAlive())&&(cloneWhite[i].isWhitePawnMovable(cloneSquare)==false)){
        deadWhite[i]=1;
      }
    }
    //kill dead pawns
    for (int i=0;i<NUMOFPAWNS;i++)
    {
      if (deadBlack[i]==1)
      {
        cloneBlack[i].killPawn();
      }
      if (deadWhite[i]==1)
      {
        cloneWhite[i].killPawn();
      }
    }
/*SOS*/
    Position clonePosition = new Position(cloneWhite,cloneBlack);
    double cloneReward=clonePosition.getReward(true);
    int whiteLeft=cloneWhite.length;
    Spiel.whiteNeural.pawnsToInput(cloneWhite,cloneBlack);
    double[] ret;
    ret=Spiel.whiteNeural.Response();
//    System.out.println("white response: "+ret[0]);
    ret[0]+=cloneReward;
    return ret;
  }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
  /* Get the value occuring after playing the
     proposed move in a cloned board for BLACK*/
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
  public final double[] getBValue(int pioni,Square tetr)
  {
    Square dest=tetr;
    int[] deadWhite;
    deadWhite=new int[NUMOFPAWNS];
    int[] deadBlack;
    deadBlack=new int[NUMOFPAWNS];
    for(int i=0;i<NUMOFPAWNS;i++)
    {
      deadWhite[i]=0;
      deadBlack[i]=0;
    }
    cloneSquare=new Square[DIMBOARD][DIMBOARD];
    for(int i=0;i<NUMOFPAWNS;i++)
    {
      cloneWhite[i]=(Pawn)whitePawns[i].clone();
      cloneWhite[i].position=(Square)whitePawns[i].position.clone();
      cloneBlack[i]=(Pawn)blackPawns[i].clone();
      cloneBlack[i].position=(Square)blackPawns[i].position.clone();
    }

    for(int i=0;i<DIMBOARD;i++)
       for(int j=0;j<DIMBOARD;j++)
          cloneSquare[i][j]=(Square)GameBoard.mySquare[i][j].clone();

    cloneBlack[pioni].movePawn(cloneBlack[pioni].position,cloneSquare[dest.xCoord][dest.yCoord]);
    for(int i=0;i<NUMOFPAWNS;i++)
    {
       if((cloneWhite[i].isAlive())&&(cloneWhite[i].isWhitePawnMovable(cloneSquare)==false))
       {
          deadWhite[i]=1;
       }
       if ((cloneBlack[i].isAlive())&&(cloneBlack[i].isBlackPawnMovable(cloneSquare)==false))
       {
          deadBlack[i]=1;
       }
    }

    for(int i=0;i<NUMOFPAWNS;i++)
    {
       if(deadWhite[i]==1)
       {
         cloneWhite[i].killPawn();
       }
       if (deadBlack[i]==1)
       {
         cloneBlack[i].killPawn();
       }
    }
/*SOS*/
    Position clonePosition = new Position(cloneWhite,cloneBlack);
    double cloneReward=clonePosition.getReward(false);
    int blackLeft=cloneBlack.length;
    Spiel.blackNeural.pawnsToInput(cloneWhite,cloneBlack);
    double[] ret;
    ret=Spiel.blackNeural.Response();
//    System.out.println("black response: "+ret[0]);
    ret[0]+=cloneReward;
    return ret;
  }

  //*************MODIFIED BY DOCKOS*************
  public final void refreshPosition()
  {
     int[] deadWhite;
     int[] deadBlack;
     deadWhite=new int[NUMOFPAWNS];
     deadBlack=new int[NUMOFPAWNS];

     //Added by Dockos
     Integer x;
     Integer y;

     for(int i=0;i<NUMOFPAWNS;i++)
     {
       deadWhite[i]=0;
       deadBlack[i]=0;
     }
    for(int i=0;i<NUMOFPAWNS;i++)
    {
      if((blackPawns[i].isAlive())&&(blackPawns[i].isBlackPawnMovable(GameBoard.mySquare)==false))
      {
          deadBlack[i]=1;
//          System.out.println("DeaD BlacK = "+blackPawns[i].position.getXCoord()+""+blackPawns[i].position.getYCoord());
      }
      if ((whitePawns[i].isAlive())&&(whitePawns[i].isWhitePawnMovable(GameBoard.mySquare)==false))
      {
          deadWhite[i]=1;
//        System.out.println("DeaD WhitE = "+whitePawns[i].position.getXCoord()+""+whitePawns[i].position.getYCoord());
      }
    }
    for (int i=0;i<NUMOFPAWNS;i++)
    {
      if (deadBlack[i]==1)
      {
        //afora to visual meros
        // Spiel.myVisualBoardFrame.visualBoard.deleteVisualPawn(blackPawns[i].position.getXCoord(),blackPawns[i].position.getYCoord());

        //**********Added by Dockos***********
        if(positionOfDeletedPawns.equals(""))
            setPositionOfDeletedPawns("->d:");
        x = blackPawns[i].position.getXCoord();
        y = blackPawns[i].position.getYCoord();
        positionOfDeletedPawns= positionOfDeletedPawns + "#0*" + x.toString() + "*" + y.toString();
        //************************************

        blackPawns[i].killPawn();
      }
      if (deadWhite[i]==1)
      {
         //afora to visual meros
         // Spiel.myVisualBoardFrame.visualBoard.deleteVisualPawn(whitePawns[i].position.getXCoord(),whitePawns[i].position.getYCoord());

        //**********Added by Dockos***********
        if(positionOfDeletedPawns.equals(""))
            setPositionOfDeletedPawns("->d:");
         x = whitePawns[i].position.getXCoord();
         y = whitePawns[i].position.getYCoord();
         positionOfDeletedPawns= positionOfDeletedPawns + "#1*" + x.toString() + "*" + y.toString();
        //************************************

         whitePawns[i].killPawn();
      }
    }
  }


  public final void setCurrentWValue(double timi){
    currentWValue=timi;
  }
  public final void setCurrentBValue(double timi){
    currentBValue=timi;
  }
  public final double getCurrentWValue(){
    return currentWValue;
  }
  public final double getCurrentBValue(){
    return currentBValue;
  }


// G. Dockos: Replace the 100 value with RunRLGameCvsC.settings.getWhiteReward() or RunRLGameCvsC.settings.getBlackReward()
// D. Kalles: Oct 25,2005
  public final double getReward(boolean asprosCall)
  {
     int whiteLeft=getWhiteRemaining(whitePawns);
     int blackLeft=getBlackRemaining(blackPawns);

    // an i katastasi einai teliki
     if(isFinal(whitePawns,blackPawns))
     {
        if((asprosCall)&&(whiteLeft==0))
           return -whiteReward;
        if((!asprosCall)&&(blackLeft==0))
            return -blackReward;
        return 100;
     }

     // an xasei kapoio pioni
     double portion=1.0/NUMOFPAWNS;
     //gia tis ypoloipew periptoseiw epistrefoume to reward os eksis:
     //briskoyme ti diafora tvn pionion ton dyo antipalon (mporei na exasan kapoia piona)
     //kai tin antistoixoume sto diastima (-100,100)
     int differenceOfPlayersPawns=getWhiteRemaining(whitePawns)-getBlackRemaining(blackPawns);
     double res;
     if(asprosCall)
     {
         res=differenceOfPlayersPawns*portion;
         return res*whiteReward;
     }
     else
     if(!asprosCall)
     {
         res=-differenceOfPlayersPawns*portion;
         return res*blackReward;
     }
     else
        return 0;
  }


/*
// D. Kalles: commented out on Oct 25,2005
  public final double getReward(boolean asprosCall)
  {
     int whiteLeft=getWhiteRemaining(whitePawns);
     int blackLeft=getBlackRemaining(blackPawns);

    // an i katastasi einai teliki
     if(isFinal(whitePawns,blackPawns))
     {
//        System.out.println("========is final=========");
        if((asprosCall)&&(whiteLeft==0))
           return -100;
        if((!asprosCall)&&(blackLeft==0))
            return -100;
        return 100;
     }

// an mporei na kerdisei kapoios apo tous dyo tote timorise tin allo
     if(asprosCall)
     {
        if(canWhiteWin())
        {
          if(canBlackWin())
            return -1;
          else
            return 2;
        }

        if((!canWhiteWin())&&(canBlackWin()))
            return -2;
     }

     if(!asprosCall)
     {
        if(canBlackWin())
        {
          if(canWhiteWin())
            return -1;
          else
            return 2;
        }

        if((!canBlackWin())&&(canWhiteWin()))
            return -2;
     }

     //     if(isNextToFinal(whitePawns,blackPawns)==true)
//        return 1; //before final state reached

     // an xasei kapoio pioni
     double portion=1.0/NUMOFPAWNS;
     //gia tis ypoloipew periptoseiw epistrefoume to reward os eksis:
     //briskoyme ti diafora tvn pionion ton dyo antipalon (mporei na exasan kapoia piona)
     //kai tin antistoixoume sto diastima (-1,1)
     int differenceOfPlayersPawns=getWhiteRemaining(whitePawns)-getBlackRemaining(blackPawns);
     double res;
     if(asprosCall)
     {
         res=differenceOfPlayersPawns*portion;
         return res;
     }
     else
     if(!asprosCall)
     {
         res=-differenceOfPlayersPawns*portion;
         return res;
     }
     else
        return 0;
  }
*/


  public final void setCurrentWInd(double whiteI,double blackI){
    currentWWInd=whiteI;
    currentWBInd=blackI;
  }
  public final double[] getCurrentWInd(){
    double[] aux=new double[2];
    aux[0]=currentWWInd;
    aux[1]=currentWBInd;
    return aux;
  }
  public final void setCurrentBInd(double whiteI,double blackI){
    currentBWInd=whiteI;
    currentBBInd=blackI;
  }
  public final double[] getCurrentBInd(){
    double[] aux=new double[2];
    aux[0]=currentBWInd;
    aux[1]=currentBBInd;
    return aux;
  }

//check if black can win after white's last move
  public final boolean canBlackWin(){
    Square[][] outSquare=new Square[DIMBOARD][DIMBOARD];
    for (int i=0;i<DIMBOARD;i++){
      for (int j=0;j<DIMBOARD;j++){
        outSquare[i][j]=(Square)GameBoard.mySquare[i][j].clone();
      }
    }
    Square[][] helpSquare=new Square[NUMOFPAWNS][1];
    helpSquare=getAllMovesForBlackPlayer(outSquare);
    for (int i=0;i<NUMOFPAWNS;i++)
      for (int j=0;j<2*DIMBASE;j++)
        if (helpSquare[i][j].isInWhiteBase()) return true;
    return false;
  }

//check if white can win after black's last move
  public final boolean canWhiteWin(){
    Square[][] outSquare=new Square[DIMBOARD][DIMBOARD];
    for (int i=0;i<DIMBOARD;i++){
      for (int j=0;j<DIMBOARD;j++){
        outSquare[i][j]=(Square)GameBoard.mySquare[i][j].clone();
      }
    }
    Square[][] helpSquare=new Square[NUMOFPAWNS][1];
    helpSquare=getAllMovesForWhitePlayer(outSquare);
    for (int i=0;i<NUMOFPAWNS;i++)
      for (int j=0;j<2*DIMBASE;j++)
        if (helpSquare[i][j].isInBlackBase()) return true;
    return false;
  }


  public final boolean nextToFinal(Pawn[] wPawns,Pawn[] bPawns)
  {
     boolean  answer=false;
     for(int i=0;i<NUMOFPAWNS;i++)
     {
        if(wPawns[i].isPawnInEnemyBase())
        {
           answer=true;
        }

        if(bPawns[i].isPawnInEnemyBase())
        {
            answer=true;
        }
     }

     return answer;
  }

  //Added by Dockos
  public String getPositionOfDeletedPawns()
  {
      return positionOfDeletedPawns;
  }
  //Added by Dockos
  public void setPositionOfDeletedPawns(String start)
  {
      positionOfDeletedPawns = start;
  }
  
}
