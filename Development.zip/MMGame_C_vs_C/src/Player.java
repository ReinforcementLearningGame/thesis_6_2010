import java.util.*;
//import java.awt.*;

public class Player implements Common{

  //******Added by Dockos************
  static public double eGreedyWhite=0.9;
  //*********************************
  private int id;
  static public double lambda=0.5;
  private double currWValue;
  private double currBValue;
  private double reward;
  private double[] index;
//  Hashtable<String,Double>[] positionsTable = new Hashtable[PLIES];
  HashMap<String,Double>[] positionsTable = new HashMap[PLIES];

  public Player(int ident) {
    for (int i = 0; i < PLIES; i++){
	positionsTable[i] = new HashMap<String,Double>(1000);    
	id=ident;
    }
  }

  public double wMinimax(int depth, Pawn[] whitePawn, Pawn[] blackPawn, Square[][] outSquare, int iPawn, Square iSquare, double a, double b){
      double value = 1000;
      double alpha = a;
      double beta = b;
      String posString;
      Double posValue;
      double wValue;

      if (alpha>=beta) return beta;
      Pawn[] cloneWhite = new Pawn[NUMOFPAWNS];
      Pawn[] cloneBlack = new Pawn[NUMOFPAWNS];
      Square[][] cloneSquare = new Square[DIMBOARD][DIMBOARD];
      Square cloneDestSquare = (Square) iSquare.clone();
      for(int i=0;i<NUMOFPAWNS;i++)
      {
        cloneWhite[i]=(Pawn)whitePawn[i].clone();
        cloneWhite[i].position=(Square)whitePawn[i].position.clone();
        cloneBlack[i]=(Pawn)blackPawn[i].clone();
        cloneBlack[i].position=(Square)blackPawn[i].position.clone();
      }
      for(int i=0;i<DIMBOARD;i++)
      {
        for(int j=0;j<DIMBOARD;j++)
        {
          cloneSquare[i][j]=(Square)outSquare[i][j].clone();
        }
      }
      Position clonePosition = new Position (cloneWhite, cloneBlack);
      wValue = clonePosition.getWValue(iPawn, cloneDestSquare);
      cloneSquare[cloneDestSquare.getXCoord()][cloneDestSquare.getYCoord()].setUnFree();
      cloneSquare[cloneWhite[iPawn].position.getXCoord()][cloneWhite[iPawn].position.getYCoord()].setFree();
      cloneWhite[iPawn].movePawn(cloneWhite[iPawn].position, cloneDestSquare);
      clonePosition.refreshPosition(cloneSquare);
      for(int i=0;i<NUMOFPAWNS;i++)
      {
        if (!cloneWhite[i].isAlive()){
            cloneSquare[cloneWhite[i].position.xCoord][cloneWhite[i].position.yCoord].setFree();
        }
        if (!cloneBlack[i].isAlive()){
            cloneSquare[cloneBlack[i].position.xCoord][cloneBlack[i].position.yCoord].setFree();
        }
      }
      for(int i=0;i<NUMOFPAWNS;i++)
      {
        if ((cloneWhite[i].isAlive()) && (!cloneWhite[i].position.isInWhiteBase())){
            cloneSquare[cloneWhite[i].position.xCoord][cloneWhite[i].position.yCoord].setUnFree();
        }
        if ((cloneBlack[i].isAlive()) && (!cloneBlack[i].position.isInBlackBase())){
            cloneSquare[cloneBlack[i].position.xCoord][cloneBlack[i].position.yCoord].setUnFree();
        }
      }
      posString = positionTag(cloneWhite,cloneBlack);
      posValue = positionsTable[depth].get(posString);
      if (posValue != null) {
        return posValue;
      }
      if (clonePosition.isFinal(cloneWhite,cloneBlack)){
        if (clonePosition.getWhiteRemaining(cloneWhite) == 0) {
			positionsTable[depth].put(posString,new Double(LOSS)); 
        	return LOSS;
        }
        if (clonePosition.getBlackRemaining(cloneBlack) == 0) {
            positionsTable[depth].put(posString, new Double(WIN));
            return WIN;
        }
        for (int i=0;i<NUMOFPAWNS;i++)
        {
             if (cloneWhite[i].isPawnInEnemyBase()){
                positionsTable[depth].put(posString, new Double(WIN));
                return WIN;
            }
        }
/*        for (int i=0;i<NUMOFPAWNS;i++)
        {
            if (cloneBlack[i].isPawnInEnemyBase()){
                positionsTable[depth].put(posString, new Double(LOSS));
                return LOSS;
            }   
        }*/
      }
//      if (depth == 0) return (WIN+LOSS)/2.0; 
      if (depth == 0) return wValue;
      Square[][] helpSquare=new Square[NUMOFPAWNS][2*DIMBASE];
      helpSquare = clonePosition.getAllMovesForBlackPlayer(cloneSquare); // get all legal moves for black
      for (int i=0;i<NUMOFPAWNS;i++){
        for (int j=0;j<2*DIMBASE;j++){
          if ((helpSquare[i][j].xCoord+helpSquare[i][j].yCoord)!=0){
             value = bMinimax(depth-1, cloneWhite, cloneBlack, cloneSquare, i, helpSquare[i][j], alpha, beta);
          }
	  if (value < beta){
		beta = value;
	  }
        }
      }
      positionsTable[depth].put(posString,beta); 
      return beta;
  }

  public double bMinimax(int depth, Pawn[] whitePawn, Pawn[] blackPawn, Square[][] outSquare, int iPawn, Square iSquare, double a, double b){
      double value = -1000;
      double alpha = a;
      double beta = b;
      String posString;
      Double posValue;
//      double wValue;
      if (alpha >= beta) return alpha;

      Pawn[] cloneWhite = new Pawn[NUMOFPAWNS];
      Pawn[] cloneBlack = new Pawn[NUMOFPAWNS];
      Square[][] cloneSquare = new Square[DIMBOARD][DIMBOARD];
      Square cloneDestSquare = (Square) iSquare.clone();
      for(int i=0;i<NUMOFPAWNS;i++)
      {
        cloneWhite[i]=(Pawn)whitePawn[i].clone();
        cloneWhite[i].position=(Square)whitePawn[i].position.clone();
        cloneBlack[i]=(Pawn)blackPawn[i].clone();
        cloneBlack[i].position=(Square)blackPawn[i].position.clone();
      }
      for(int i=0;i<DIMBOARD;i++)
      {
        for(int j=0;j<DIMBOARD;j++)
        {
          cloneSquare[i][j]=(Square)outSquare[i][j].clone();
        }
      }
      Position clonePosition = new Position (cloneWhite, cloneBlack);
//      wValue = clonePosition.getWValue(iPawn, cloneDestSquare);
      cloneSquare[cloneDestSquare.getXCoord()][cloneDestSquare.getYCoord()].setUnFree();
      cloneSquare[cloneBlack[iPawn].position.getXCoord()][cloneBlack[iPawn].position.getYCoord()].setFree();
      cloneBlack[iPawn].movePawn(cloneBlack[iPawn].position, cloneDestSquare);
      clonePosition.refreshPosition(cloneSquare);
      for(int i=0;i<NUMOFPAWNS;i++)
      {
        if (!cloneWhite[i].isAlive()){
            cloneSquare[cloneWhite[i].position.xCoord][cloneWhite[i].position.yCoord].setFree();
        }
        if (!cloneBlack[i].isAlive()){
            cloneSquare[cloneBlack[i].position.xCoord][cloneBlack[i].position.yCoord].setFree();
        }
      }
      for(int i=0;i<NUMOFPAWNS;i++)
      {
        if ((cloneWhite[i].isAlive()) && (!cloneWhite[i].position.isInWhiteBase())){
            cloneSquare[cloneWhite[i].position.xCoord][cloneWhite[i].position.yCoord].setUnFree();
        }
        if ((cloneBlack[i].isAlive()) && (!cloneBlack[i].position.isInBlackBase())){
            cloneSquare[cloneBlack[i].position.xCoord][cloneBlack[i].position.yCoord].setUnFree();
        }
      }
      posString = positionTag(cloneWhite,cloneBlack);
      posValue = positionsTable[depth].get(posString);
      if (posValue != null) {
        return posValue;
      }
      if (clonePosition.isFinal(cloneWhite,cloneBlack)){
            if (clonePosition.getWhiteRemaining(cloneWhite) == 0) {
                positionsTable[depth].put(posString,new Double(LOSS));
                return LOSS;
            }
            if (clonePosition.getBlackRemaining(cloneBlack) == 0) {
                positionsTable[depth].put(posString,new Double(WIN));
                return WIN;
            }
            for (int i=0;i<NUMOFPAWNS;i++)
                    if (cloneWhite[i].isPawnInEnemyBase()){
                        positionsTable[depth].put(posString,new Double(WIN));
                        return WIN;
                    }   
            for (int i=0;i<NUMOFPAWNS;i++)
            {
                    if (cloneBlack[i].isPawnInEnemyBase()){
                        positionsTable[depth].put(posString,new Double(LOSS));
                        return LOSS;
                    }
            }
      }
      if (depth == 0) return (WIN+LOSS)/2.0;
//      if (depth == 0) return wValue;
      Square[][] helpSquare=new Square[NUMOFPAWNS][2*DIMBASE];
      helpSquare = clonePosition.getAllMovesForWhitePlayer(cloneSquare); // get all legal moves for black
      for (int i=0;i<NUMOFPAWNS;i++){
        for (int j=0;j<2*DIMBASE;j++){
          if ((helpSquare[i][j].xCoord+helpSquare[i][j].yCoord)!=0)
			value = wMinimax(depth-1, cloneWhite, cloneBlack, cloneSquare, i, helpSquare[i][j], alpha, beta);
 	  if (value > alpha)
		alpha = value;
        }
      }
      positionsTable[depth].put(posString, alpha); 
      return alpha;
  }

  public String positionTag(Pawn[] whitePawn, Pawn[] blackPawn){
     String answer="";
     int[] whiteIndex = new int[NUMOFPAWNS];
     int[] blackIndex = new int[NUMOFPAWNS];
     int temp, j;
     for(int i=0; i<NUMOFPAWNS;i++){
        whiteIndex[i] = whitePawn[i].pawn2Tag();
        blackIndex[i] = blackPawn[i].pawn2Tag();
     }
     for(int i=1; i<NUMOFPAWNS;i++){
        temp = whiteIndex[i];
        j = i-1;
	while ((j>=0)&&(whiteIndex[j]>temp)){
		whiteIndex[j+1] = whiteIndex[j];
		j = j-1;
        }
	whiteIndex[j+1] = temp;
     }
     for(int i=1; i<NUMOFPAWNS;i++){
        temp = blackIndex[i];
        j = i-1;
	while ((j>=0)&&(blackIndex[j]>temp)){
		blackIndex[j+1] = blackIndex[j];
		j = j-1;
        }
	blackIndex[j+1] = temp;
     }
     for(int i=0; i<NUMOFPAWNS;i++)
	answer+= whiteIndex[i];
     answer+=":";
     for(int i=0; i<NUMOFPAWNS;i++)
	answer+= blackIndex[i];

     return answer;
     

  }

  // computer white plays
  
  /****************************************************************************
  public final int[] pickWhiteMove(int depth, Pawn[] whitePawn, Pawn[] blackPawn, Square[][] outSquare){
  Modified by Dockos to */
  public final String[] pickWhiteMove(int depth, Pawn[] whitePawn, Pawn[] blackPawn, Square[][] outSquare){
  //****************************************************************************
    
    int xx=-1;int yy=-1;
    double maxValue=-1000;
    double value = maxValue;
    double alpha = LOSS;
    double beta = WIN;	
    Pawn[] cloneWhite = new Pawn[NUMOFPAWNS];
    Pawn[] cloneBlack = new Pawn[NUMOFPAWNS];
    Square[][] cloneSquare = new Square[DIMBOARD][DIMBOARD];
    boolean whiteWins; 

    for (int i = 0; i < PLIES; i++){
	positionsTable[i].clear();    
    }


    for(int i=0;i<NUMOFPAWNS;i++)
    {
      cloneWhite[i]=(Pawn)whitePawn[i].clone();
      cloneWhite[i].position=(Square)whitePawn[i].position.clone();
      cloneBlack[i]=(Pawn)blackPawn[i].clone();
      cloneBlack[i].position=(Square)blackPawn[i].position.clone();
    }
    for(int i=0;i<DIMBOARD;i++)
    {
      for(int j=0;j<DIMBOARD;j++)
      {
        cloneSquare[i][j]=(Square)outSquare[i][j].clone();
      }
    }
    
    /*************************************************************************
    String[] selMoveDesc=new String[2];
    Modified by Dockos to */
    String[] selMoveDesc=new String[4];
    //*************************************************************************
    
    Square[][] helpSquare=new Square[NUMOFPAWNS][2*DIMBASE];
    helpSquare = Spiel.myPosition.getAllMovesForWhitePlayer(outSquare); // get all legal moves for white
    whiteWins = Spiel.myPosition.canWhiteWin();
    for (int i=0;i<NUMOFPAWNS;i++){
      for (int j=0;j<2*DIMBASE;j++){
        if ((helpSquare[i][j].xCoord+helpSquare[i][j].yCoord)!=0)
		if (whiteWins)
			value =  wMinimax(0, cloneWhite, cloneBlack, cloneSquare, i, helpSquare[i][j], alpha, beta);
		else 
			value = wMinimax(depth-1, cloneWhite, cloneBlack, cloneSquare, i, helpSquare[i][j], alpha, beta);
        if (value>maxValue) { //if it is the biggest value, keep it
              maxValue=value;
              xx=i;
              yy=j;
        }
      }
    }
    
    /*************************************************************************
    selMoveDesc[0]=String.valueOf(whitePawn[xx].position.square2Tag());
    selMoveDesc[1]=String.valueOf(helpSquare[xx][yy].square2Tag());
    Modified by Dockos to */
    selMoveDesc[0]=String.valueOf(whitePawn[xx].position.square2Tag());
    selMoveDesc[1]=String.valueOf(helpSquare[xx][yy].square2Tag());
    //**************************************************************************
    
    whitePawn[xx].movePawn(whitePawn[xx].position,helpSquare[xx][yy]);
    Spiel.myPosition.refreshPosition(outSquare);

    //*************Added by Dockos************
    selMoveDesc[2]=Double.toString(maxValue);
    selMoveDesc[3]=Spiel.myPosition.getPositionOfDeletedPawns()+"\t";
    Spiel.myPosition.setPositionOfDeletedPawns("");
    //****************************************

    Spiel.whiteNeural.pawnsToInput(Spiel.whitePawn,Spiel.blackPawn);
    reward=Spiel.myPosition.getReward(true);
    boolean setValue =Spiel.myPosition.isFinal(Spiel.whitePawn,Spiel.blackPawn);
    Spiel.whiteNeural.singleStep(reward,setValue);
    return selMoveDesc;	
  }


  //computer black plays
  
  /****************************************************************************
  public final int[] pickBlackMove(Pawn[] blackPawn,Square[][] boutSquare){
    int[] selMoveDesc=new int[2];
  Modified by Dockos to */
  public final String[] pickBlackMove(Pawn[] blackPawn,Square[][] boutSquare){
    String[] selMoveDesc=new String[4];
  //***************************************************************************
    Pawn[] blacPawn=blackPawn;
    Square[][] helpSquare=new Square[NUMOFPAWNS][2*DIMBASE];
    helpSquare=Spiel.myPosition.getAllMovesForBlackPlayer(boutSquare); //get all legal moves for black
    selMoveDesc=blackChooses(blacPawn,helpSquare); //play one of them
    return selMoveDesc;
  }

  //choose a legal move
  
  /****************************************************************************
  private final int[] blackChooses(Pawn[] blacPawn,Square[][] helpSquare){ 
  Modified by Dockos to */
  private final String[] blackChooses(Pawn[] blacPawn,Square[][] helpSquare){
  //***************************************************************************

    int xx=-1;int yy=-1;
    Pawn[] blackPawn=blacPawn;
    double value;
    double maxValue=-1000;
    boolean bestMove;
    Vector possiblePawns=new Vector();
    Vector possibleSquares=new Vector();
    java.util.Date helpDate=new Date();
    Random eSoftDecision=new Random(helpDate.getTime()+2500321);
    double eSoft=eSoftDecision.nextDouble();
    //bestMove=(eSoft<0.9)?true:false;
    //replaced by Dockos to
    bestMove=(eSoft<eGreedyWhite)?true:false;
    index=Spiel.myPosition.getCurrentBInd();
    Random exploreBDecision=new Random(helpDate.getTime()+4000000);
    int moveCounter=0;
    for (int i=0;i<NUMOFPAWNS;i++){
      for (int j=0;j<2*DIMBASE;j++){
        if ((helpSquare[i][j].xCoord+helpSquare[i][j].yCoord)!=0){
          double[] aux=Spiel.myPosition.getBValue(i,helpSquare[i][j]);
          moveCounter++;
          possiblePawns.addElement(new Integer(i));
          possibleSquares.addElement(helpSquare[i][j]);
          value=aux[0];
          if (value>maxValue) {
            maxValue=value;
            xx=i;
            yy=j;
          }
        }
      }
    }
    if (bestMove){
      
      /***************************************
      int[] selMoveDesc=new int[2];
      selMoveDesc[0]=blackPawn[xx].position.square2Tag();
      selMoveDesc[1]=helpSquare[xx][yy].square2Tag();
      Modified by Dockos to */
      String[] selMoveDesc=new String[4];
      selMoveDesc[0]=String.valueOf(blackPawn[xx].position.square2Tag());
      selMoveDesc[1]=String.valueOf(helpSquare[xx][yy].square2Tag());
      //**************************************
      
      blackPawn[xx].movePawn(blackPawn[xx].position,helpSquare[xx][yy]);
      Spiel.myPosition.refreshPosition(GameBoard.mySquare);

      //*************Added by Dockos************
      selMoveDesc[2]=Double.toString(maxValue);
      selMoveDesc[3]=Spiel.myPosition.getPositionOfDeletedPawns()+"\n";
      Spiel.myPosition.setPositionOfDeletedPawns("");
      //****************************************

      Spiel.blackNeural.pawnsToInput(Spiel.whitePawn,Spiel.blackPawn);
      reward=Spiel.myPosition.getReward(false);
      boolean setValue=Spiel.myPosition.isFinal(Spiel.whitePawn,Spiel.blackPawn);
      Spiel.blackNeural.singleStep(reward,setValue);
      return selMoveDesc;
    }
    else {
      Spiel.blackNeural.clearEligTrace();
      double explore=exploreBDecision.nextDouble();
      int target=(int)(explore*moveCounter);
      int chosenPawn=((Integer) possiblePawns.elementAt(target)).intValue();
      Square chosenSquare=(Square)possibleSquares.elementAt(target);
      double[] aux=Spiel.myPosition.getBValue(chosenPawn,chosenSquare);

      /***************************************
      int[] selMoveDesc=new int[2];
      selMoveDesc[0]=blackPawn[chosenPawn].position.square2Tag();
      selMoveDesc[1]=chosenSquare.square2Tag();
      Modified by Dockos to */
      String[] selMoveDesc=new String[4];
      selMoveDesc[0]=String.valueOf(blackPawn[chosenPawn].position.square2Tag());
      selMoveDesc[1]=String.valueOf(chosenSquare.square2Tag());
      //**************************************

      blackPawn[chosenPawn].movePawn(blackPawn[chosenPawn].position,chosenSquare);
      Spiel.myPosition.refreshPosition(GameBoard.mySquare);

      //*************Added by Dockos************
      selMoveDesc[2]=String.valueOf(maxValue);
      selMoveDesc[3]=Spiel.myPosition.getPositionOfDeletedPawns()+"\n";
      Spiel.myPosition.setPositionOfDeletedPawns("");
      //****************************************

      Spiel.blackNeural.setOldOutputNode(aux[0]);
      return selMoveDesc;
    }
  }
}

