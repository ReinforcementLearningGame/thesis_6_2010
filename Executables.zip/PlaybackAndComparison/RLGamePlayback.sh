#!/bin/sh

java -jar RLGamePlayback.jar

