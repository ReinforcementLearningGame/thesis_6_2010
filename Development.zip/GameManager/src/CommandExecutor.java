
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CommandExecutor implements Runnable {

    private byte[] inputBuffer = new byte[8786];
    private byte[] errorBuffer = new byte[1024];

    private Process proc;
    private InputStream procErrorStream;
    private InputStream procInputStream;
    private OutputStream procOutputStream;
    private PrintWriter outputWriter;
    private Thread processThread;
    private Thread iputReaderThread;
    private Thread errorThread;
    private ExecutionProcessor handler;

    private CommandExecutor(ExecutionProcessor executionProcessor, Process p) {

        handler = executionProcessor;
        proc = p;

        procErrorStream = proc.getErrorStream();
        procInputStream = proc.getInputStream();
        procOutputStream = proc.getOutputStream();

        outputWriter = new PrintWriter(procOutputStream, true);

        processThread = new Thread(this);
        iputReaderThread = new Thread(this);
        errorThread = new Thread(this);

        processThread.start();
        iputReaderThread.start();
        errorThread.start();
    }

    public InputStream getProcInputStream() {
        return procInputStream;
    }

    private void processEnded(int exitValue) {
        handler.processEnded(exitValue);
    }

    private void processNewInput(String input) {
        // Handle proc new input..
        handler.processNewInput(input);
    }

    private void processNewError(String error) {
        handler.processNewError(error);
    }

    public static CommandExecutor exec(ExecutionProcessor handler, String path, String command) throws IOException {
        String baseDir = System.getProperty("user.dir");
        ProcessBuilder pb = new ProcessBuilder(baseDir + File.separatorChar + path + File.separatorChar + command);
        File pDir= new File(baseDir + File.separatorChar + path);
        pb.directory(pDir);
        pb.redirectErrorStream(true);
        System.out.print(pb.directory().toString()+"\n");
        Process p = null;
        try {
            p = pb.start();
        } catch (IOException ex) {
            Logger.getLogger(GameManager.class.getName()).log(Level.SEVERE, null, ex);
            System.out.print(ex.getMessage()+"Process failed\n");
        }
        return new CommandExecutor(handler, p);
    }
    
    
    public void print(String output) {
        outputWriter.print(output);
    }

    public void println(String output) {
        outputWriter.println(output);
    }

    @Override
    public void run() {
        String Lc = null;
        if (System.getProperty("os.name").toLowerCase().indexOf( "win" ) >= 0)
        {
            Lc="ibm737";
        }
        else if (System.getProperty("os.name").indexOf( "nix") >=0 || System.getProperty("os.name").indexOf( "nux") >=0)
        {
            Lc="utf8";
        }
        if (processThread == Thread.currentThread()) {
            try {
                processEnded(proc.waitFor());
            } catch (InterruptedException ex) {
                Logger.getLogger(GameManager.class.getName()).log(Level.SEVERE, null, ex);
                System.out.print(ex.getMessage()+"Process interrupted\n");
            }
        } else if (iputReaderThread == Thread.currentThread()) {
            try {
                for (int i = 0; i > -1; i = procInputStream.read(inputBuffer)) {
                    processNewInput(new String(inputBuffer, 0, i, Lc));
                    /*try {
                    iputReaderThread.sleep(10);
                    } catch (InterruptedException ex) {
                    Logger.getLogger(CommandExecutor.class.getName()).log(Level.SEVERE, null, ex);
                    }*/
                }
            } catch (IOException ex) {
                Logger.getLogger(GameManager.class.getName()).log(Level.SEVERE, null, ex);
                System.out.print(ex.getMessage()+"Process failed\n");
            }
        } else if (errorThread == Thread.currentThread()) {
            try {
               for (int i = 0; i > -1; i = procErrorStream.read(errorBuffer)) {
                    processNewError(new String(errorBuffer, 0, i, Lc));
                }
            } catch (IOException ex) {
                Logger.getLogger(GameManager.class.getName()).log(Level.SEVERE, null, ex);
                System.out.print(ex.getMessage()+"Process failed\n");
            }
        }
    }
}