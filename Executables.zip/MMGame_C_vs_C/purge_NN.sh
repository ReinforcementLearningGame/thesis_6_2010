#!/bin/sh

rm -v whVWeights
rm -v whWWeights
rm -v blVWeights
rm -v blWWeights

