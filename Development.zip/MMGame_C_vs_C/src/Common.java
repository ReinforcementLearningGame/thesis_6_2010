// some standard values used throughout the programme
interface Common{
   static final int DIMBOARD =8;   // board size
   static final int DIMBASE=2;    // base size
   static final int NUMOFPAWNS=10; // easy to understand
   static final int PLIES = 1;
   static final int WIN = 100;
   static final int LOSS = -100;
}
