
import javax.swing.SwingUtilities;
import javax.swing.ToolTipManager;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class RunRLGameComparison {

    //public static ComparisonFrame comparisonFrame;

    public static void main(String args[]) {
        ToolTipManager.sharedInstance().setDismissDelay(10000);
        ComparisonFrame.comparisonFrame = new ComparisonFrame();
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                ComparisonFrame.comparisonFrame.setVisible(true);
            }
        });
    }
}
