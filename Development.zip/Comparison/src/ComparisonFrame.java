


import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.io.File;
import javax.swing.BorderFactory;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.border.BevelBorder;
import javax.swing.border.TitledBorder;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * MainFrame.java
 *
 * Created on 28 Ιουν 2009, 8:13:25 μμ
 */

/**
 *
 * @author user
 */
public class ComparisonFrame extends javax.swing.JFrame {
    public static ComparisonFrame comparisonFrame;

    private LookAndFeelInfo[] looks;

    /** Creates new form MainFrame */
    public ComparisonFrame()
    {
        // set look and feel for this application
        looks = UIManager.getInstalledLookAndFeels();

        try
        {
            UIManager.setLookAndFeel( looks[3].getClassName() );
            SwingUtilities.updateComponentTreeUI( this );
        }
        catch ( Exception exception )
        {
            exception.printStackTrace();
        }

        initComponents();
        zeroConfig();
        setLocation(4, 4);
        comparisonTypeSelector = new ComparisonTypeSelectorWindow(this,true);
        comparisonTypeSelector.setLocation(this.getX()+this.getWidth()+5,this.getY()-5 );
        options = new OptionsWindow(this,true);
        options.setLocation(this.getX()+this.getWidth()+10,this.getY() );

    }

    public ComparisonType getSelectedComparisonType() {
        return selectedComparisonType;
    }

    public Game getMainGame() {
        return mainGame;
    }

    public JTextArea getResultTextArea() {
        return resultTextArea;
    }

    public JMenuItem getViewResultInfoMenuItem() {
        return viewResultInfoMenuItem;
    }

    public JMenuItem getPlaySimilarGameBackMenuItem() {
        return playSimilarGameBackMenuItem;
    }

    public JMenuItem getViewSimilarGameInfoMenuItem() {
        return viewSimilarGameInfoMenuItem;
    }

    public JMenuItem getViewSimilarGameTrajectoriesMenuItem1() {
        return viewSimilarGameTrajectoriesMenuItem;
    }

    public JMenuItem getChooseMSTMenuItem() {
        return chooseMSTMenuItem;
    }

    public JMenuItem getOptionsMSTMenuItem() {
        return optionsMSTMenuItem;
    }

    public JMenuItem getSelectFromListMenuItem() {
        return selectFromListMenuItem;
    }

    public JMenuItem getViewListMenuItem() {
        return viewListMenuItem;
    }

    public JMenuItem getPlaybackComparisonMenuItem() {
        return playbackComparisonMenuItem;
    }

    public JMenuItem getVisualComparisonMenuItem() {
        return visualComparisonMenuItem;
    }

    private void zeroConfig()
    {
        if(selectedSimilarGame.getGameFile()!=null)
            selectedSimilarGame.setGameFile(null);
        if(!similarGameSelectionInfo.getText().equals(""))
            similarGameSelectionInfo.setText("");
        selectedSimilarGame.setSimilarFileSelection(null);
        viewGameInfoMenuItem.setEnabled(false);
        viewGameTrajectoriesMenuItem.setEnabled(false);
        playGameBackMenuItem.setEnabled(false);
        viewListMenuItem.setEnabled(false);
        selectFromListMenuItem.setEnabled(false);
        viewSimilarGameInfoMenuItem.setEnabled(false);
        viewSimilarGameTrajectoriesMenuItem.setEnabled(false);
        playSimilarGameBackMenuItem.setEnabled(false);
        chooseMSTMenuItem.setEnabled(false);
        optionsMSTMenuItem.setEnabled(false);
        comparisonSettingsMenuItem.setEnabled(false);
        compareMenuItem.setEnabled(false);
        viewResultInfoMenuItem.setEnabled(false);
        visualComparisonMenuItem.setEnabled(false);
        playbackComparisonMenuItem.setEnabled(false);
    }

    public void recompareConf(){
        viewListMenuItem.setEnabled(false);
        selectFromListMenuItem.setEnabled(false);
        viewSimilarGameInfoMenuItem.setEnabled(false);
        viewSimilarGameTrajectoriesMenuItem.setEnabled(false);
        playSimilarGameBackMenuItem.setEnabled(false);
        chooseMSTMenuItem.setEnabled(false);
        optionsMSTMenuItem.setEnabled(false);
        viewResultInfoMenuItem.setEnabled(false);
        playbackComparisonMenuItem.setEnabled(false);
        visualComparisonMenuItem.setEnabled(false);
        similarGameSelectionInfo.setText("");
        resultTextArea.setText("");
    }

    public void createDoubleGameBoardSnapshotCmpType() {
        doubleGameBoardSnapshotCmpType = new CmpType2GBS();
        selectedComparisonType = doubleGameBoardSnapshotCmpType;
        this.recompareConf();
        System.out.print("\ncreateDoubleGameBoardSnapshotCmpType");
    }

    public void createDoubleWinnerBoardSnapshotCmpType() {
        doubleWinnerBoardSnapshotCmpType = new CmpType2WBS();
        selectedComparisonType = doubleWinnerBoardSnapshotCmpType;
        this.recompareConf();
        System.out.print("\ncreateDoubleWinnerBoardSnapshotCmpType");
    }

    public void createSimpleGameBoardSnapshotCmpType() {
        simpleGameBoardSnapshotCmpType = new CmpType1GBS();
        selectedComparisonType = simpleGameBoardSnapshotCmpType;
        this.recompareConf();
        System.out.print("\ncreateSimpleGameBoardSnapshotCmpType");
    }

    public void createSimpleWinnerBoardSnapshotCmpType() {
        simpleWinnerBoardSnapshotCmpType = new CmpType1WBS();
        selectedComparisonType = simpleWinnerBoardSnapshotCmpType;
        this.recompareConf();
        System.out.print("\ncreateSimpleWinnerBoardSnapshotCmpType");
    }

    public void createSpatialGameTrajectoriesType() {
        spatialGameTrajectoriesType = new CmpTypeSGTs();
        selectedComparisonType = spatialGameTrajectoriesType;
        this.recompareConf();
        System.out.print("\ncreateSpatialGameTrajectoriesType");
    }

    public void createSpatialWinningMultiTrajectoryType() {
        spatialWinningMultiTrajectoryType = new CmpTypeSWMT();
        selectedComparisonType = spatialWinningMultiTrajectoryType;
        this.recompareConf();
        System.out.print("\ncreateSpatialWinningMultiTrajectoryType");
    }

    public void createSpatialWinningTrajectoryType() {
        spatialWinningTrajectoryType = new CmpTypeSWT();
        selectedComparisonType = spatialWinningTrajectoryType;
       this.recompareConf();
        System.out.print("\ncreateSpatialWinningTrajectoryType");
    }

    public void createSpatiotemporalGameTrajectoriesType() {
        spatiotemporalGameTrajectoriesType = new CmpTypeStGTs();
        selectedComparisonType = spatiotemporalGameTrajectoriesType;
        this.recompareConf();
        System.out.print("\ncreateSpatiotemporalGameTrajectoriesType");
    }

    public void createSpatiotemporalWinningMultiTrajectoryType() {
        spatiotemporalWinningMultiTrajectoryType = new CmpTypeStWMT();
        selectedComparisonType = spatiotemporalWinningMultiTrajectoryType;
        this.recompareConf();
        System.out.print("\ncreateSpatiotemporalWinningMultiTrajectoryType");
    }

    public void createSpatiotemporalWinningTrajectoryType() {
        spatiotemporalWinningTrajectoryType = new CmpTypeStWT();
        selectedComparisonType = spatiotemporalWinningTrajectoryType;
        this.recompareConf();
        System.out.print("\ncreateSpatiotemporalWinningTrajectoryType");
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainGame = new Game();
        selectedSimilarGame = new Game();
        aboutWindow = new AboutWindow();
        rlGameComparisonPanel = new javax.swing.JPanel();
        mainGameSelectionInfo = new javax.swing.JLabel();
        comparisonTypeSelectionInfo = new javax.swing.JLabel();
        similarGameSelectionInfo = new javax.swing.JLabel();
        resultlPane = new javax.swing.JScrollPane();
        resultTextArea = new javax.swing.JTextArea();
        mainMenuBar = new javax.swing.JMenuBar();
        gameMenu = new javax.swing.JMenu();
        selectGameMenuItem = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JSeparator();
        viewGameInfoMenuItem = new javax.swing.JMenuItem();
        viewGameTrajectoriesMenuItem = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JSeparator();
        playGameBackMenuItem = new javax.swing.JMenuItem();
        similarGamesMenu = new javax.swing.JMenu();
        viewListMenuItem = new javax.swing.JMenuItem();
        selectFromListMenuItem = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JSeparator();
        viewSimilarGameInfoMenuItem = new javax.swing.JMenuItem();
        viewSimilarGameTrajectoriesMenuItem = new javax.swing.JMenuItem();
        jSeparator4 = new javax.swing.JSeparator();
        playSimilarGameBackMenuItem = new javax.swing.JMenuItem();
        trajectoryMenu = new javax.swing.JMenu();
        optionsMSTMenuItem = new javax.swing.JMenuItem();
        chooseMSTMenuItem = new javax.swing.JMenuItem();
        comparisonMenu = new javax.swing.JMenu();
        selectComparisonTypeMenuItem = new javax.swing.JMenuItem();
        comparisonSettingsMenuItem = new javax.swing.JMenuItem();
        jSeparator5 = new javax.swing.JSeparator();
        compareMenuItem = new javax.swing.JMenuItem();
        jSeparator6 = new javax.swing.JSeparator();
        viewResultInfoMenuItem = new javax.swing.JMenuItem();
        toolsMenu = new javax.swing.JMenu();
        visualComparisonMenuItem = new javax.swing.JMenuItem();
        playbackComparisonMenuItem = new javax.swing.JMenuItem();
        jSeparator7 = new javax.swing.JSeparator();
        optionsMenuItem = new javax.swing.JMenuItem();
        helpMenu = new javax.swing.JMenu();
        aboutMenuItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("RLGame Comparison");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setIconImage(new javax.swing.ImageIcon(getClass().getResource("/images/RLGame_comparison.png")).getImage());

        rlGameComparisonPanel.setBackground(new java.awt.Color(182, 208, 208));

        mainGameSelectionInfo.setFont(mainGameSelectionInfo.getFont().deriveFont(mainGameSelectionInfo.getFont().getSize()+2f));
        mainGameSelectionInfo.setForeground(new java.awt.Color(0, 51, 51));
        mainGameSelectionInfo.setText("There is no main game selected");

        comparisonTypeSelectionInfo.setFont(comparisonTypeSelectionInfo.getFont().deriveFont(comparisonTypeSelectionInfo.getFont().getSize()+2f));
        comparisonTypeSelectionInfo.setForeground(new java.awt.Color(0, 51, 51));
        comparisonTypeSelectionInfo.setText("There is no comparison type selected");

        similarGameSelectionInfo.setFont(similarGameSelectionInfo.getFont().deriveFont(similarGameSelectionInfo.getFont().getSize()+2f));
        similarGameSelectionInfo.setForeground(new java.awt.Color(0, 51, 51));
        similarGameSelectionInfo.setText(" ");

        resultlPane.setBorder(null);

        resultTextArea.setBackground(new java.awt.Color(182, 208, 208));
        resultTextArea.setColumns(20);
        resultTextArea.setEditable(false);
        resultTextArea.setFont(new java.awt.Font("Tahoma", 0, 13));
        resultTextArea.setForeground(new java.awt.Color(0, 51, 51));
        resultTextArea.setRows(5);
        resultTextArea.setTabSize(12);
        resultlPane.setViewportView(resultTextArea);

        javax.swing.GroupLayout rlGameComparisonPanelLayout = new javax.swing.GroupLayout(rlGameComparisonPanel);
        rlGameComparisonPanel.setLayout(rlGameComparisonPanelLayout);
        rlGameComparisonPanelLayout.setHorizontalGroup(
            rlGameComparisonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rlGameComparisonPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(rlGameComparisonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(rlGameComparisonPanelLayout.createSequentialGroup()
                        .addComponent(resultlPane, javax.swing.GroupLayout.DEFAULT_SIZE, 565, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(rlGameComparisonPanelLayout.createSequentialGroup()
                        .addGroup(rlGameComparisonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(similarGameSelectionInfo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 214, Short.MAX_VALUE)
                            .addComponent(mainGameSelectionInfo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 214, Short.MAX_VALUE)
                            .addComponent(comparisonTypeSelectionInfo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap(361, Short.MAX_VALUE))))
        );
        rlGameComparisonPanelLayout.setVerticalGroup(
            rlGameComparisonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rlGameComparisonPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(mainGameSelectionInfo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(comparisonTypeSelectionInfo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(similarGameSelectionInfo)
                .addGap(18, 18, 18)
                .addComponent(resultlPane, javax.swing.GroupLayout.DEFAULT_SIZE, 246, Short.MAX_VALUE)
                .addContainerGap())
        );

        getContentPane().add(rlGameComparisonPanel, java.awt.BorderLayout.CENTER);

        mainMenuBar.setFont(mainMenuBar.getFont().deriveFont(mainMenuBar.getFont().getSize()+2f));
        mainMenuBar.setPreferredSize(new java.awt.Dimension(270, 28));

        gameMenu.setForeground(new java.awt.Color(0, 102, 102));
        gameMenu.setText("  Main Game ");
        gameMenu.setFont(gameMenu.getFont().deriveFont(gameMenu.getFont().getSize()+2f));

        selectGameMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_M, java.awt.event.InputEvent.CTRL_MASK));
        selectGameMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/document_open_small.png"))); // NOI18N
        selectGameMenuItem.setText("Select Game");
        selectGameMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectGameMenuItemActionPerformed(evt);
            }
        });
        gameMenu.add(selectGameMenuItem);
        gameMenu.add(jSeparator1);

        viewGameInfoMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_M, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        viewGameInfoMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/info_small.png"))); // NOI18N
        viewGameInfoMenuItem.setText("View Game Info");
        viewGameInfoMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewGameInfoMenuItemActionPerformed(evt);
            }
        });
        gameMenu.add(viewGameInfoMenuItem);

        viewGameTrajectoriesMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_M, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.SHIFT_MASK));
        viewGameTrajectoriesMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/trajectory_small_1.png"))); // NOI18N
        viewGameTrajectoriesMenuItem.setText("View Game Trajectories");
        viewGameTrajectoriesMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewGameTrajectoriesMenuItemActionPerformed(evt);
            }
        });
        gameMenu.add(viewGameTrajectoriesMenuItem);
        gameMenu.add(jSeparator2);

        playGameBackMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_M, java.awt.event.InputEvent.ALT_MASK));
        playGameBackMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/mplayer_small.png"))); // NOI18N
        playGameBackMenuItem.setText("Playback Game ...");
        playGameBackMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                playGameBackMenuItemActionPerformed(evt);
            }
        });
        gameMenu.add(playGameBackMenuItem);

        mainMenuBar.add(gameMenu);

        similarGamesMenu.setForeground(new java.awt.Color(0, 102, 102));
        similarGamesMenu.setText("  Similar Games");
        similarGamesMenu.setFont(similarGamesMenu.getFont().deriveFont(similarGamesMenu.getFont().getSize()+2f));

        viewListMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_L, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        viewListMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/list_small.png"))); // NOI18N
        viewListMenuItem.setText("View Game List");
        viewListMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewListMenuItemActionPerformed(evt);
            }
        });
        similarGamesMenu.add(viewListMenuItem);

        selectFromListMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        selectFromListMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/selection_small.png"))); // NOI18N
        selectFromListMenuItem.setText("Select From List");
        selectFromListMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectFromListMenuItemActionPerformed(evt);
            }
        });
        similarGamesMenu.add(selectFromListMenuItem);
        similarGamesMenu.add(jSeparator3);

        viewSimilarGameInfoMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        viewSimilarGameInfoMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/hwinfo_small.png"))); // NOI18N
        viewSimilarGameInfoMenuItem.setText("View Similar Game Info");
        viewSimilarGameInfoMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewSimilarGameInfoMenuItemActionPerformed(evt);
            }
        });
        similarGamesMenu.add(viewSimilarGameInfoMenuItem);

        viewSimilarGameTrajectoriesMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.SHIFT_MASK));
        viewSimilarGameTrajectoriesMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/trajectory_small_1.png"))); // NOI18N
        viewSimilarGameTrajectoriesMenuItem.setText("View Similar Game Trajectories");
        viewSimilarGameTrajectoriesMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewSimilarGameTrajectoriesMenuItemActionPerformed(evt);
            }
        });
        similarGamesMenu.add(viewSimilarGameTrajectoriesMenuItem);
        similarGamesMenu.add(jSeparator4);

        playSimilarGameBackMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.ALT_MASK));
        playSimilarGameBackMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/mplayer_small.png"))); // NOI18N
        playSimilarGameBackMenuItem.setText("Playback Similar Game ...");
        playSimilarGameBackMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                playSimilarGameBackMenuItemActionPerformed(evt);
            }
        });
        similarGamesMenu.add(playSimilarGameBackMenuItem);

        mainMenuBar.add(similarGamesMenu);

        trajectoryMenu.setForeground(new java.awt.Color(0, 102, 102));
        trajectoryMenu.setText("  Trajectory");
        trajectoryMenu.setFont(trajectoryMenu.getFont().deriveFont(trajectoryMenu.getFont().getSize()+2f));

        optionsMSTMenuItem.setText("MST Options");
        trajectoryMenu.add(optionsMSTMenuItem);

        chooseMSTMenuItem.setText("Choose MST");
        trajectoryMenu.add(chooseMSTMenuItem);

        mainMenuBar.add(trajectoryMenu);

        comparisonMenu.setForeground(new java.awt.Color(0, 102, 102));
        comparisonMenu.setText("  Comparison");
        comparisonMenu.setFont(comparisonMenu.getFont().deriveFont(comparisonMenu.getFont().getSize()+2f));

        selectComparisonTypeMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_T, java.awt.event.InputEvent.CTRL_MASK));
        selectComparisonTypeMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/select_comparison_small.png"))); // NOI18N
        selectComparisonTypeMenuItem.setText("Select Comparison Type");
        selectComparisonTypeMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectComparisonTypeMenuItemActionPerformed(evt);
            }
        });
        comparisonMenu.add(selectComparisonTypeMenuItem);

        comparisonSettingsMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        comparisonSettingsMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/settings_small.png"))); // NOI18N
        comparisonSettingsMenuItem.setText("Comparison Settings");
        comparisonSettingsMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comparisonSettingsMenuItemActionPerformed(evt);
            }
        });
        comparisonMenu.add(comparisonSettingsMenuItem);
        comparisonMenu.add(jSeparator5);

        compareMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.SHIFT_MASK));
        compareMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/compare_small.png"))); // NOI18N
        compareMenuItem.setText("Compare ...");
        compareMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                compareMenuItemActionPerformed(evt);
            }
        });
        comparisonMenu.add(compareMenuItem);
        comparisonMenu.add(jSeparator6);

        viewResultInfoMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        viewResultInfoMenuItem.setText("View Result Info");
        viewResultInfoMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewResultInfoMenuItemActionPerformed(evt);
            }
        });
        comparisonMenu.add(viewResultInfoMenuItem);

        mainMenuBar.add(comparisonMenu);

        toolsMenu.setForeground(new java.awt.Color(0, 102, 102));
        toolsMenu.setText("  Tools");
        toolsMenu.setFont(toolsMenu.getFont().deriveFont(toolsMenu.getFont().getSize()+2f));

        visualComparisonMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.SHIFT_MASK));
        visualComparisonMenuItem.setText("Visual Comparison");
        toolsMenu.add(visualComparisonMenuItem);

        playbackComparisonMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.ALT_MASK));
        playbackComparisonMenuItem.setText("Playback Comparison");
        toolsMenu.add(playbackComparisonMenuItem);
        toolsMenu.add(jSeparator7);

        optionsMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        optionsMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/options_small.png"))); // NOI18N
        optionsMenuItem.setText("Options");
        optionsMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optionsMenuItemActionPerformed(evt);
            }
        });
        toolsMenu.add(optionsMenuItem);

        mainMenuBar.add(toolsMenu);

        helpMenu.setForeground(new java.awt.Color(0, 102, 102));
        helpMenu.setText("  Help");
        helpMenu.setFont(helpMenu.getFont().deriveFont(helpMenu.getFont().getSize()+2f));

        aboutMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/about.png"))); // NOI18N
        aboutMenuItem.setText("About RLGame Comparison");
        aboutMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aboutMenuItemActionPerformed(evt);
            }
        });
        helpMenu.add(aboutMenuItem);

        mainMenuBar.add(helpMenu);

        setJMenuBar(mainMenuBar);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void selectComparisonTypeMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectComparisonTypeMenuItemActionPerformed
        // TODO add your handling code here:
        comparisonTypeSelector.setVisible(true);
        if(selectedComparisonType==null)
            return;
        comparisonTypeSelectionInfo.setText(selectedComparisonType.getClass().getName() + " comparison type is selected");
        if(mainGame.getGameFile()!=null)
        {
            comparisonSettingsMenuItem.setEnabled(true);
            compareMenuItem.setEnabled(true);
        }
}//GEN-LAST:event_selectComparisonTypeMenuItemActionPerformed

    private void aboutMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aboutMenuItemActionPerformed
        // TODO add your handling code here:
        aboutWindow.setVisible(true);
        aboutWindow.setLocation((int) (Toolkit.getDefaultToolkit().getScreenSize().getWidth()/2 - aboutWindow.getWidth()/2),(int) (Toolkit.getDefaultToolkit().getScreenSize().getHeight()/2 - aboutWindow.getHeight()/2));
    }//GEN-LAST:event_aboutMenuItemActionPerformed

    private void selectGameMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectGameMenuItemActionPerformed
        // TODO add your handling code here:
        File tempGameFile = mainGame.getGameFile();
        mainGame.selectMainGame();
        if(mainGame.getGameFile()==null)
            return;
        if(mainGame.getGameFile().equals(tempGameFile))
            return;
        zeroConfig();
        mainGame.setPawnDeletionPossitionList(null);
        mainGame.splitPawnTrajectories(0);
        mainGame.splitPawnTrajectories(1);
        Trajectory wTrajectory = Trajectory.trajectoryListRedistribution(mainGame.getWhiteTrajectories());
        Trajectory bTrajectory = Trajectory.trajectoryListRedistribution(mainGame.getBlackTrajectories());
        mainGame.setWhiteTrajectories(wTrajectory);
        mainGame.setBlackTrajectories(bTrajectory);
        mainGameSelectionInfo.setText(mainGame.getGameFile().getName()+" game file is selected");
        options.setComparisonDirectory(mainGame.getFileSelection().getCurrentDirectory());
        options.getDirectoryText().setText(mainGame.getFileSelection().getCurrentDirectory().getPath());
        resultTextArea.setText("");
        viewGameInfoMenuItem.setEnabled(true);
        viewGameTrajectoriesMenuItem.setEnabled(true);
        playGameBackMenuItem.setEnabled(true);
        if(selectedComparisonType!=null)
        {
            comparisonSettingsMenuItem.setEnabled(true);
            compareMenuItem.setEnabled(true);
            selectedComparisonType.setNewGameSelection(true);
        }

        if(mainGameTrajectoriesViewer!=null && mainGameTrajectoriesViewer.isShowing())
        {
            mainGameTrajectoriesViewer.dispose();
            mainGameTrajectoriesViewer=new TrajectoriesViewer(mainGame);
            mainGameTrajectoriesViewer.setVisible(true);
        }

    }//GEN-LAST:event_selectGameMenuItemActionPerformed

    private void viewGameInfoMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewGameInfoMenuItemActionPerformed
        // TODO add your handling code here:
        mainGame.createGameInfoWindow("Main Game","MAIN GAME INFORMATION");
    }//GEN-LAST:event_viewGameInfoMenuItemActionPerformed

    private void selectFromListMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectFromListMenuItemActionPerformed
        // TODO add your handling code here:
        File tempSimilarGameFile = selectedSimilarGame.getGameFile();
        selectedSimilarGame.selectASimilarGame();
        if(selectedSimilarGame.getGameFile()==null)
            return;
        if(selectedSimilarGame.getGameFile().equals(tempSimilarGameFile))
            return;
        selectedSimilarGame.setPawnDeletionPossitionList(null);
        selectedSimilarGame.splitPawnTrajectories(0);
        selectedSimilarGame.splitPawnTrajectories(1);
        Trajectory wTrajectory = Trajectory.trajectoryListRedistribution(selectedSimilarGame.getWhiteTrajectories());
        Trajectory bTrajectory = Trajectory.trajectoryListRedistribution(selectedSimilarGame.getBlackTrajectories());
        selectedSimilarGame.setWhiteTrajectories(wTrajectory);
        selectedSimilarGame.setBlackTrajectories(bTrajectory);
        similarGameSelectionInfo.setText(selectedSimilarGame.getGameFile().getName()+" similar game file is selected");
        viewSimilarGameInfoMenuItem.setEnabled(true);
        viewSimilarGameTrajectoriesMenuItem.setEnabled(true);
        playSimilarGameBackMenuItem.setEnabled(true);
        viewResultInfoMenuItem.setEnabled(true);
        visualComparisonMenuItem.setEnabled(true);
        playbackComparisonMenuItem.setEnabled(true);

        if(similarGameTrajectoriesViewer!=null && similarGameTrajectoriesViewer.isShowing())
        {
            similarGameTrajectoriesViewer.dispose();
            similarGameTrajectoriesViewer=new TrajectoriesViewer(selectedSimilarGame);
            similarGameTrajectoriesViewer.setVisible(true);
        }

    }//GEN-LAST:event_selectFromListMenuItemActionPerformed

    private void viewSimilarGameInfoMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewSimilarGameInfoMenuItemActionPerformed
        // TODO add your handling code here:
        selectedSimilarGame.createGameInfoWindow("Similar Game","SIMILAR GAME INFORMATION");
        selectedSimilarGame.getGameInfoWindow().setIconImage(new javax.swing.ImageIcon(getClass().getResource("/images/hwinfo_small.png")).getImage());
    }//GEN-LAST:event_viewSimilarGameInfoMenuItemActionPerformed

    private void viewListMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewListMenuItemActionPerformed
        // TODO add your handling code here:
        selectedSimilarGame.setSimilarFileSelection(new SimilarGamesListWindow(comparisonFrame,true));
        selectedSimilarGame.getSimilarFileSelection().getFileList().setEnabled(false);
        selectedSimilarGame.getSimilarFileSelection().getGamesListPanel().setBorder(BorderFactory.createTitledBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, new Color(231, 241, 241), new Color(0, 102, 102), new Color(0, 102, 102), new Color(231, 241, 241)), "SIMILAR GAMES", TitledBorder.CENTER, TitledBorder.TOP, new Font("Tahoma", 1, 14), new Color(0, 102, 102)));
        selectedSimilarGame.getSimilarFileSelection().repaint();
        selectedSimilarGame.getSimilarFileSelection().setLocation(comparisonFrame.getWidth()-selectedSimilarGame.getSimilarFileSelection().getWidth(), comparisonFrame.getHeight()-selectedSimilarGame.getSimilarFileSelection().getHeight());
        selectedSimilarGame.getSimilarFileSelection().setVisible(true);
    }//GEN-LAST:event_viewListMenuItemActionPerformed

    private void compareMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_compareMenuItemActionPerformed
        if(options.getComparisonDirectory()==null)
        {
            JOptionPane.showMessageDialog(this, "<html><font color=\"#006666\">There is no comparison directory selected. Select plese</font>", "Comparison directory error", JOptionPane.WARNING_MESSAGE);
            options.selectDirectory(comparisonFrame);
            if(options.getComparisonDirectory()==null)
            {
                JOptionPane.showMessageDialog(this, "<html><font color=\"#006666\">The comparison was suspended because no directory is selected.<br/>Try again or press Tools --> Options to select one.</font>", "Comparison directory selection", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }
        File[]toCompareFiles = selectedComparisonType.selectComparisonFiles(options.getComparisonDirectory().toString());
        if(toCompareFiles.length==0)
        {
            options.setComparisonDirectory(null);
            options.getDirectoryText().setText("");
            return ;
        }
        selectedComparisonType.getResult().clear();
        for(int i=0;i<toCompareFiles.length;i++)
        {
            boolean  hasDimentionSimilarity = selectedComparisonType.selectProspectiveSimilarGameFile(toCompareFiles[i]);
            if(!hasDimentionSimilarity)
                continue;
            System.out.print("\nTHE FILE: "+selectedComparisonType.getProspectiveSimilarGame().getGameFile().getName()+" IS SELECTED\n");
            boolean isPreperationOK = selectedComparisonType.prepareSingleComparison(mainGame);
            if(!isPreperationOK)
            {
                System.out.print("\nTHE OPPONENT IS THE WINNER\n");
                continue;
            }
            selectedComparisonType.estimateComparisonMeasure();
            ComparisonType.SingleResultInfo singleResult = selectedComparisonType.collectAndStoreInfo();
            if(selectedComparisonType.getCmpMeasure1()==0)
                continue;
            System.out.print("\nTHE GAME: "+selectedComparisonType.getProspectiveSimilarGame().getGameFile().getName()+" IS SIMILAR\n");
            selectedComparisonType.getResult().add(singleResult);
            //System.out.print("\n!!!"+spatialWinningTrajectoryType.getArea()+"!!!\n");
        }
        if(selectedComparisonType.getResult().isEmpty())
        {
            JOptionPane.showMessageDialog(ComparisonFrame.comparisonFrame, "<html><font color=\"#006666\">This comparison direcrory has no similar games.<br/>Click on Tools --> Options to select another.</font>", "Similar Games", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        viewListMenuItem.setEnabled(true);
        selectFromListMenuItem.setEnabled(true);
        chooseMSTMenuItem.setEnabled(true);
        optionsMSTMenuItem.setEnabled(true);
        viewResultInfoMenuItem.setEnabled(true);
    }//GEN-LAST:event_compareMenuItemActionPerformed

    private void viewGameTrajectoriesMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewGameTrajectoriesMenuItemActionPerformed
        // TODO add your handling code here:
        if(mainGameTrajectoriesViewer==null || !mainGameTrajectoriesViewer.isShowing())
        {
            mainGameTrajectoriesViewer=new TrajectoriesViewer(mainGame);
            mainGameTrajectoriesViewer.setVisible(true);
        }
    }//GEN-LAST:event_viewGameTrajectoriesMenuItemActionPerformed

    private void viewSimilarGameTrajectoriesMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewSimilarGameTrajectoriesMenuItemActionPerformed
        // TODO add your handling code here:
        if(similarGameTrajectoriesViewer==null || !similarGameTrajectoriesViewer.isShowing())
        {
            similarGameTrajectoriesViewer=new TrajectoriesViewer(selectedSimilarGame);
            similarGameTrajectoriesViewer.setVisible(true);
        }
    }//GEN-LAST:event_viewSimilarGameTrajectoriesMenuItemActionPerformed

    private void playGameBackMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_playGameBackMenuItemActionPerformed
        // TODO add your handling code here:
        mainGamePlaybackFrame = new PlaybackFrame();
        mainGamePlaybackFrame.getSelectGameButton().setEnabled(false);
        mainGamePlaybackFrame.getSelectGameButton().setVisible(false);
        mainGamePlaybackFrame.setLocation(15+this.getWidth(), this.getY());
        mainGamePlaybackFrame.setDefaultCloseOperation(javax.swing.JFrame.DISPOSE_ON_CLOSE);
        //mainGamePlaybackFrame.getPlaybackSrvs().setSelectedFile( mainGame.getGameFile());
        mainGamePlaybackFrame.getPlaybackSrvs().setFileSrvs(mainGame.getFileSrvs());
        mainGamePlaybackFrame.getPlaybackSrvs().setExternalFileSelection(true);
        mainGamePlaybackFrame.getPlaybackSrvs().selectGame();
        mainGamePlaybackFrame.getPlaybackSrvs().getInfoWindow().dispose();

    }//GEN-LAST:event_playGameBackMenuItemActionPerformed

    private void playSimilarGameBackMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_playSimilarGameBackMenuItemActionPerformed
        // TODO add your handling code here:
        similarGamePlaybackFrame = new PlaybackFrame();
        similarGamePlaybackFrame.getSelectGameButton().setEnabled(false);
        similarGamePlaybackFrame.getSelectGameButton().setVisible(false);
        similarGamePlaybackFrame.setLocation(15+this.getWidth(), this.getY());
        similarGamePlaybackFrame.setDefaultCloseOperation(javax.swing.JFrame.DISPOSE_ON_CLOSE);
        similarGamePlaybackFrame.getPlaybackSrvs().setFileSrvs(selectedSimilarGame.getFileSrvs());
        similarGamePlaybackFrame.getPlaybackSrvs().setExternalFileSelection(true);
        similarGamePlaybackFrame.getPlaybackSrvs().selectGame();
        similarGamePlaybackFrame.getPlaybackSrvs().getInfoWindow().dispose();

    }//GEN-LAST:event_playSimilarGameBackMenuItemActionPerformed

    private void optionsMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_optionsMenuItemActionPerformed
        options.setVisible(true);
    }//GEN-LAST:event_optionsMenuItemActionPerformed

    private void comparisonSettingsMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comparisonSettingsMenuItemActionPerformed
        selectedComparisonType.getSettingsWindow().setVisible(true);
    }//GEN-LAST:event_comparisonSettingsMenuItemActionPerformed

    private void viewResultInfoMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewResultInfoMenuItemActionPerformed
        /*// TODO add your handling code here:
        resultTextArea.setText("\n\t\t\tFOUND "+selectedComparisonType.getResult().size()+" SIMILAR GAMES\n");
        //resultTextArea.setFont(new java.awt.Font("Tahoma", java.awt.Font.BOLD, 13));
        resultTextArea.append("\n\tFile Name\t\tCommon Points\tIncluded Area\tMoves\tSimilarity Measure 1\t\tSimilarity Measure 2\n");
        //resultTextArea.setFont(new java.awt.Font("Tahoma", 0, 13));
        String result="";
        ComparisonType.singleResultInfo rslt;
        for(int i=0; i<selectedComparisonType.getResult().size(); i++){
        rslt = (ComparisonType.singleResultInfo)selectedComparisonType.getResult().get(i);
        result += rslt.getSimilarFile().getName()+"\t"+rslt.getCommonPointsNum()+"\t"+rslt.getIncludedVolume()+"\t"+rslt.getMoveTime()+"\t"+rslt.getSimilarityMeasure1()+"\t\t"+rslt.getSimilarityMeasure2()+"\n";
        }*/
        resultTextArea.append(selectedComparisonType.printResult());
        System.out.print(selectedComparisonType.printResult());
    }//GEN-LAST:event_viewResultInfoMenuItemActionPerformed


    /**
    * @param args the command line arguments
    */


    private OptionsWindow options;
    private PlaybackFrame mainGamePlaybackFrame;
    private PlaybackFrame similarGamePlaybackFrame;
    private TrajectoriesViewer similarGameTrajectoriesViewer;
    private TrajectoriesViewer mainGameTrajectoriesViewer;
    private CmpTypeSWT spatialWinningTrajectoryType;
    private CmpTypeSWMT spatialWinningMultiTrajectoryType;
    private CmpTypeStWT spatiotemporalWinningTrajectoryType;
    private CmpTypeStWMT spatiotemporalWinningMultiTrajectoryType;
    private CmpTypeSGTs spatialGameTrajectoriesType;
    private CmpTypeStGTs spatiotemporalGameTrajectoriesType;
    private CmpType1WBS simpleWinnerBoardSnapshotCmpType;
    private CmpType2WBS doubleWinnerBoardSnapshotCmpType;
    private CmpType1GBS simpleGameBoardSnapshotCmpType;
    private CmpType2GBS doubleGameBoardSnapshotCmpType;
    private ComparisonType selectedComparisonType;
    private ComparisonTypeSelectorWindow comparisonTypeSelector;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem aboutMenuItem;
    private AboutWindow aboutWindow;
    private javax.swing.JMenuItem chooseMSTMenuItem;
    private javax.swing.JMenuItem compareMenuItem;
    private javax.swing.JMenu comparisonMenu;
    private javax.swing.JMenuItem comparisonSettingsMenuItem;
    private javax.swing.JLabel comparisonTypeSelectionInfo;
    private javax.swing.JMenu gameMenu;
    private javax.swing.JMenu helpMenu;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private Game mainGame;
    private javax.swing.JLabel mainGameSelectionInfo;
    private javax.swing.JMenuBar mainMenuBar;
    private javax.swing.JMenuItem optionsMSTMenuItem;
    private javax.swing.JMenuItem optionsMenuItem;
    private javax.swing.JMenuItem playGameBackMenuItem;
    private javax.swing.JMenuItem playSimilarGameBackMenuItem;
    private javax.swing.JMenuItem playbackComparisonMenuItem;
    private javax.swing.JTextArea resultTextArea;
    private javax.swing.JScrollPane resultlPane;
    private javax.swing.JPanel rlGameComparisonPanel;
    private javax.swing.JMenuItem selectComparisonTypeMenuItem;
    private javax.swing.JMenuItem selectFromListMenuItem;
    private javax.swing.JMenuItem selectGameMenuItem;
    private Game selectedSimilarGame;
    private javax.swing.JLabel similarGameSelectionInfo;
    private javax.swing.JMenu similarGamesMenu;
    private javax.swing.JMenu toolsMenu;
    private javax.swing.JMenu trajectoryMenu;
    private javax.swing.JMenuItem viewGameInfoMenuItem;
    private javax.swing.JMenuItem viewGameTrajectoriesMenuItem;
    private javax.swing.JMenuItem viewListMenuItem;
    private javax.swing.JMenuItem viewResultInfoMenuItem;
    private javax.swing.JMenuItem viewSimilarGameInfoMenuItem;
    private javax.swing.JMenuItem viewSimilarGameTrajectoriesMenuItem;
    private javax.swing.JMenuItem visualComparisonMenuItem;
    // End of variables declaration//GEN-END:variables

}
