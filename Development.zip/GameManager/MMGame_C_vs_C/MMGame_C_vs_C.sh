#!/bin/sh

java -jar MMGame_C_vs_C.jar

