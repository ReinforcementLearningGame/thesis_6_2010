
import java.util.*;
import java.awt.*;

public class Player implements Common{

  //******Added by Dockos************
  static public double eGreedyWhite=0.9;
  static public double eGreedyBlack=0.9;
  //*********************************
  private int id;
  static public double alpha=0.001;
  static public double lambda=0.5;
  private double currWValue;
  private double currBValue;
  private double reward;
  private double[] index;
  TextArea toWSaveGame=new TextArea();
  TextArea toBSaveGame=new TextArea();
  public Player(int ident) {
    id=ident;
  }

  //not used, a human white player moves
  public final void humanWhite(Pawn[] whitePawn,Square source,Square sink){
    int j=-1;
    double valueOfMovement = -1;
    for (int i=0;i<NUMOFPAWNS;i++){
      if (whitePawn[i].position.equals(source)) j=i;
    }

    //*************Added by Dockos************
    double[] aux=Spiel.myPosition.getWValue(j,sink);
    valueOfMovement=aux[0];
    //****************************************

    whitePawn[j].movePawn(source,sink);
    Spiel.myPosition.refreshPosition();
    
    //createWSaveGame(""+source.xCoord+source.yCoord+"->"+sink.xCoord+sink.yCoord);
    //Modified by Dockos to
    createWSaveGame(""+source.xCoord+","+source.yCoord+"->"+sink.xCoord+","+sink.yCoord+"->" +valueOfMovement);
  }


  //not used, a human white player moves
  public final void humanBlack(Pawn[] blackPawn,Square source,Square sink){
    int j=-1;
    double valueOfMovement = -1;
    for (int i=0;i<NUMOFPAWNS;i++){
      if (blackPawn[i].position.equals(source)) j=i;
    }

    //*************Added by Dockos************
    double[] aux=Spiel.myPosition.getWValue(j,sink);
    valueOfMovement=aux[0];
    //****************************************

    blackPawn[j].movePawn(source,sink);
    Spiel.myPosition.refreshPosition();
    
    //createBSaveGame(""+source.xCoord+source.yCoord+"->"+sink.xCoord+sink.yCoord);
    //Modified by Dockos to
    createBSaveGame(""+source.xCoord+","+source.yCoord+"->"+sink.xCoord+","+sink.yCoord+"->" +valueOfMovement);
  }


  // computer white plays
  public final int[] pickWhiteMove(Pawn[] whitePawn,Square[][] woutSquare){
    int[] selMoveDesc=new int[2];
    Pawn[] whitPawn=whitePawn;
    Square[][] helpSquare=new Square[NUMOFPAWNS][2*DIMBASE];
    helpSquare=Spiel.myPosition.getAllMovesForWhitePlayer(woutSquare); // get all legal moves for white
    selMoveDesc=whiteChooses(whitPawn,helpSquare);  //play one of them
    return selMoveDesc;
  }

  //computer black plays
  public final int[] pickBlackMove(Pawn[] blackPawn,Square[][] boutSquare){
    int[] selMoveDesc=new int[2];
    Pawn[] blacPawn=blackPawn;
    Square[][] helpSquare=new Square[NUMOFPAWNS][2*DIMBASE];
    helpSquare=Spiel.myPosition.getAllMovesForBlackPlayer(boutSquare); //get all legal moves for black
    selMoveDesc=blackChooses(blacPawn,helpSquare); //play one of them
    return selMoveDesc;
  }

  //choose a legal move
  private final int[] whiteChooses(Pawn[] whitPawn,Square[][] helpSquare){
    int xx=-1;int yy=-1;
    Pawn[] whitePawn=whitPawn;
    double maxValue=-1000;
    double value;  // the value of the position that occurs after making a move
    boolean bestMove; //if true-> exploit, else ->explore

    //Added by Dockos
    String movement;

    Vector possiblePawns=new Vector();
    Vector possibleSquares=new Vector();
    java.util.Date helpDate=new Date();
    Random eSoftDecision=new Random(helpDate.getTime());
    double eSoft=eSoftDecision.nextDouble();
    //bestMove=(eSoft<0.9)?true:false; //if eSoft is less than 0.9 then we exploit
    //replaced by Dockos to
    bestMove=(eSoft<eGreedyWhite)?true:false; //if eSoft is less than 0.9 then we exploit
    Random exploreWDecision=new Random(helpDate.getTime()+1230000);
    int moveCounter=0;
    for (int i=0;i<NUMOFPAWNS;i++){
      for (int j=0;j<2*DIMBASE;j++){
        if ((helpSquare[i][j].xCoord+helpSquare[i][j].yCoord)!=0){
          double[] aux=Spiel.myPosition.getWValue(i,helpSquare[i][j]); //get the value of the occuring position
          moveCounter++;
          possiblePawns.addElement(new Integer(i));
          possibleSquares.addElement(helpSquare[i][j]);
          value=aux[0];
          if (value>maxValue) { //if it is the biggest value, keep it
            maxValue=value;
            xx=i;
            yy=j;
          }
        }
      }
    }
    if (bestMove){  //exploit
      int[] selMoveDesc=new int[2];

      //createWSaveGame(""+whitePawn[xx].position.xCoord+Spiel.whitePawn[xx].position.yCoord+"->"+helpSquare[xx][yy].xCoord+helpSquare[xx][yy].yCoord);
      //Replaced by Dockos to
      movement = ""+whitePawn[xx].position.xCoord+","+Spiel.whitePawn[xx].position.yCoord+"->"+helpSquare[xx][yy].xCoord+","+helpSquare[xx][yy].yCoord+"->" +maxValue;

      selMoveDesc[0]=whitePawn[xx].position.square2Tag();
      selMoveDesc[1]=helpSquare[xx][yy].square2Tag();
      // move the pawn
      whitePawn[xx].movePawn(whitePawn[xx].position,helpSquare[xx][yy]);
      // check for dead pawns
      Spiel.myPosition.refreshPosition();

      //************Added by Dockos*************
      createWSaveGame(movement + Spiel.myPosition.getPositionOfDeletedPawns());
      Spiel.myPosition.setPositionOfDeletedPawns("");
      //****************************************

      Spiel.myPosition.setCurrentWValue(maxValue);
      //transform pawns to binary array for the neural net
      Spiel.whiteNeural.pawnsToInput(Spiel.whitePawn,Spiel.blackPawn);
      // get the appropriate reward
      reward=Spiel.myPosition.getReward(true);
      boolean setValue=Spiel.myPosition.isFinal(Spiel.whitePawn,Spiel.blackPawn);
      // update the neural net
      Spiel.whiteNeural.singleStep(reward,setValue);

//      saveWGame(); //if uncommented then we also record the moves
      return selMoveDesc;
    }
    else {   //explore
      Spiel.whiteNeural.clearEligTrace(); //clear eligibility traces
      double explore=exploreWDecision.nextDouble();
      int target=(int)(explore*moveCounter);
      int chosenPawn=((Integer) possiblePawns.elementAt(target)).intValue();
      Square chosenSquare=(Square)possibleSquares.elementAt(target);
      double[] aux=Spiel.myPosition.getWValue(chosenPawn,chosenSquare);

      //createWSaveGame(""+whitePawn[chosenPawn].position.xCoord+whitePawn[chosenPawn].position.yCoord+"->"+chosenSquare.xCoord+chosenSquare.yCoord);
      //Replaced by Dockos to
      movement = ""+whitePawn[chosenPawn].position.xCoord+","+whitePawn[chosenPawn].position.yCoord+"->"+chosenSquare.xCoord+","+chosenSquare.yCoord+"->" +maxValue;

      int[] selMoveDesc=new int[2];
      selMoveDesc[0]=whitePawn[chosenPawn].position.square2Tag();
      selMoveDesc[1]=chosenSquare.square2Tag();
      // move pawn
      whitePawn[chosenPawn].movePawn(whitePawn[chosenPawn].position,chosenSquare);
      // check for dead
      Spiel.myPosition.refreshPosition();
      
      //*************Added by Dockos************
      createWSaveGame(movement + Spiel.myPosition.getPositionOfDeletedPawns());
      Spiel.myPosition.setPositionOfDeletedPawns("");
      //****************************************

      Spiel.whiteNeural.setOldOutputNode(aux[0]);
  //    saveWGame(); //uncomment to save the moves 
      return selMoveDesc;
    }
  }

  //choose a legal move
  private final int[] blackChooses(Pawn[] blacPawn,Square[][] helpSquare){
    int xx=-1;int yy=-1;
    Pawn[] blackPawn=blacPawn;
    double value;
    double maxValue=-1000;
    boolean bestMove;
    
    //Added by Dockos
    String movement;

    Vector possiblePawns=new Vector();
    Vector possibleSquares=new Vector();
    java.util.Date helpDate=new Date();
    Random eSoftDecision=new Random(helpDate.getTime()+2500321);
    double eSoft=eSoftDecision.nextDouble();
    //bestMove=(eSoft<0.9)?true:false;
    //replaced by Dockos to
    bestMove=(eSoft<eGreedyBlack)?true:false;
    index=Spiel.myPosition.getCurrentBInd();
    Random exploreBDecision=new Random(helpDate.getTime()+4000000);
    int moveCounter=0;
    for (int i=0;i<NUMOFPAWNS;i++){
      for (int j=0;j<2*DIMBASE;j++){
        if ((helpSquare[i][j].xCoord+helpSquare[i][j].yCoord)!=0){
          double[] aux=Spiel.myPosition.getBValue(i,helpSquare[i][j]);
          moveCounter++;
          possiblePawns.addElement(new Integer(i));
          possibleSquares.addElement(helpSquare[i][j]);
          value=aux[0];
          if (value>maxValue) {
            maxValue=value;
            xx=i;
            yy=j;
          }
        }
      }
    }
    if (bestMove){

      //createBSaveGame(""+blackPawn[xx].position.xCoord+Spiel.blackPawn[xx].position.yCoord+"->"+helpSquare[xx][yy].xCoord+helpSquare[xx][yy].yCoord);
      //Replaced by Dockos to
      movement = ""+blackPawn[xx].position.xCoord+","+Spiel.blackPawn[xx].position.yCoord+"->"+helpSquare[xx][yy].xCoord+","+helpSquare[xx][yy].yCoord+"->" +maxValue;

      int[] selMoveDesc=new int[2];
      selMoveDesc[0]=blackPawn[xx].position.square2Tag();
      selMoveDesc[1]=helpSquare[xx][yy].square2Tag();
      blackPawn[xx].movePawn(blackPawn[xx].position,helpSquare[xx][yy]);
      Spiel.myPosition.refreshPosition();
      
      //************Added by Dockos************
      createBSaveGame(movement + Spiel.myPosition.getPositionOfDeletedPawns());
      Spiel.myPosition.setPositionOfDeletedPawns("");
      //***************************************

      Spiel.myPosition.setCurrentBValue(maxValue);
    //  saveBGame();
      Spiel.blackNeural.pawnsToInput(Spiel.whitePawn,Spiel.blackPawn);
      reward=Spiel.myPosition.getReward(false);
      boolean setValue=Spiel.myPosition.isFinal(Spiel.whitePawn,Spiel.blackPawn);
      Spiel.blackNeural.singleStep(reward,setValue);
      return selMoveDesc;
    }
    else {
      Spiel.blackNeural.clearEligTrace();
      double explore=exploreBDecision.nextDouble();
      int target=(int)(explore*moveCounter);
      int chosenPawn=((Integer) possiblePawns.elementAt(target)).intValue();
      Square chosenSquare=(Square)possibleSquares.elementAt(target);
      double[] aux=Spiel.myPosition.getBValue(chosenPawn,chosenSquare);
      
      //createBSaveGame(""+blackPawn[chosenPawn].position.xCoord+blackPawn[chosenPawn].position.yCoord+"->"+chosenSquare.xCoord+chosenSquare.yCoord);
      //Replaced by Dockos to
      movement = ""+blackPawn[chosenPawn].position.xCoord+","+blackPawn[chosenPawn].position.yCoord+"->"+chosenSquare.xCoord+","+chosenSquare.yCoord+"->" +maxValue;

      int[] selMoveDesc=new int[2];
      selMoveDesc[0]=blackPawn[chosenPawn].position.square2Tag();
      selMoveDesc[1]=chosenSquare.square2Tag();
      blackPawn[chosenPawn].movePawn(blackPawn[chosenPawn].position,chosenSquare);
      Spiel.myPosition.refreshPosition();
      
      //*************Added by Dockos************
      createBSaveGame(movement + Spiel.myPosition.getPositionOfDeletedPawns());
      Spiel.myPosition.setPositionOfDeletedPawns("");
      //****************************************

      Spiel.blackNeural.setOldOutputNode(aux[0]);
//      saveBGame();
      return selMoveDesc;
    }
  }
  public final void createWSaveGame(String s)
    {
        toWSaveGame.append(s);
        toWSaveGame.append("\n");

    }
     public final void saveWGame()
    {
       history savedWGame=new history();
       savedWGame.writeToFile(toWSaveGame.getText(),"aspra" ,1);
    }
    public final void createBSaveGame(String s)
    {
        toBSaveGame.append(s);
        toBSaveGame.append("\n");

    }
     public final void saveBGame()
    {
       history savedBGame=new history();
       savedBGame.writeToFile(toBSaveGame.getText(),"mavra" ,1);
    }

}

