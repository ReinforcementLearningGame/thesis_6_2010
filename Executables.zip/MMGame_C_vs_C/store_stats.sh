#!/bin/sh

mkdir -v statistics
mv -v *.txt statistics

