/***************
  Created by:  Panagiotis Kanellopoulos
  Modified by: Eirini Ntoutsi
  Operation: Is the main class, it authenticates the player, initiates history (statistics) and begins a game
*******/
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.awt.geom.*;
import javax.swing.*;

public class RunRLGameHvsC implements Common
{
   static String login;
   static JFrame loginFrame;

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   //Krata gia kathe paixnidi to plithos ton kiniseon kai to nikiti
   public static void saveStats()
   {
      history statistics=new history();
      statistics.writeToFile(Spiel.myStats.getText(),"_stats" ,1);
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   //Pistopoiisi paikti i eggrafi neou paikti
   public static void showLoginWindow()
   {
      final JTextField myText;
      loginFrame =new JFrame();
      JPanel myJPanel=new JPanel();
      myText = new JTextField(6);
      Dimension frameSize=new Dimension(200,60);
      Dimension panelSize=new Dimension(130,50);

      loginFrame.setBackground(Color.orange);
      loginFrame.setTitle(" Enter your login");
      loginFrame.setResizable(false);

      myJPanel.setBackground(Color.orange);

      myJPanel.setSize(panelSize);
      myJPanel.setMaximumSize(panelSize);
      myJPanel.setMinimumSize(panelSize);
      myText.setRequestFocusEnabled(true);

      myJPanel.add(myText);
      loginFrame.setContentPane(myJPanel);
      myText.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent evt)
         {
           login = myText.getText().trim();
           myText.setText("");
         }
      });
      loginFrame.setSize(frameSize);
      loginFrame.setVisible(true);
      loginFrame.repaint();
      loginFrame.addWindowListener(new WindowAdapter()
      {
         public void windowClosing(WindowEvent e)
         {
            System.exit(1);
         }
      });
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
  //eso ksekinaei i ektelesi tou programmatos
   public static void main(String[] args)
   {
      showLoginWindow();
      login="";
      while(true)
      {
         if ((login!="")&&(login!=null)&&(login.length()>0))
         {
            loginFrame.dispose();
            break;
         }
      }

      //paikse 10 paixnidia ton 10 episodion to kathena, molis teleiosei to ena paixniid arxizei
      //aytomata to allo(eksodos me to stopButton tou board)
/*    for (int kk=0;kk<10;kk++)
      {
          for (int i=0;i<10;i++)
          {
*/
            //paikse ena paixnidi
            Spiel myGame=new Spiel(DIMBOARD,DIMBASE,NUMOFPAWNS,login);
            //arxikopoiise ek neou to visualBoard
            Spiel.myVisualBoardFrame.clearVisualBoard();
/*
            System.out.print(" End of episode "+i);
            if((i%10)==0)
               System.out.println(i);
          }
*/
          saveStats();
          System.out.println("GAME OVER");
/*
      }
*/
}
}
//this is the end