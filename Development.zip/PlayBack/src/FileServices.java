
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * 
 * @author giordoc
 */
public class FileServices
{
   /**
    * The name of the <code>File</code> object which will be opened by an object 
    * of the current class
    */ 
   private String fileName;                     
   
   /**
    * The <code>File</code> object which will be created by an object of the current class  
    */
   private File file;
   
   /**
    * An object of the subclass <code>fileNameAnalyzer</code> which will be created by 
    * the current class intending to the reading and analysing of the name 
    * <code>fileName</code> of the file <code>file</code>that was opened
    */
   private fileNameAnalyzer fNaneAnalyzer;
   
   /**
    * An <code>ArrayList</code> object which is created by an object of the current 
    * class with the intention of recording the saved data that exists at the 
    * <code>File</code> object <code>file</code> for all the moves of a played game  
    */
   private  MovementList movementList;
   
   /**
    * The number of the lost pawns for the 'black' player at the game saved in <code>file</code>
    */
   private int bLostPawns;
   
   /**
    * The number of the lost pawns for the 'white' player at the game saved in <code>file</code>
    */
   private int wLostPawns;

   private char fileType = 'a';

   /**
    * 
    * @param newFile
    * @throws java.io.IOException
    */
   public FileServices( File newFile ) throws IOException
   {
      file = new File( newFile.getPath() );
      fileName = newFile.getName();
      fNaneAnalyzer= new fileNameAnalyzer();
      movementList=new MovementList();
   }
   
   public FileServices()
   {
      movementList=new MovementList();
      movementList.clear();
   }

   /**
    * Returns the name of the opened file which is hold out by the <code>File</code> 
    * object <code>file</code>
    * @return the name of the opened file
    */
   public String getFileName()
   {
       return fileName;
   }
   
   /**
    * This method reads the saved data for all the movements that exists in <code>File</code> 
    * object <code>file</code> and places them to an <code>ArrayList</code> object
    */
   public void readRecordsToMakeList()
   {
        try {
            System.out.print("\n");
            System.out.print(file.getName());                
            Scanner fileReader = new Scanner(new FileReader(file));
            int serialNumber=0;
            while(fileReader.hasNext())
            {
                this.readRecordToListing(fileReader.next(),serialNumber);
                serialNumber++;
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FileServices.class.getName()).log(Level.SEVERE, null, ex);
        }
       
   }
   
   /**
    * This method reads the saved data for a movement that exists in <code>File</code> 
    * object <code>file</code> and adds them as an element of the <code>ArrayList</code> 
    * object <code>movementList</code>
    * @param movement a string that contains the data for the movement
    * @param index the movement's serial number
    */
    public void readRecordToListing(String movement, int index)
    {
        ArrayList dPawns = new ArrayList();
        //reformat the movement string
        movement = movement.replace("->", " ");
        movement = movement.replace(",", " ");
        //place it to a scanner for reading
        Scanner moveReader = new Scanner(movement);
        int prevX=-1;
        int prevY=-1;
        int nextX=-1;
        int nextY=-1;
        if(fileType=='a' || fileType=='b')
        {
            prevX = moveReader.nextInt();
            prevY = moveReader.nextInt();
            nextX = moveReader.nextInt();
            nextY = moveReader.nextInt();
        }
        System.out.print("\n");
        System.out.print(index);
        System.out.print("th movement: ");
        System.out.print(prevX);
        System.out.print("*");
        System.out.print(prevY);
        System.out.print(" --> ");
        System.out.print(nextX);
        System.out.print("*");
        System.out.print(nextY);

        String valueofMovement = moveReader.next();
        
        if(moveReader.hasNext() && !(moveReader.hasNextInt() || moveReader.hasNextDouble()))
        {
            String deletedPawns = moveReader.next();
            deletedPawns=deletedPawns.replace("d:","");
            deletedPawns=deletedPawns.replace("#", " ");
            System.out.print(deletedPawns);
            Scanner dPawnsReader = new Scanner(deletedPawns);
            int i = 0;
            while(dPawnsReader.hasNext())
            {
                dPawns.add(i,dPawnsReader.next());
                //System.out.print(" ");
                //System.out.print(dPawns.get(i));
                i++;
            }
        }
        movementList.addMovement(index, prevX, prevY, nextX, nextY, dPawns);

    }


   /**
    * Returns the name of the player who won the saved game. It is estimated by
    * the number of the movements of the game. This is reflected at the size of the
    * <code>ArrayList</code> object <code>movementList</code>. Because the white 
    * player plays first if the value of the list size is an odd number then the 
    * winner is the white player. If the number is even the winner is the black one. 
    * @return a string that represents the winner of the game. If the list is empty
    * returns the string "winner"
    */
   public String getWinner()
   {
       if(!movementList.isEmpty())
       {
           int w = movementList.size()%2;
           if(w==0)
               return "red";
           else
               return "blue";
           
       }
       else
           return "winner";
   }
   
   /**
    * Returns the movement number of the player who won the saved game which is 
    * reflected at the <code>movementList</code> size
    * @return winner's movement number
    */
   public int getWinnerMovements()
   {
       if(!movementList.isEmpty())
       {
           return ((movementList.size()-1)/2)+1;

       }
       else
           return 0;       
   }
   
   /**
    * Returns the value of <code>wLostPawns</code>
    * @return the number of the lost pawns for the white player
    */
   public int getWLostPawns()
   {
        return wLostPawns;
   }
   
   /**
    * Returns the value of <code>bLostPawns</code>
    * @return the number of the lost pawns for the black player
    */   public int getBLostPawns()
   {
        return bLostPawns;
   }   

   /**
    * This method estimates the numbers of lost pawns for each player. The method 
    * initiates the values of <code>bLostPawns</code> and <code>wLostPawns</code>and
    * sets them after estimate. For each movement recorded at <code>movementList</code>,
    * the method checks if there were deleted pawns. If so, counts them for each
    * player
    */
    public void estimateLostPawns()
   {
        wLostPawns=0;
        bLostPawns=0;
        if(!movementList.isEmpty())
        {
            for(int ii=0; ii<movementList.size(); ii++)
            {
                if(!movementList.getMovement(ii).getPawnsToDelete().isEmpty())
                {
                    for(int i=0; i<movementList.getMovement(ii).getPawnsToDelete().size(); i++)
                    {
                        String dPawn= (String)movementList.getMovement(ii).getPawnsToDelete().get(i);
                        String color = dPawn.substring(0, 1);
                        if(color.equals("1"))
                            wLostPawns++;
                        if(color.equals("0"))
                            bLostPawns++;
                    }
           
                }
            }
        }
   }

    public fileNameAnalyzer getFNaneAnalyzer() {
        return fNaneAnalyzer;
    }

    public MovementList getMovementList() {
        return movementList;
    }

    public File getFile() {
        return file;
    }

    public void setFNaneAnalyzer(fileNameAnalyzer fNaneAnalyzer) {
        this.fNaneAnalyzer = fNaneAnalyzer;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public void setMovementList(MovementList movementList) {
        this.movementList = movementList;
    }

    public char getFileType() {
        return fileType;
    }

    public void setFileType(char fileType) {
        this.fileType = fileType;
    }
    
   /**
    * This subclass reads and analyzes the string that is recorded at 
    * the property <code>fileName</code>
    */
   public class fileNameAnalyzer
   {
       private Scanner time = new Scanner(getFileName().substring(11, 19));
       private String hour = time.next();
       private String min = time.next();
       private String sec = time.next();
       private String day = getFileName().substring(0, 3);
       private String month = getFileName().substring(4, 7);
       private String monthday = getFileName().substring(8, 10);
       private Scanner gameParam = new Scanner(getFileName().substring(20));
       private Scanner user_and_board = new Scanner(gameParam.next().replace("_", " "));
       private String user = user_and_board.next();
       private int dimboard = user_and_board.nextInt();
       private int dimbase = user_and_board.nextInt();
       private int numpawns = user_and_board.nextInt();
       
       /**
        * Returns the day that the played game was saved and has been recorded at 
        * the property <code>day</code>
        * @return the string of the day that the played game was saved
        */
       public String getGameDay()
       {
           return day;
       }
       
       /**
        * Returns the month that the played game was saved and has been recorded at 
        * the property <code>month</code>
        * @return the string of the day that the played game was saved
        */
       public String getGameMonth()
       {
           return month;
       }
       
       /**
        * Returns the monthday that the played game was saved and has been recorded at 
        * the property <code>monthday</code>
        * @return the string of the day that the played game was saved
        */
       public String getGameMonthday()
       {
           return monthday;
       }
       
       /**
        * Returns the hour that the played game was saved and has been recorded at 
        * the property <code>hour</code>
        * @return the string of the day that the played game was saved
        */
       public String getGameHour()
       {
           return hour;
       }
       
       /**
        * Returns the minutes that the played game was saved and has been recorded at 
        * the property <code>min</code>
        * @return the string of the day that the played game was saved
        */
       public String getGameMin()
       {
           return min;
       }
       
       /**
        * Returns the seconds that the played game was saved and has been recorded at 
        * the property <code>sec</code>
        * @return the string of the day that the played game was saved
        */
       public String getGameSec()
       {
           return sec;
       }
       
       /**
        * Returns the username of the player that played against the computer.
        * The player can also be the computer itself. It has been recorded at 
        * the property <code>user</code>
        * @return the string of the player who played against the computer
        */
       public String getGameUser()
       {
           return user;
       }       
       
       /**
        * Returns the dimension of the gameboard for the saved game. It has been 
        * recorded at the property <code>dimboard</code>
        * @return the dimension of the gameboard
        */
       public int getGameDimboard()
       {
           return dimboard;
       }
       
       /**
        * Returns the dimension of the player base for the saved game. It has been 
        * recorded at the property <code>dimbase</code>
        * @return the dimension of the player base
        */
       public int getGameDimbase()
       {
           return dimbase;
       }
       
       /**
        * Returns the number of pawns that every player had at his disposal for 
        * the saved game. It has been recorded at the property <code>numpawns</code>
        * @return the number of pawns that every player had at his disposal
        */
       public int getGameNumpawns()
       {
           return numpawns;
       }
       
   }

    
}

