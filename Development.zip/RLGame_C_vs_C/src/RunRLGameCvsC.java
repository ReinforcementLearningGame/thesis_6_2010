
import java.io.File;
import java.util.Date;
import javax.swing.JOptionPane;


// This is the main class, it initiates history (statistics) and begins a game

public class RunRLGameCvsC implements Common{
  static int metritis=0;
  static GameSettings settings;

  // start logfile
  public static void saveStats(){
      history statistics=new history();
      statistics.writeToFile(Spiel.myStats.getText(),"_stats" ,1);
  }

//****************Added by Dockos**********************************************
    private static File makeGamesDirectory()
    {
        Date myDate=new Date();
        String helpName=myDate.toString();
        helpName=helpName.substring(0,19);
        helpName=helpName.replace(':',' ');
        helpName=helpName+".gamedir";
        File dir=new File(helpName);
        return dir;
    }

  public static void main(String[] args) {
//****************Added by Dockos**********************************************
   int gamesNumber=100;
   int roundsNumber=10;
   File gamedir=null;
   String help = "\nRLGame By Dimitris Kalles & Panagiotis Kanellopoulos\n" +
           "\n\t\t##SWITHES##\n" +
           "\n\t-h Shows the current screen" +
           "\n\t-g Enter the number of games to be executed in each round" +
           "\n\t-r Enter the number of game rounds" +
           "\n\t-wg Enter the discount rate for the white player" +
           "\n\t-wl Enter the credit assignment factor for the white player" +
           "\n\t-bg Enter the discount rate for the black player" +
           "\n\t-bl Enter the credit assignment factor for the black player" +
           "\n\t-wr Enter the reward value for the white player" +
           "\n\t-br Enter the reward value for the black player" +
           "\n\t-we Enter the e-greedy policy number for the white player" +
           "\n\t-be Enter the e-greedy policy number for the black player\n";

   if(args.length==1 && args[0].contentEquals("-h"))
   {
       System.out.print(help);
       return;
   }
   
   if(args.length==0)
   {
   int answer=JOptionPane.CLOSED_OPTION;
       answer = JOptionPane.showOptionDialog(settings, "The command called without parameters. Do you want to set them? \nIf you select \"no\" the command will execute with the defaults", "Input Parametres", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
       if(answer==JOptionPane.OK_OPTION)
       {
           settings = new GameSettings();
           settings.setVisible(true);
           while(true)
           {
               if(!(settings.isVisible()))
                   break;
           }
           gamesNumber=settings.getGamesNumber();
           roundsNumber=settings.getRoundsNumber();
           Position.whiteReward=settings.getWhiteReward();
           Position.blackReward=settings.getBlackReward();
           Player.eGreedyWhite=settings.getWhiteEGreedy();
           Player.eGreedyBlack=settings.getBlackEGreedy();
           Spiel.blackGamma=settings.getBlackGamma();
           Spiel.blackLamda=settings.getBlackLamda();
           Spiel.whiteGamma=settings.getWhiteGamma();
           Spiel.whiteLamda=settings.getWhiteLamda();
       }
       else if(answer==JOptionPane.NO_OPTION)
           ;
       else return;
   }
   else if(args.length>20)
   {
       System.out.print("\nToo many arguments.Termination\n");
       return;
   }
   else
   {
       for(int l=0; l<args.length; l++)
       {
           if(l%2==0)
           {
               if(!args[l].startsWith("-"))
               {
                   System.out.printf("\nThe %dth argument has no switch (-). Defaulting...", l+1);
                   continue;
               }
               if(args[l].contentEquals("-g"))
               {
                   try {
                       gamesNumber = Integer.parseInt(args[l + 1]);
                       System.out.printf("\nThe games per round number has been set up in %s.",args[l + 1]);
                   } catch (NumberFormatException numberFormatException) {
                       System.out.print("\nInvalid value in games per round number argument. "+numberFormatException.getMessage()+"Defaulting to 100");
                   }
                   continue;
               }
               if(args[l].contentEquals("-r"))
               {
                   try {
                       roundsNumber = Integer.parseInt(args[l + 1]);
                       System.out.printf("\nThe games round number has been set up in %s.",args[l + 1]);
                   } catch (NumberFormatException numberFormatException) {
                       System.out.print("\nInvalid value in games round number argument. "+numberFormatException.getMessage()+"Defaulting to 10");
                   }
                   continue;
               }
               if(args[l].equals("-wg"))
               {
                   try {
                       Spiel.whiteGamma = Double.parseDouble(args[l + 1]);
                       System.out.printf("\nThe discount rate number for the white player has been set up in %s.",args[l + 1]);
                   } catch (NumberFormatException numberFormatException) {
                       System.out.print("\nInvalid value in discount rate number argument for the white player. "+numberFormatException.getMessage()+"Defaulting to 0.95");
                   }
                   continue;
               }
               if(args[l].equals("-wl"))
               {
                   try {
                       Spiel.whiteLamda = Double.parseDouble(args[l + 1]);
                       System.out.printf("\nThe credit asignment factor for the white player has been set up in %s.",args[l + 1]);
                   } catch (NumberFormatException numberFormatException) {
                       System.out.print("\nInvalid value in credit asignment factor argument for the white player. "+numberFormatException.getMessage()+"Defaulting to 0.5");
                   }
                   continue;
               }
               if(args[l].equals("-bg"))
               {
                   try {
                       Spiel.blackGamma = Double.parseDouble(args[l + 1]);
                       System.out.printf("\nThe discount rate number for the black player has been set up in %s.",args[l + 1]);
                   } catch (NumberFormatException numberFormatException) {
                       System.out.print("\nInvalid value in discount rate number argument for the black player. "+numberFormatException.getMessage()+"Defaulting to 0.95");
                   }
                   continue;
               }
               if(args[l].equals("-bl"))
               {
                   try {
                       Spiel.blackLamda = Double.parseDouble(args[l + 1]);
                       System.out.printf("\nThe credit asignment factor for the black player has been set up in %s.",args[l + 1]);
                   } catch (NumberFormatException numberFormatException) {
                       System.out.print("\nInvalid value in credit asignment factor argument for the black player. "+numberFormatException.getMessage()+"Defaulting to 0.5");
                   }
                   continue;
               }
               if(args[l].equals("-wr"))
               {
                   try {
                       Position.whiteReward = Double.parseDouble(args[l + 1]);
                       System.out.printf("\nThe reward value for the white player has been set up in %s.",args[l + 1]);
                   } catch (NumberFormatException numberFormatException) {
                       System.out.print("\nInvalid value in reward value argument for the white player. "+numberFormatException.getMessage()+"Defaulting to 100");
                   }
                   continue;
               }
               if(args[l].equals("-br"))
               {
                   try {
                       Position.blackReward = Double.parseDouble(args[l + 1]);
                       System.out.printf("\nThe reward value for the black player has been set up in %s.",args[l + 1]);
                   } catch (NumberFormatException numberFormatException) {
                       System.out.print("\nInvalid value in reward value argument for the black player. "+numberFormatException.getMessage()+"Defaulting to 100");
                   }
                   continue;
               }
               if(args[l].equals("-we"))
               {
                   try {
                       Player.eGreedyWhite = Double.parseDouble(args[l + 1]);
                       System.out.printf("\nThe e-Greedy policy number for the white player has been set up in %s.",args[l + 1]);
                   } catch (NumberFormatException numberFormatException) {
                       System.out.print("\nInvalid value in e-Greedy policy number argument for the white player. "+numberFormatException.getMessage()+"Defaulting to 0.9");
                   }
                   continue;
               }
               if(args[l].equals("-be"))
               {
                   try {
                       Player.eGreedyBlack = Double.parseDouble(args[l + 1]);
                       System.out.printf("\nThe e-Greedy policy number for the black player has been set up in %s.",args[l + 1]);
                   } catch (NumberFormatException numberFormatException) {
                       System.out.print("\nInvalid value in e-Greedy policy number argument for the black player. "+numberFormatException.getMessage()+"Defaulting to 0.9");
                   }
                   continue;
               }
               System.out.printf("\nThe %dth argument is not valid.");
               continue;
           }
       }
   }

   gamedir=makeGamesDirectory();
   gamedir.mkdir();
   history.Path=gamedir.getAbsolutePath();
//****************************************************************************
   
   //****************Modyfied by Dockos***************************************
   for (int kk=0;kk<roundsNumber;kk++){
      for (int i=0;i<gamesNumber;i++){
   //*************************************************************************
         // play a game
        Spiel myGame=new Spiel(DIMBOARD,DIMBASE,NUMOFPAWNS);
        //if ((i%10)==0) {
          System.out.print(kk);
          System.out.print(":");
          System.out.println(i);
	  //}
      }
      System.out.println("telos");
    }
    saveStats();
    System.exit(0);
  }

}





