
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileNameExtensionFilter;

public class PlaybackFrame extends JFrame
{
    //public static JLabel picture;
    private UIManager.LookAndFeelInfo looks[];
    private int DIMBOARD; //board size
    private PlaybackBoard playbackBoard;
    private PlaybackServices playbackSrvs;
    private ProgressionManager progressionMngr;
    //private JFrame myFrame;
    private JPanel boardPanel;
    private JPanel toolbarPanel;
    private JPanel speedPanel;
    private JPanel southPanel;
    private JButton modeButton,moveStatusButton,closeButton,infoButton,playButton,stopButton,pauseButton,previousButton,nextButton,selectGameButton,selectSpeedButton;
    private InterfaceManager setInterface = new InterfaceManager();

    public PlaybackFrame()
    {
        super("RLGame Playback");
        playbackBoard=new PlaybackBoard(setInterface.getDimboard(),setInterface.getDimbase());
        playbackSrvs = new PlaybackServices();
        toolbarPanel=new JPanel();
        boardPanel=new JPanel();
        speedPanel=new JPanel();
        southPanel=new JPanel();
        progressionMngr = new ProgressionManager();

        DIMBOARD= setInterface.getDimboard();

        Dimension boardDim = new Dimension(DIMBOARD*40,DIMBOARD*40);
        Dimension toolbarDim = new Dimension(400,42);
        Dimension buttonSize = new Dimension(28,28);
        Dimension frameDim = new Dimension(400,DIMBOARD*40+310);

        setLayout(new BorderLayout());

        speedPanel.setBackground(new Color(250, 250, 210));
        speedPanel.setBorder(new BevelBorder(BevelBorder.LOWERED,new Color(222,184,135),new Color(222,184,135)));
        speedPanel.setLayout(new BorderLayout());
        speedPanel.add(playbackSrvs.speedSettler, BorderLayout.CENTER);

        boardPanel.setMinimumSize(boardDim);
        boardPanel.setBackground(new Color(255, 255, 224));
        boardPanel.setBorder(new BevelBorder(BevelBorder.LOWERED,new Color(222,184,135),new Color(222,184,135)));
        boardPanel.add(playbackBoard);
        boardPanel.setLayout(null);

        progressionMngr.setBorder(new BevelBorder(BevelBorder.LOWERED,new Color(222,184,135),new Color(222,184,135)));

        southPanel.setBackground(new Color(250, 250, 210));
        //southPanel.setBorder(new BevelBorder(BevelBorder.LOWERED,new Color(222,184,135),new Color(222,184,135)));
        southPanel.setLayout(new BorderLayout());
        southPanel.add(speedPanel, BorderLayout.SOUTH);
        southPanel.add(progressionMngr, BorderLayout.NORTH);

        toolbarPanel.setSize(toolbarDim);
        toolbarPanel.setPreferredSize(toolbarDim);
        toolbarPanel.setMinimumSize(toolbarDim);
        //toolbarPanel.setMaximumSize(toolbarDim);
        toolbarPanel.setOpaque(true);
        toolbarPanel.setBackground(new Color(250, 250, 210));
        toolbarPanel.setBorder(new BevelBorder(BevelBorder.LOWERED,new Color(222,184,135),new Color(222,184,135)));


        /* (1)to selectGameButton kai o listener tou */
        selectGameButton =new JButton(new ImageIcon(getClass().getResource("images/selectgame.png")));
        selectGameButton.setToolTipText("<html><font color=\"#B8860B\">Select Game</font>");
        selectGameButton.setMaximumSize(buttonSize);
        selectGameButton.setPreferredSize(buttonSize);
        selectGameButton.setBackground(new Color(240,230,140));
        class selectGameButtonActionListener implements ActionListener
        {
            public void actionPerformed(ActionEvent evt)
            {
                playbackSrvs.selectGame();
            }
        }
        selectGameButtonActionListener myselectGameButton=new selectGameButtonActionListener();
        selectGameButton.addActionListener(myselectGameButton);
        toolbarPanel.add(selectGameButton);
        /* ok me to selectGameButton*/

        /* (1)to selectSpeedButton kai o listener tou */
        selectSpeedButton =new JButton();
        selectSpeedButton.setIcon(new ImageIcon(getClass().getResource("images/selectspeed.png")));
        selectSpeedButton.setToolTipText("<html><font color=\"#B8860B\">Select playback speed</font>");
        selectSpeedButton.setMaximumSize(buttonSize);
        selectSpeedButton.setPreferredSize(buttonSize);
        selectSpeedButton.setBackground(new Color(240,230,140));
        selectSpeedButton.setEnabled(false);
        class selectSpeedButtonActionListener implements ActionListener
        {
            public void actionPerformed(ActionEvent evt)
            {
                playbackSrvs.selectSpeed();
            }
      }
        selectSpeedButtonActionListener myselectSpeedButton=new selectSpeedButtonActionListener();
        selectSpeedButton.addActionListener(myselectSpeedButton);
        toolbarPanel.add(selectSpeedButton);
        /* ok me to selectSpeedButton*/

        /* (1)to settingsButton kai o listener tou */
        moveStatusButton =new JButton(new ImageIcon(getClass().getResource("images/move_status.png")));
        moveStatusButton.setToolTipText("<html><font color=\"#B8860B\">Show move status</font>");
        moveStatusButton.setMaximumSize(buttonSize);
        moveStatusButton.setPreferredSize(buttonSize);
        moveStatusButton.setBackground(new Color(240,230,140));
        moveStatusButton.setEnabled(true);
        class moveStatusButtonActionListener implements ActionListener
        {
            public void actionPerformed(ActionEvent evt)
            {
                playbackSrvs.showMoveStatus();
            }
        }
        moveStatusButtonActionListener myMoveStatusButton=new moveStatusButtonActionListener();
        moveStatusButton.addActionListener(myMoveStatusButton);
        toolbarPanel.add(moveStatusButton);
        /* ok me to settingsButton*/

        /* (1)to settingsButton kai o listener tou */
        modeButton =new JButton(new ImageIcon(getClass().getResource("images/step_by_step.png")));
        modeButton.setToolTipText("<html><font color=\"#B8860B\">Step by step mode</font>");
        modeButton.setMaximumSize(buttonSize);
        modeButton.setPreferredSize(buttonSize);
        modeButton.setBackground(new Color(240,230,140));
        //modeButton.setEnabled(false);
        class modeButtonActionListener implements ActionListener
        {
            public void actionPerformed(ActionEvent evt)
            {
                playbackSrvs.selectMode();
            }
        }
        modeButtonActionListener myModeButton=new modeButtonActionListener();
        modeButton.addActionListener(myModeButton);
        toolbarPanel.add(modeButton);
        /* ok me to closeButton*/

        /* (1)to playButton kai o listener tou */
        playButton =new JButton(new ImageIcon(getClass().getResource("images/play.png")));
        playButton.setToolTipText("<html><font color=\"#B8860B\">Play selected game</font>");
        playButton.setMaximumSize(buttonSize);
        playButton.setPreferredSize(buttonSize);
        playButton.setBackground(new Color(240,230,140));
        class playButtonActionListener implements ActionListener
        {
            @SuppressWarnings("static-access")
            public void actionPerformed(ActionEvent evt)
            {
                playbackSrvs.playGameInitiation();
                playbackSrvs.playSelectedGame();
            }
        }
        playButtonActionListener myplayButton=new playButtonActionListener();
        playButton.addActionListener(myplayButton);
        toolbarPanel.add(playButton);
        /* ok me to playButton*/


        /* (1)to pauseButton kai o listener tou */
        pauseButton =new JButton(new ImageIcon(getClass().getResource("images/pause.png")));
        pauseButton.setToolTipText("<html><font color=\"#B8860B\">Pause current game</font>");
        pauseButton.setMaximumSize(buttonSize);
        pauseButton.setPreferredSize(buttonSize);
        pauseButton.setBackground(new Color(240,230,140));
        pauseButton.setEnabled(false);
        class pauseButtonActionListener implements ActionListener
        {
            public void actionPerformed(ActionEvent evt)
            {
                playbackSrvs.pauseCurrentGame();
            }
        }
        pauseButtonActionListener mypauseButton=new pauseButtonActionListener();
        pauseButton.addActionListener(mypauseButton);
        toolbarPanel.add(pauseButton);
        /* ok me to pauseButton*/

        /* (1)to stopButton kai o listener tou */
        stopButton =new JButton(new ImageIcon(getClass().getResource("images/stop.png")));
        stopButton.setToolTipText("<html><font color=\"#B8860B\">Stop current game</font>");
        stopButton.setMaximumSize(buttonSize);
        stopButton.setPreferredSize(buttonSize);
        stopButton.setBackground(new Color(240,230,140));
        stopButton.setEnabled(false);
        class stopButtonActionListener implements ActionListener
        {
            public void actionPerformed(ActionEvent evt)
            {
                playbackSrvs.stopCurrentGame();
            }
        }
        stopButtonActionListener mystopButton=new stopButtonActionListener();
        stopButton.addActionListener(mystopButton);
        toolbarPanel.add(stopButton);
        /* ok me to stopButton*/

        /* (1)to previousButton kai o listener tou */
        previousButton =new JButton(new ImageIcon(getClass().getResource("images/previous.png")));
        previousButton.setToolTipText("<html><font color=\"#B8860B\">Previous move</font>");
        previousButton.setMaximumSize(buttonSize);
        previousButton.setPreferredSize(buttonSize);
        previousButton.setBackground(new Color(240,230,140));
        previousButton.setEnabled(false);
        class previousButtonActionListener implements ActionListener
        {
            public void actionPerformed(ActionEvent evt)
            {
                playbackSrvs.previousMovement();
            }
        }
        previousButtonActionListener mypreviousButton=new previousButtonActionListener();
        previousButton.addActionListener(mypreviousButton);
        toolbarPanel.add(previousButton);
        /* ok me to previousButton*/

        /* (1)to nextButton kai o listener tou */
        nextButton =new JButton(new ImageIcon(getClass().getResource("images/next.png")));
        nextButton.setToolTipText("<html><font color=\"#B8860B\">Next move</font>");
        nextButton.setMaximumSize(buttonSize);
        nextButton.setPreferredSize(buttonSize);
        nextButton.setBackground(new Color(240,230,140));
        nextButton.setEnabled(false);
        class nextButtonActionListener implements ActionListener
        {
            public void actionPerformed(ActionEvent evt)
            {
                playbackSrvs.nextMovement();
            }
        }
        nextButtonActionListener mynextButton=new nextButtonActionListener();
        nextButton.addActionListener(mynextButton);
        toolbarPanel.add(nextButton);
        /* ok me to nextButton*/

        /* (5)to infoButton kai o listener tou */
        infoButton =new JButton(new ImageIcon(getClass().getResource("images/info.gif")));
        infoButton.setToolTipText("<html><font color=\"#B8860B\">Info</font>");
        infoButton.setMaximumSize(buttonSize);
        infoButton.setBackground(new Color(240,230,140));
        infoButton.setPreferredSize(buttonSize);
        class infoButtonActionListener implements ActionListener
        {
            public void actionPerformed(ActionEvent evt)
            {
                playbackSrvs.playbackInfo();
            }
        }
        infoButtonActionListener myInfoAL=new infoButtonActionListener();
        infoButton.addActionListener(myInfoAL);
        toolbarPanel.add(infoButton);
        /* ok me to infoButton*/

        /* (1)to closeButton kai o listener tou */
        closeButton =new JButton(new ImageIcon(getClass().getResource("images/exit.gif")));
        closeButton.setToolTipText("<html><font color=\"#B8860B\">Exit playback</font>");
        closeButton.setMaximumSize(buttonSize);
        closeButton.setPreferredSize(buttonSize);
        closeButton.setBackground(new Color(240,230,140));
        class closeButtonActionListener implements ActionListener
        {
            public void actionPerformed(ActionEvent evt)
            {
                if(playbackSrvs.isExternalFileSelection())
                {
                    playbackSrvs.speedSettler.stopAnimation();
                    dispose();
                    System.gc();
                }
                else
                System.exit(0);
            }
        }
        closeButtonActionListener myCloseAL=new closeButtonActionListener();
        closeButton.addActionListener(myCloseAL);
        toolbarPanel.add(closeButton);
        /* ok me to closeButton*/

        /* --- End of listeners --- */

        getContentPane().add(BorderLayout.CENTER,boardPanel);
        getContentPane().add(BorderLayout.NORTH,toolbarPanel);
        getContentPane().add(BorderLayout.SOUTH,southPanel);

        // set look and feel for this application
        looks = UIManager.getInstalledLookAndFeels();

        try
        {
            UIManager.setLookAndFeel( looks[0].getClassName());
            SwingUtilities.updateComponentTreeUI(this.toolbarPanel);
            UIManager.setLookAndFeel( looks[3].getClassName());
            SwingUtilities.updateComponentTreeUI(this.progressionMngr);
            SwingUtilities.updateComponentTreeUI(this.playbackSrvs.infoWindow);
            SwingUtilities.updateComponentTreeUI(this.playbackSrvs.speedSettler);
        }
        catch ( Exception exception )
        {
            exception.printStackTrace();
        }

        setSize(DIMBOARD*40+60,DIMBOARD*40+190);
        setMinimumSize(frameDim);

        if(this.getSize().width <= this.getMinimumSize().width)
            playbackBoard.setLocation(200-(DIMBOARD*40)/2,25);
        else
            playbackBoard.setLocation(37,25);

        ImageIcon winIcon = new ImageIcon(getClass().getResource("images/playback.png"));
        setIconImage(winIcon.getImage());
        setResizable(false);
        setVisible(true);
        setLocation(10,10);
        repaint();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        addWindowListener(
        new WindowAdapter()
        {
            @Override
            public void windowClosing(WindowEvent e)
            {
                if( playbackSrvs.isExternalFileSelection())
                {
                    playbackSrvs.speedSettler.stopAnimation();
                    dispose();
                    System.gc();
                }
            }
        });
    }

    public PlaybackBoard getPlaybackBoard() {
        return playbackBoard;
    }

    public void setPlaybackBoard(PlaybackBoard playbackBoard) {
        this.playbackBoard = playbackBoard;
    }

    public ProgressionManager getProgressionMngr() {
        return progressionMngr;
    }

    public PlaybackServices getPlaybackSrvs() {
        return playbackSrvs;
    }

    public JPanel getBoardPanel() {
        return boardPanel;
    }

    public JPanel getSouthPanel() {
        return southPanel;
    }

    public JPanel getSpeedPanel() {
        return speedPanel;
    }

    public JButton getCloseButton() {
        return closeButton;
    }

    public JButton getInfoButton() {
        return infoButton;
    }

    public JButton getModeButton() {
        return modeButton;
    }

    public JButton getMoveStatusButton() {
        return moveStatusButton;
    }

    public JButton getNextButton() {
        return nextButton;
    }

    public JButton getPauseButton() {
        return pauseButton;
    }

    public JButton getPlayButton() {
        return playButton;
    }

    public JButton getPreviousButton() {
        return previousButton;
    }

    public JButton getSelectGameButton() {
        return selectGameButton;
    }

    public JButton getSelectSpeedButton() {
        return selectSpeedButton;
    }

    public JButton getStopButton() {
        return stopButton;
    }

    public JPanel getToolbarPanel() {
        return toolbarPanel;
    }

    public PlaybackFrame getThisPlaybackFrame() {
        return this;
    }



    public class PlaybackServices{
        private JFileChooser fileSelection;
        private Informer infoWindow;
        private MoveStatus movementStatus;
        private SpeedManager speedSettler;
        private FileServices fileSrvs;
        private File selectedFile;
        private boolean pause=false;
        private boolean nextSeek=true;
        private boolean stepByStep=false;
        private boolean externalGameSelection=false;
        //private JFrame SpeedManagerFrame;

        public  PlaybackServices()
        {
            speedSettler = new SpeedManager();
            fileSrvs= new FileServices();
            infoWindow = new Informer(setInterface.getDimboard(),setInterface.getDimbase(),fileSrvs.getMovementList());
            movementStatus=new MoveStatus();
        }

        public void selectGame()
        {
            stopCurrentGame();

            FileNameExtensionFilter filter1 = new FileNameExtensionFilter("MinMaxGame Playback File", "mmg");
            FileNameExtensionFilter filter = new FileNameExtensionFilter("RLGame Playback File", "rlg");
            if(!externalGameSelection)
            {
                fileSelection= new JFileChooser();
                fileSelection.setDialogTitle("Open Game File");
                fileSelection.setFileFilter(filter1);
                fileSelection.setFileFilter(filter);
                if(selectedFile==null)
                    fileSelection.setCurrentDirectory(new File(System.getProperty("user.dir")));
                else
                    fileSelection.setCurrentDirectory(selectedFile);
                fileSelection.showOpenDialog(playbackBoard);
                fileSelection.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
                selectedFile = fileSelection.getSelectedFile();
                if((selectedFile==null)||(selectedFile.getName().equals("")))
                {
                   JOptionPane.showMessageDialog(playbackBoard, "Invalid file or file name", "File error", JOptionPane.ERROR_MESSAGE);
                   return;
                }
           
                try {
                    fileSrvs = new FileServices(selectedFile);
                } catch (IOException ex) {
                    Logger.getLogger(PlaybackFrame.class.getName()).log(Level.SEVERE, "IOException", ex);
                }


                if(fileSelection.getFileFilter() == filter)
                    fileSrvs.setFileType('a');
                if(fileSelection.getFileFilter() == filter1)
                    fileSrvs.setFileType('b');
                
                fileSrvs.getMovementList().clear();
                try
                {
                    fileSrvs.readRecordsToMakeList();
                }
                catch (NullPointerException NPE)
                {
                    return;
                }

                fileSrvs.estimateLostPawns();
                
            }

            setInterface.setDimboard(fileSrvs.getFNaneAnalyzer().getGameDimboard());
            setInterface.setDimbase(fileSrvs.getFNaneAnalyzer().getGameDimbase());
            setInterface.setNumpawns(fileSrvs.getFNaneAnalyzer().getGameNumpawns());

            modeButton.setEnabled(true);

            setNewPlaybackBoardFrame();

            progressionMngr.gameProgression.setMaximum(fileSrvs.getWinnerMovements());
            progressionMngr.setTicks(fileSrvs.getWinnerMovements());
            //if(!stepByStep)
            progressionMngr.gameProgression.setEnabled(true);

            infoWindow = new Informer(setInterface.getDimboard(),setInterface.getDimbase(),fileSrvs.getMovementList());
            playbackInfo();
            infoWindow.viewInformerTab(1);

            showTrajectories();

            if(MoveStatus.frame!=null)
            {
                if(setInterface.getDimboard()*40+60>400)
                    MoveStatus.frame.setLocation(setInterface.getDimboard()*40+80, 590);
                else
                    MoveStatus.frame.setLocation(420, 590);
            }

            System.out.print("\nThe movement list's size is: ");
            System.out.print(fileSrvs.getMovementList().size());
        }

        public void selectSpeed()
        {
            if(!speedSettler.isShowing())
                   speedSettler.createAndShowSpeedManager();
        }

        public void showMoveStatus()
        {
            if(!movementStatus.isShowing())
                movementStatus.createAndShowMoveStatus(setInterface.getDimboard());
        }

        public void showTrajectories()
        {
            int DIMBOARD=setInterface.getDimboard();
            Dimension trajectoryPanelDim = new Dimension(DIMBOARD*50+70,DIMBOARD*50+70);
            Informer.blueTrajectoryPanel.remove(Informer.blueTrajectoryViewer);
            Informer.blueTrajectoryViewer = new TrajectoryViewer(1,setInterface.getDimboard(),setInterface.getDimbase(),fileSrvs.getMovementList());
            Informer.blueTrajectoryPanel.setSize(trajectoryPanelDim);
            Informer.blueTrajectoryPanel.setPreferredSize(trajectoryPanelDim);
            Informer.blueTrajectoryPanel.add(Informer.blueTrajectoryViewer);
            Informer.blueTrajectoryViewer.setLocation(40,40);
            Informer.redTrajectoryPanel.remove(Informer.redTrajectoryViewer);
            Informer.redTrajectoryViewer = new TrajectoryViewer(2,setInterface.getDimboard(),setInterface.getDimbase(),fileSrvs.getMovementList());
            Informer.redTrajectoryPanel.setSize(trajectoryPanelDim);
            Informer.redTrajectoryPanel.setPreferredSize(trajectoryPanelDim);
            Informer.redTrajectoryPanel.add(Informer.redTrajectoryViewer);
            Informer.redTrajectoryViewer.setLocation(40,40);
            Informer.trajectoriesPanel.remove(Informer.trajectoriesViewer);
            Informer.trajectoriesViewer = new TrajectoryViewer(3,setInterface.getDimboard(),setInterface.getDimbase(),fileSrvs.getMovementList());
            Informer.trajectoriesPanel.setSize(trajectoryPanelDim);
            Informer.trajectoriesPanel.setPreferredSize(trajectoryPanelDim);
            Informer.trajectoriesPanel.add(Informer.trajectoriesViewer);
            Informer.trajectoriesViewer.setLocation(40,40);
        }

        public void playGameInitiation()
        {
            if(fileSrvs.getFile()==null)
            {
                selectGame();
            }
            setNewPlaybackBoardFrame();

            //fileSrvs.movementList.clear();

        }

        public void setNewPlaybackBoardFrame()
        {
            boardPanel.remove(playbackBoard);

            playbackBoard=new PlaybackBoard(setInterface.getDimboard(),setInterface.getDimbase());

            int DIMBOARD=setInterface.getDimboard();
            Dimension boardDim = new Dimension(DIMBOARD*40,DIMBOARD*40);
            Dimension frameDim = new Dimension(400,DIMBOARD*40+210);

            boardPanel.setMinimumSize(boardDim);
            boardPanel.setBackground(new Color(255, 255, 224));
            boardPanel.setBorder(new BevelBorder(BevelBorder.LOWERED,new Color(222,184,135),new Color(222,184,135)));
            boardPanel.add(playbackBoard);


            getThisPlaybackFrame().setMinimumSize(frameDim);
            getThisPlaybackFrame().setSize(DIMBOARD*40+60,DIMBOARD*40+310);
            if(getThisPlaybackFrame().getSize().width <= getThisPlaybackFrame().getMinimumSize().width)
                playbackBoard.setLocation(200-(DIMBOARD*40)/2,25);
            else
                playbackBoard.setLocation(37,25);
            getThisPlaybackFrame().repaint();

            if (getThisPlaybackFrame().getSize().getHeight() >= Toolkit.getDefaultToolkit().getScreenSize().getHeight())
            {
                southPanel.remove(speedPanel);
                southPanel.repaint();
                getThisPlaybackFrame().setSize(DIMBOARD*40+60,DIMBOARD*40+210);
                getThisPlaybackFrame().repaint();
                selectSpeedButton.setEnabled(true);
            }
            else
            {
                if(speedSettler.frame!=null&&speedSettler.frame.isVisible())
                {
                    speedSettler.frame.setVisible(false);
                    speedSettler.frame=null;
                }
                speedPanel.add(speedSettler);
                speedPanel.repaint();
                southPanel.add(speedPanel);
                southPanel.repaint();
                getThisPlaybackFrame().repaint();
                selectSpeedButton.setEnabled(false);
            }

        }

        public void playSingleMove(int serialNum, boolean backwards)
        {
            System.out.print("\n");
            System.out.print(speedSettler.getSeekNumber());
            System.out.print("**");
            System.out.print(serialNum);
            if(!pause && serialNum>=fileSrvs.getMovementList().size())
            {
                stopCurrentGame();
                    if(fileSrvs.getMovementList().size()%2!=0)
                        JOptionPane.showMessageDialog(playbackBoard,
                                "<html>The <b>winner</b> of this game was the player of the <font color=\"#0000CD\"><b>blue</b></font> base",
                                "!!!!THE WINNER!!!!",
                                JOptionPane.INFORMATION_MESSAGE,
                                new ImageIcon(getClass().getResource("images/dialog-information.png")));
                    else
                        JOptionPane.showMessageDialog(playbackBoard,
                                "<html>The <b>winner</b> of this game was the player of the <font color=\"#FF0000\">red</font> base",
                                "!!!!THE WINNER!!!!",
                                JOptionPane.INFORMATION_MESSAGE,
                                new ImageIcon(getClass().getResource("images/dialog-information.png")));
                speedSettler.setSeekNumber(speedSettler.getSeekNumber()-1);
                return;
            }
            else if(!pause && serialNum<0)
            {
                stopCurrentGame();
                speedSettler.setSeekNumber(speedSettler.getSeekNumber()+1);
                return;
            }
            else
            {
                int xCoord = fileSrvs.getMovementList().getMovement(serialNum).getPosNextX();
                int yCoord = fileSrvs.getMovementList().getMovement(serialNum).getPosNextY();
                int previousX = fileSrvs.getMovementList().getMovement(serialNum).getPosPrevX();
                int previousY = fileSrvs.getMovementList().getMovement(serialNum).getPosPrevY();

                movementStatus.setPrevXLabel(previousX);
                movementStatus.setPrevYLabel(previousY);
                movementStatus.setNextXLabel(xCoord);
                movementStatus.setNextYLabel(yCoord);
                movementStatus.setMovementNumLabel(serialNum/2+1);
                if(serialNum%2==0)
                    movementStatus.setPlayerLabel("BLUE", Color.BLUE);
                else
                    movementStatus.setPlayerLabel("RED", Color.RED);

                if(backwards)
                {
                    checkForDeletedPawns(serialNum,backwards);
                    checkMovementAndShowing( previousX, previousY, xCoord, yCoord );
                }
                else
                {
                    checkMovementAndShowing( xCoord, yCoord, previousX, previousY );
                    checkForDeletedPawns(serialNum,backwards);
                }
            }
        }

        public void playbackInfo()
        {
            if(!infoWindow.isShowing()) infoWindow.setVisible(true);
            infoWindow.viewInformerTab(0);
            updateCGInformer();
            if(setInterface.getDimboard()*40+60>400)
                infoWindow.setLocation(setInterface.getDimboard()*40+80, 10);
            else
                infoWindow.setLocation(420, 10);

        }

    public void updateCGInformer()
    {
        if(playbackSrvs.fileSrvs.getFNaneAnalyzer()!=null)
        {
            getThisPlaybackFrame().playbackSrvs.infoWindow.getDay().setText(playbackSrvs.fileSrvs.getFNaneAnalyzer().getGameDay());
            getThisPlaybackFrame().playbackSrvs.infoWindow.getMonth().setText(playbackSrvs.fileSrvs.getFNaneAnalyzer().getGameMonth());
            getThisPlaybackFrame().playbackSrvs.infoWindow.getMonthday().setText(playbackSrvs.fileSrvs.getFNaneAnalyzer().getGameMonthday());
            getThisPlaybackFrame().playbackSrvs.infoWindow.getUser().setText(playbackSrvs.fileSrvs.getFNaneAnalyzer().getGameUser());
            getThisPlaybackFrame().playbackSrvs.infoWindow.getHour().setText(playbackSrvs.fileSrvs.getFNaneAnalyzer().getGameHour());
            getThisPlaybackFrame().playbackSrvs.infoWindow.getMinutes().setText(playbackSrvs.fileSrvs.getFNaneAnalyzer().getGameMin());
            getThisPlaybackFrame().playbackSrvs.infoWindow.getSeconds().setText(playbackSrvs.fileSrvs.getFNaneAnalyzer().getGameSec());
            getThisPlaybackFrame().playbackSrvs.infoWindow.getDimboard().setText( String.valueOf(playbackSrvs.fileSrvs.getFNaneAnalyzer().getGameDimboard()));
            getThisPlaybackFrame().playbackSrvs.infoWindow.getDimbase().setText(String.valueOf(playbackSrvs.fileSrvs.getFNaneAnalyzer().getGameDimbase()));
            getThisPlaybackFrame().playbackSrvs.infoWindow.getNumpawns().setText(String.valueOf(playbackSrvs.fileSrvs.getFNaneAnalyzer().getGameNumpawns()));
            getThisPlaybackFrame().playbackSrvs.infoWindow.getWinner().setText(playbackSrvs.fileSrvs.getWinner());
            if(!playbackSrvs.fileSrvs.getMovementList().isEmpty())
            {
                if(playbackSrvs.fileSrvs.getWinner().equals("blue"))
                    getThisPlaybackFrame().playbackSrvs.infoWindow.getWinner().setForeground(Color.blue);
                else if(playbackSrvs.fileSrvs.getWinner().equals("red"))
                    getThisPlaybackFrame().playbackSrvs.infoWindow.getWinner().setForeground(Color.red);
                else getThisPlaybackFrame().playbackSrvs.infoWindow.getWinner().setForeground(Color.black);
                getThisPlaybackFrame().playbackSrvs.infoWindow.getWinnerMovements().setText(String.valueOf(playbackSrvs.fileSrvs.getWinnerMovements()));
                getThisPlaybackFrame().playbackSrvs.infoWindow.getWLostPawns().setText(String.valueOf(playbackSrvs.fileSrvs.getWLostPawns()));
                getThisPlaybackFrame().playbackSrvs.infoWindow.getBLostPawns().setText(String.valueOf(playbackSrvs.fileSrvs.getBLostPawns()));
                getThisPlaybackFrame().playbackSrvs.infoWindow.disableDetails(false);
            }
            else
                getThisPlaybackFrame().playbackSrvs.infoWindow.disableDetails(true);
        }

    }

        @SuppressWarnings("empty-statement")
        public void playSelectedGame()
        {
            if(fileSrvs.getFile()==null)
                return;
            if(!pause)
            {
                speedSettler.setSeekNumber(0);
            }
            //if(infoWindow.isShowing()) return;
            if(speedSettler.movesPerSecond.getValue()!=0) speedSettler.startAnimation();
            stopButton.setEnabled(true);
            pauseButton.setEnabled(true);
            modeButton.setEnabled(false);
        }

        public void pauseCurrentGame()
        {
            if(!pause)
            {
                speedSettler.stopAnimation();
                pause=true;
                nextButton.setEnabled(true);
                previousButton.setEnabled(true);
                if(speedSettler.getSeekNumber()==0)
                    previousButton.setEnabled(false);
                playButton.setEnabled(false);
                pauseButton.setToolTipText("Resume current game");
                pauseButton.setIcon(new ImageIcon(getClass().getResource("images/resume.png")));
            }
            else
            {
                if(!nextSeek)
                    speedSettler.setSeekNumber(speedSettler.getSeekNumber()+1);
                if(speedSettler.movesPerSecond.getValue()!=0) speedSettler.startAnimation();
                pause=false;
                nextSeek=true;
                nextButton.setEnabled(false);
                previousButton.setEnabled(false);
                playButton.setEnabled(true);
                pauseButton.setToolTipText("Pause current game");
                pauseButton.setIcon(new ImageIcon(getClass().getResource("images/pause.png")));
            }
        }

        public void stopCurrentGame()
        {
            if(stepByStep)
            {
                selectMode();
                playbackBoard.clearVisualBoardPawns();
                progressionMngr.gameProgression.setValue(0);
                setNewPlaybackBoardFrame();
                selectMode();
                return;
            }
            speedSettler.stopAnimation();
            speedSettler.setSeekNumber(0);
            progressionMngr.gameProgression.setValue(0);
            setNewPlaybackBoardFrame();
            //fileSrvs.movementList.clear();
            nextButton.setEnabled(false);
            previousButton.setEnabled(false);
            stopButton.setEnabled(false);
            pauseButton.setEnabled(false);
            playButton.setEnabled(true);
            modeButton.setEnabled(true);
            pauseButton.setToolTipText("Pause current game");
            pauseButton.setIcon(new ImageIcon(getClass().getResource("images/pause.png")));
        }

        public void nextMovement()
        {
            if(fileSrvs.getFile()==null)
            {
                selectGame();
                return;
            }
           // setNewPlaybackBoardFrame();
            if(pause)
            {
                if(!nextSeek)
                    speedSettler.setSeekNumber(speedSettler.getSeekNumber()+1);
                if(speedSettler.getSeekNumber()==fileSrvs.getMovementList().size()-1)
                    nextButton.setEnabled(false);
                if(speedSettler.getSeekNumber()>=fileSrvs.getMovementList().size())
                    speedSettler.setSeekNumber(fileSrvs.getMovementList().size()-1);
                if(speedSettler.getSeekNumber()==0)
                    previousButton.setEnabled(true);
                playSingleMove(speedSettler.getSeekNumber(), false);
                speedSettler.setSeekNumber(speedSettler.getSeekNumber()+1);
                progressionMngr.gameProgression.setValue(speedSettler.getSeekNumber()/2);
                nextSeek=true;
            }
        }

        public void previousMovement()
        {
            if(pause)
            {
                if(nextSeek)
                    speedSettler.setSeekNumber(speedSettler.getSeekNumber()-1);
                if(speedSettler.getSeekNumber()==0)
                    previousButton.setEnabled(false);
                if(speedSettler.getSeekNumber()<0)
                    speedSettler.setSeekNumber(0);
                if(speedSettler.getSeekNumber()==fileSrvs.getMovementList().size()-1)
                    nextButton.setEnabled(true);
                playSingleMove(speedSettler.getSeekNumber(), true);
                progressionMngr.gameProgression.setValue((speedSettler.getSeekNumber()+1)/2);
                speedSettler.setSeekNumber(speedSettler.getSeekNumber()-1);
                nextSeek=false;
            }
        }

        public void checkMovementAndShowing( int xCoord, int yCoord, int previousX, int previousY )
        {
            int DIMBOARD=setInterface.getDimboard();
            int DIMBASE=setInterface.getDimbase();
            playbackBoard.moveVisualPawn(previousX,previousY,xCoord,yCoord);
            if((playbackBoard.colorSelectedPawn(xCoord,yCoord)==1) && ((xCoord<=(DIMBASE-1))&&(yCoord<=(DIMBASE-1))))
            {
                playbackBoard.deleteVisualPawn(xCoord,yCoord);
            }
            else if((playbackBoard.colorSelectedPawn(xCoord,yCoord)==0) && ((xCoord>=(DIMBOARD-DIMBASE))&&(yCoord>=(DIMBOARD-DIMBASE))))
            {
                playbackBoard.deleteVisualPawn(xCoord,yCoord);
            }
        }

        @SuppressWarnings("empty-statement")
        public void checkForDeletedPawns( int serialNum, boolean backwards)
        {
            //PlaybackBoardFrame.playbackBoard.repaint();
            int DIMBOARD=setInterface.getDimboard();
            int DIMBASE=setInterface.getDimbase();
            if(!fileSrvs.getMovementList().getMovement(serialNum).getPawnsToDelete().isEmpty())
            {
                String deletionInfo="<html>At this point (<b>"+(serialNum/2+1)+"th move)</b> pawns at the positions:\n";
                for(int i=0; i<fileSrvs.getMovementList().getMovement(serialNum).getPawnsToDelete().size(); i++)
                {
                    String dPawn= (String)fileSrvs.getMovementList().getMovement(serialNum).getPawnsToDelete().get(i);
                    Scanner pawnToDelete= new Scanner(dPawn.replace("*", " "));
                    //System.out.print(dPawn.toString());
                    int color = pawnToDelete.nextInt();
                    int coordX = pawnToDelete.nextInt();
                    int coordY = pawnToDelete.nextInt();
                    if(backwards)
                    {
                        if(!((coordX<=(DIMBASE-1))&&(coordY<=(DIMBASE-1)))&&!((coordX>=(DIMBOARD-DIMBASE))&&(coordY>=(DIMBOARD-DIMBASE))))
                            playbackBoard.createVisualPawn(color, coordX, coordY);
                    }
                    else
                    {
                        playbackBoard.deleteVisualPawn(coordX,coordY);
                        if(color==1)
                            deletionInfo=deletionInfo+"<html><font color=\"#0000CD\"><b>("+coordX+","+coordY+")</b></font> of the player in the <font color=\"#0000CD\">blue</font> base\n";
                        if(color==0)
                            deletionInfo=deletionInfo+"<html><font color=\"#FF0000\"><b>("+coordX+","+coordY+")</b></font> of the player in the <font color=\"#FF0000\">red</font> base\n";
                    }

                }
                deletionInfo=deletionInfo+"were deleted because they have no legal move";
                if(!backwards&&!progressionMngr.gameProgression.isFocusOwner())
                    JOptionPane.showMessageDialog(progressionMngr.gameProgression,
                            deletionInfo,
                            "DELETIONS",
                            JOptionPane.INFORMATION_MESSAGE,
                            new ImageIcon(getClass().getResource("images/dialog-information.png")));
                //PlaybackBoardFrame.playbackBoard.repaint();
            }

        }

        public boolean getPause()
        {
            return pause;
        }

        public void setPause(boolean ok)
        {
            pause=ok;
        }

        public boolean getStepByStep()
        {
            return stepByStep;
        }

        public void setStepByStep(boolean ok)
        {
            stepByStep=ok;
        }

        public void selectMode()
        {
            speedSettler.setSeekNumber(0);
            playbackBoard.clearVisualBoardPawns();
            if(stepByStep)
            {
                stopButton.setEnabled(false);
                nextButton.setEnabled(false);
                previousButton.setEnabled(false);
                playButton.setEnabled(true);
                //PlaybackFrame.selectSpeedButton.setEnabled(true);
                //ProgressionManager.gameProgression.setEnabled(true);
                progressionMngr.gameProgression.setValue(0);
                modeButton.setToolTipText("Step by step node");
                modeButton.setIcon(new ImageIcon(getClass().getResource("images/step_by_step.png")));
                stepByStep=false;
                pause=false;
            }
            else
            {
                stopButton.setEnabled(true);
                pauseButton.setEnabled(false);
                nextButton.setEnabled(true);
                playButton.setEnabled(false);
                //PlaybackFrame.selectSpeedButton.setEnabled(false);
                //ProgressionManager.gameProgression.setEnabled(false);
                modeButton.setToolTipText("Normal node");
                modeButton.setIcon(new ImageIcon(getClass().getResource("images/normal.png")));
                stepByStep=true;
                pause=true;
            }
        }

        public Informer getInfoWindow() {
            return infoWindow;
        }

        public FileServices getFileSrvs() {
            return fileSrvs;
        }

        public void setFileSrvs(FileServices fileSrvs) {
            this.fileSrvs = fileSrvs;
        }

        public File getSelectedFile() {
            return selectedFile;
        }

        public void setSelectedFile(File selectedFile) {
            this.selectedFile = selectedFile;
        }

        public boolean isExternalFileSelection() {
            return externalGameSelection;
        }

        public void setExternalFileSelection(boolean externalFileSelection) {
            this.externalGameSelection = externalFileSelection;
        }

        public SpeedManager getSpeedSettler() {
            return speedSettler;
        }

    }




    public class ProgressionManager extends JPanel {


        private JSlider gameProgression;

        /** Creates new form ProgressionManager */
        public ProgressionManager() {
            initComponents();
        }

        public void setTicks(int maxValue)
        {
            Hashtable<Integer, JLabel> labelTable = new Hashtable<Integer, JLabel>();
            for(int i=0; i<16; i++)
            {
                int k=i*(maxValue/10);
                labelTable.put(new Integer( k ), new JLabel(String.valueOf(k)));
            }
            gameProgression.setLabelTable(labelTable);
            if(maxValue<=10)
            {
                gameProgression.setMajorTickSpacing(1);
                gameProgression.setMinorTickSpacing(0);
                return;
            }
            else if(maxValue>10 && maxValue<=20)
            {
                gameProgression.setMajorTickSpacing(2);
                gameProgression.setMinorTickSpacing(1);
                return;
            }
            else if(maxValue>20 && maxValue<=30)
            {
                gameProgression.setMajorTickSpacing(3);
                gameProgression.setMinorTickSpacing(1);
                return;
            }
            else if(maxValue>30 && maxValue<=50)
            {
                gameProgression.setMajorTickSpacing(5);
                gameProgression.setMinorTickSpacing(1);
                return;
            }
            else if(maxValue>50 && maxValue<=100)
            {
                gameProgression.setMajorTickSpacing(10);
                gameProgression.setMinorTickSpacing(2);
                return;
            }
            else if(maxValue>100 && maxValue<=200)
            {
                gameProgression.setMajorTickSpacing(20);
                gameProgression.setMinorTickSpacing(4);
                return;
            }
            else if(maxValue>200 && maxValue<=300)
            {
                gameProgression.setMajorTickSpacing(30);
                gameProgression.setMinorTickSpacing(6);
                return;
            }
            else if(maxValue>300 && maxValue<=500)
            {
                gameProgression.setMajorTickSpacing(50);
                gameProgression.setMinorTickSpacing(10);
                return;
            }
            else if(maxValue>500 && maxValue<=1000)
            {
                gameProgression.setMajorTickSpacing(100);
                gameProgression.setMinorTickSpacing(20);
                return;
            }
            else if(maxValue>1000 && maxValue<=1500)
            {
                gameProgression.setMajorTickSpacing(150);
                gameProgression.setMinorTickSpacing(30);
            }
            else if(maxValue>1500 && maxValue<=2000)
            {
                gameProgression.setMajorTickSpacing(200);
                gameProgression.setMinorTickSpacing(40);
            }
            else if(maxValue>2000 && maxValue<=3000)
            {
                gameProgression.setMajorTickSpacing(300);
                gameProgression.setMinorTickSpacing(60);
            }
            else if(maxValue>3000 && maxValue<=5000)
            {
                gameProgression.setMajorTickSpacing(500);
                gameProgression.setMinorTickSpacing(100);
            }
            else
            {
                gameProgression.setMajorTickSpacing(1000);
                gameProgression.setMinorTickSpacing(200);
                gameProgression.setSnapToTicks(false);
                return;
            }

        }

        @SuppressWarnings("unchecked")
        private void initComponents() {

            gameProgression = new JSlider();

            setBackground(new Color(250, 250, 210));

            gameProgression.setBackground(new Color(240, 230, 140));
            gameProgression.setMajorTickSpacing(10);
            gameProgression.setMinorTickSpacing(2);
            gameProgression.setPaintLabels(true);
            gameProgression.setPaintTicks(true);
            gameProgression.setSnapToTicks(true);
            gameProgression.setToolTipText("<html>\n\n<font color=\"#B8860B\">You may drag with your mouse the slider pointer at any time either in <b>step by</b><br />\n<b>step mode</b> or in <b>normal mode</b>. The slider value where the pointer will be dropped<br />\nis the move from which the game will continue its execution. The pointer ticks<br />\nand labels represent one round of movements (one move for both of the players)<br /></font>");
            gameProgression.setValue(0);
            gameProgression.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED, new Color(255, 255, 225), new Color(218, 165, 32)), "SELECT A MOVE ROUND", TitledBorder.CENTER, TitledBorder.DEFAULT_POSITION, new Font("SansSerif", 1, 10), new Color(218, 165, 32)));
            gameProgression.setEnabled(false);
            gameProgression.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mousePressed(java.awt.event.MouseEvent evt) {
                    stopPlayingCurrentMove(evt);
                }
                @Override
                public void mouseReleased(java.awt.event.MouseEvent evt) {
                    continuePlayingFromThisMove(evt);
                }
            });

            GroupLayout layout = new javax.swing.GroupLayout(this);
            this.setLayout(layout);
            layout.setHorizontalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(gameProgression, GroupLayout.DEFAULT_SIZE, 497, Short.MAX_VALUE)
                    .addContainerGap())
            );
            layout.setVerticalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(gameProgression, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            );
        }

        private void stopPlayingCurrentMove(MouseEvent evt)
        {

            if(gameProgression.isEnabled())
            {
                if(!playbackSrvs.stepByStep)
                {
                    if(!playbackSrvs.pause)
                        playbackSrvs.pauseCurrentGame();
                    else
                        playbackSrvs.setPause(false);
                }
            }
        }

        private void continuePlayingFromThisMove(MouseEvent evt)
        {
            if(gameProgression.isEnabled())
            {
                int j = playbackSrvs.speedSettler.getSeekNumber();
                int k = gameProgression.getValue();
                playbackSrvs.speedSettler.setSeekNumber(2*k);
                if(2*k>playbackSrvs.fileSrvs.getMovementList().size())
                {
                    playbackSrvs.stopCurrentGame();
                    return;
                }
                if(2*k-j>=0)
                {
                    for(int i=j; i<2*k; i++)
                    {
                        playbackSrvs.playSingleMove(i, false);
                    }
                }
                else
                {
                    for(int i=j-1; i>=2*k; i--)
                    {
                        playbackSrvs.playSingleMove(i, true);
                    }
                }
                if(!playbackSrvs.stepByStep)
                {
                    playbackSrvs.pauseCurrentGame();
                    getThisPlaybackFrame().pauseButton.setEnabled(true);
                }
                getThisPlaybackFrame().stopButton.setEnabled(true);
                if(playbackSrvs.pause)
                    getThisPlaybackFrame().previousButton.setEnabled(true);
                getThisPlaybackFrame().nextButton.setEnabled(true);
                if(playbackSrvs.speedSettler.getSeekNumber()==0)
                    getThisPlaybackFrame().previousButton.setEnabled(false);
                if(playbackSrvs.speedSettler.getSeekNumber()==playbackSrvs.fileSrvs.getMovementList().size())
                    getThisPlaybackFrame().nextButton.setEnabled(false);
                gameProgression.transferFocusBackward();
            }

        }

        public JSlider getGameProgression() {
            return gameProgression;
        }

    }



    public class SpeedManager extends JComponent implements ActionListener,WindowListener,ChangeListener
    {
        //Set up animation parameters.
        static final int FPS_MIN = 0;
        static final int FPS_MAX = 40;
        static final int FPS_INIT = 20;
        private int seekNumber =0;
        private int delay;
        private Timer timer;
        private boolean frozen = false;
        private JSlider movesPerSecond;
        JFrame frame;

        public SpeedManager() {
            setBackground(new Color(250, 250, 210));
            setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));

            delay = 10000 / FPS_INIT;

            //Create the slider.
            movesPerSecond = new JSlider(JSlider.HORIZONTAL,FPS_MIN, FPS_MAX, FPS_INIT);

            movesPerSecond.addChangeListener(this);

            //Turn on labels at major tick marks.
            movesPerSecond.setMajorTickSpacing(10);
            movesPerSecond.setMinorTickSpacing(1);
            movesPerSecond.setPaintTicks(true);
            movesPerSecond.setPaintLabels(true);
            movesPerSecond.setToolTipText("<html><font color=\"#B8860B\">You may drag the slider pointer with the mouse in order to alter the game playback<br/>speed. The pointer drop point will specify the increment or decrement.</font>");
            movesPerSecond.setBackground(new Color(240,230,140));
            movesPerSecond.setBorder(
                 BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(BevelBorder.RAISED,new Color(255, 255, 224),new Color(218,165,32)),
                                                  "SELECT GAME SPEED",
                                                  TitledBorder.CENTER,
                                                  TitledBorder.TOP,
                                                  new Font("Sans Serif", Font.BOLD, 10),
                                                  new Color(218,165,32)));
            Font font = new Font("Sans", Font.PLAIN, 12);
            movesPerSecond.setFont(font);
            add(movesPerSecond);
            setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

            //Set up a timer that calls this object's action handler.
            timer = new Timer(delay, this);
            timer.setInitialDelay(delay * 2); //We pause animation twice per cycle by restarting the timer
            timer.setCoalesce(true);
        }

        /** Add a listener for window events. */
        public void addWindowListener(Window w) {
            w.addWindowListener(this);
        }

        //React to window events.

        public void windowOpened(WindowEvent e) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public void windowClosing(WindowEvent e) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public void windowClosed(WindowEvent e) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public void windowIconified(WindowEvent e) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public void windowDeiconified(WindowEvent e) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public void windowActivated(WindowEvent e) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public void windowDeactivated(WindowEvent e) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        /** Listen to the slider. */
        public void stateChanged(ChangeEvent e) {
            JSlider source = (JSlider)e.getSource();
            if (!source.getValueIsAdjusting()) {
                int fps = (int)source.getValue();
                if (fps == 0) {
                    if (!frozen) stopAnimation();
                } else {
                    if (frozen) startAnimation();
                    delay =10000 / fps;
                    timer.setDelay(delay);
                    timer.setInitialDelay(delay * 2);
                }
            }
        }

        public void startAnimation() {
            //Start (or restart) animating!
            timer.start();
            frozen = false;
        }

        public void stopAnimation() {
            //Stop the animating thread.
            timer.stop();
            frozen = true;
        }

        public int getSeekNumber()
        {
            return seekNumber;
        }

        public void setSeekNumber(int num)
        {
            seekNumber=num;
        }

        //Called when the Timer fires.
        public void actionPerformed(ActionEvent e) {

            playbackSrvs.playSingleMove(seekNumber,false);
            seekNumber++;
            progressionMngr.gameProgression.setValue(seekNumber/2);
        }

        public void createAndShowSpeedManager()
        {
            //Create and set up the window.
            JPanel speedPanel = new JPanel();
            frame = new JFrame("Run Speed");
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            speedPanel.setBackground(new Color(250, 250, 210));
            speedPanel.setBorder(new BevelBorder(BevelBorder.LOWERED,new Color(222,184,135),new Color(222,184,135)));
            speedPanel.setLayout(new BorderLayout());
            speedPanel.add(this, BorderLayout.CENTER);

            frame.add(speedPanel);
            frame.pack();
            frame.setSize(new Dimension(500,120));
            //frame.setBackground(new Color(250, 250, 210));
            frame.setResizable(false);
            frame.setVisible(true);
            frame.setLocation(520, 580);
            ImageIcon winIcon = new ImageIcon(getClass().getResource("images/selectspeed.png"));
            frame.setIconImage(winIcon.getImage());
        }


    }


}
