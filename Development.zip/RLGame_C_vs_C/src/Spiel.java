import java.awt.*;


//Spiel is ''game'' in german
import java.util.Random;
import java.util.StringTokenizer;
public class Spiel implements Common{
    static NeuralNet whiteNeural; //neural net used for the 1st player
    static NeuralNet blackNeural; //neural net used for the 2nd player
    
    //**************Added by Dockos************
    static Player whitePlayer; //human player
    static Player blackPlayer; //computer player
    static double whiteGamma=0.95;
    static double blackGamma=0.95;
    static double whiteLamda=0.5;
    static double blackLamda=0.5;
   //******************************************

    static Pawn[] whitePawn;
    static Pawn[] blackPawn;
    static Position myPosition;
    static TextArea myStats=new TextArea(); //used for the statistics
    static int inputSize=DIMBOARD*DIMBOARD-2*DIMBASE*DIMBASE+5; //abbreviation
    public Spiel(int dimBoard,int dimBase,int numOfPawns) {
      GameBoard myBoard=new GameBoard(dimBoard,dimBase);
      whitePawn=new Pawn[numOfPawns];
      blackPawn=new Pawn[numOfPawns];

      /*whiteNeural=new NeuralNet(1,2*inputSize,inputSize,1,0.95,0.5);
        blackNeural=new NeuralNet(2,2*inputSize,inputSize,1,0.95,0.5);
        replaced by Dockos to*/
      whiteNeural=new NeuralNet(1,2*inputSize,inputSize,1,whiteGamma,whiteLamda);
      blackNeural=new NeuralNet(2,2*inputSize,inputSize,1,blackGamma,blackLamda);
      
      //Player whitePlayer=new Player(1);
      //Player blackPlayer=new Player(2);
      //Modified by Dockos to
      whitePlayer=new Player(1);
      blackPlayer=new Player(2);

      for (int i=0;i<numOfPawns;i++){
        whitePawn[i]=new Pawn(i,true);
        blackPawn[i]=new Pawn(i,false);
      }
      myPosition=new Position(whitePawn,blackPawn);
      int counter=1; //so as not to let a game last forever, the maximum number of moves is 10000
      int[] whiteDesc=new int[2]; //not used, description of the move made
      int[] blackDesc=new int[2]; //not used, description of the move made
      boolean written=false;
      while ((myPosition.isFinal(whitePawn,blackPawn)==false)&&(counter<10000)){
        whiteDesc=whitePlayer.pickWhiteMove(whitePawn,GameBoard.mySquare);
        if (myPosition.isFinal(whitePawn,blackPawn)==false){
         blackDesc=blackPlayer.pickBlackMove(blackPawn,GameBoard.mySquare);
        } else {
                  written=true;
                  createStats(""+counter);
                  createStats("aspros");
                  //Added by Dockos
                  storeGameMovesAndStats();
               }
        counter++;
      }
      if ((counter<10000)&&(written==false)){
        createStats(""+ (--counter));
        createStats("mavros");
        //Added by Dockos
        storeGameMovesAndStats();
      }
      whiteNeural.storeWeights();
      blackNeural.storeWeights();
    }
    public void createStats(String s)
    {
        myStats.append(s);
        myStats.append("\n");

    }

    //Added by Dockos
    public void storeGameMovesAndStats()
    {
        String wHistory=whitePlayer.toWSaveGame.getText(); //white human player moves
        String bHistory=blackPlayer.toBSaveGame.getText(); //black computer player moves
        history gameHistory=new history();
        StringTokenizer stW = new StringTokenizer(wHistory.replace('\n',' '));
        StringTokenizer stB = new StringTokenizer(bHistory.replace('\n',' '));
        String gameMoves="";
        while(stB.hasMoreTokens())
        {
            gameMoves+=stW.nextToken()+"\t"+stB.nextToken()+"\n";
        }
        //o aspros mporei na exei mia akomi kinisi => check it
        if(stW.hasMoreTokens())
        {
            gameMoves+=stW.nextToken()+'\n';
        }
        gameHistory.writeToFile(gameMoves,"_cVSc_"+DIMBOARD+"_"+DIMBASE+"_"+NUMOFPAWNS+"_game_"+Math.abs(new Random().nextInt()),0);
    }    
    
}
