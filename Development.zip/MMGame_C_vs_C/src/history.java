//records the result and the number of moves

import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class history {
  File file;
  FileWriter out;

  /*****************************************/
  /*public history(String fileName) {
  Modified by Dockos to */
  public history(String fileName,int historyType, String Path) {
  /*******************************************/

    /* Date myDate=new Date();
    String fileName=myDate.toString();
    fileName=fileName.substring(11,19);
    fileName=fileName.replace(':',' ');
    fileName=fileName.concat(".txt"); */

    /************* Added by Dockos ************/
    Date myDate=new Date();
    String name=fileName;
    String startName=myDate.toString();
    startName=startName.substring(0,19);
    startName=startName.replace(':',' ');
    name=startName+name;
    if(historyType==0)
    {
        name=name.concat(".mmg");
        file=new File(Path+File.separatorChar+name);
    }
    if(historyType==1)
    {
        name=name.concat(".txt");
        file=new File(name);
    }
    /******************************************/

    /******************************************/
    /* file=new File(fileName);
    Deleted by Dockos */
    /******************************************/

  }
  
  //updates the file
  final void writeToFile(String s){
        try {
            out = new FileWriter(file, true);
            out.write(s);
            out.close();
        } catch (IOException ex) {
            Logger.getLogger(history.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("tin katsame");
        }

  }
}
