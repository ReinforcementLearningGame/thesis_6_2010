#!/bin/sh

mkdir -v weights
cp -v whVWeights weights/
cp -v whWWeights weights/
cp -v blVWeights weights/
cp -v blWWeights weights/
cp -v whVWeights ../
cp -v whWWeights ../
cp -v blVWeights ../
cp -v blWWeights ../

