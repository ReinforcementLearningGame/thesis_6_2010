/***************
  Created by: Eirini Ntoutsi
  Operation:
*******/
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class PlaybackBoard extends JComponent
{
   private Vector visualPawns;
   private Point selectedSquare;
   private int DIMBOARD;
   private int DIMBASE;
   private Dimension minPBSize;

   //constructor
   public PlaybackBoard(int dimboard, int dimbase)
   {
      super();
      DIMBOARD=dimboard;
      DIMBASE=dimbase;
      minPBSize=new Dimension(DIMBOARD*40,DIMBOARD*40);
      selectedSquare=new Point(-1,-1);
      setSize(minPBSize);
      setMaximumSize(minPBSize);
      setMinimumSize(minPBSize);
      setPreferredSize(minPBSize);
      visualPawns=new Vector();
      addMouseListener(new MouseAdapter()
          {
            @Override
            public void mouseClicked(MouseEvent e)
            {

            }
          }
      );
   }

   //klasi Visual Pawn
   public class VisualPawn
   {
      private int cordX;
      private int cordY;
      private int color;

      VisualPawn(int cordX,int cordY, int color)
      {
         this.cordX=cordX;
         this.cordY=cordY;
         this.color=color;
      }
      public int getXCord()
      {
         return cordX;
      }

      public int getYCord()
      {
         return cordY;
      }

      public int getColor()
      {
         return color;
      }
   }

   public int colorSelectedPawn(int selX,int selY)
   {
      int selColor=0;
      for(int i=0;i<visualPawns.size();i++)
      {
          VisualPawn selPawn=(VisualPawn)visualPawns.get(i);
          if((selPawn.getXCord()==selX)&&(selPawn.getYCord()==selY))
          {
             selColor=selPawn.getColor();
          }
      }
      return selColor;
   }


   //metakinise to visual pawn apo ti thesi (removeX,removeY) sti thesi (addX,addY)
   public void moveVisualPawn(int removeX,int removeY,int addX,int addY)
   {
      boolean done=false;
      for(int i=0;i<visualPawns.size();i++)
      {
          VisualPawn tmpPawn=(VisualPawn)visualPawns.get(i);
          if((tmpPawn.getXCord()==removeX)&&(tmpPawn.getYCord()==removeY))
          {
             int color=tmpPawn.getColor();
             visualPawns.remove(tmpPawn);
             VisualPawn toDisplayPawn=new VisualPawn(addX,addY,color);
             visualPawns.addElement(toDisplayPawn);
             done=true;
             break;
          }
      }
      if(done)
      {
          repaint();
          return;
      }
      if((removeX+removeY<=2*(DIMBASE-1))&&(removeX<=(DIMBASE-1))&&(removeY<=(DIMBASE-1)))
      {
      	VisualPawn toDisplayPawn=new VisualPawn(addX,addY,1);
      	visualPawns.addElement(toDisplayPawn);
      }
      if((removeX+removeY>=2*(DIMBOARD-DIMBASE))&&(removeX>=(DIMBOARD-DIMBASE))&&(removeY>=(DIMBOARD-DIMBASE)))
      {
      	VisualPawn toDisplayPawn=new VisualPawn(addX,addY,0);
      	visualPawns.addElement(toDisplayPawn);
      }
      repaint();
   }

   //gia ti diagrafi tou visual pawn (removeX,removeY)
   public void deleteVisualPawn(int removeX,int removeY)
   {
      for(int i=0;i<visualPawns.size();i++)
      {
          VisualPawn tmpPawn=(VisualPawn)visualPawns.get(i);
          if((tmpPawn.getXCord()==removeX)&&(tmpPawn.getYCord()==removeY))
          {
              visualPawns.remove(tmpPawn);
              break;
          }
      }
      repaint();
   }
   
   public void createVisualPawn(int color,int addX,int addY)
   {
        VisualPawn toDisplayPawn=new VisualPawn(addX,addY,color);
        visualPawns.addElement(toDisplayPawn);
        repaint();
   }
   
   //kanei reset sta visual pawns
   public void clearVisualBoardPawns()
   {
       visualPawns.clear();
       repaint();
   }

   //gia to paint tou component
    @Override
   public void paintComponent (Graphics g)
   {
      Graphics2D g2D = null;
      if (g instanceof Graphics2D)
        g2D = (Graphics2D) g;
      else
        return;

      float slope_x = (getSize().width-1)/DIMBOARD;
      float slope_y = (getSize().height-1)/DIMBOARD;

      //paralliles kai kathetes grammes gia tin emfanisi tou board
      g2D.setColor(Color.magenta);
      for (int i=0;i<DIMBOARD+1;i++)
      {
        g2D.drawLine(0,(int)(slope_y*i),(int)slope_x*DIMBOARD,(int)slope_y*i);
        g2D.drawLine((int)(slope_x*i),0,(int)slope_x*i,(int)slope_y*DIMBOARD);
      }
      //g2D.drawLine(0,(int)(slope_y*DIMBOARD),(int)slope_x*DIMBOARD,(int)slope_y*DIMBOARD);
      //g2D.drawLine((int)(slope_x*DIMBOARD)+1,0,(int)slope_x*DIMBOARD+1,(int)slope_y*DIMBOARD);

      //xromatise tis baseis
      g2D.setColor(Color.red);
      g2D.fill3DRect((int)((DIMBOARD-DIMBASE)*slope_x)+2,2,(int)(DIMBASE*slope_x)-3,(int)(slope_y*DIMBASE)-3,true);
      g2D.setColor(Color.blue);
      g2D.fill3DRect(2,(int)((DIMBOARD-DIMBASE)*slope_y)+2,(int)(DIMBASE*slope_x)-3,(int)(DIMBASE*slope_y)-3,true);

      //arithmise ta tetragwna
      g2D.setColor(Color.black);
      for ( int j = 0; j <DIMBOARD; j++ )
      {
         int axeX = (int)((float)j*slope_x);
         int axeY = (int) ((float)j*slope_y);
         g2D.drawString(""+(DIMBOARD-j-1),3,axeY+(slope_y/2));
         g2D.drawString(""+(j),axeX+(slope_x/2),DIMBOARD*40-4-DIMBOARD);
      }
      
      if((selectedSquare.getX()!=-1)&&(selectedSquare.getY()!=-1))
      {
         g2D.setColor(Color.red);
         g2D.draw3DRect((int)(selectedSquare.getX()*slope_x),(int)((DIMBOARD-1-selectedSquare.getY())*slope_y),(int)(slope_x),(int)(slope_y),true);
      }
      //emfanise ta pionia
      for (int k=0;k<visualPawns.size();k++)
      {
         VisualPawn displayP=(VisualPawn)visualPawns.get(k);
         int x=displayP.getXCord();
         int y=displayP.getYCord();
         int myColor=displayP.getColor();
         if(myColor==1)
         {
            g2D.setColor(Color.green);
            if(!((x>=(DIMBOARD-DIMBASE))&&(y>=(DIMBOARD-DIMBASE))))
                g2D.fillOval((int)(x*slope_x)+2,(int)((DIMBOARD-1-y)*slope_y)+2,(int)slope_x-4,(int)slope_y-4);
         }
         else
         {
            g2D.setColor(Color.orange);
            if(!((x<=DIMBASE-1)&&(y<=DIMBASE-1)))
                g2D.fillOval((int)(x*slope_x)+2,(int)((DIMBOARD-1-y)*slope_y)+2,(int)slope_x-4,(int)slope_y-4);
         }
      }
   }
//this is the end
}
